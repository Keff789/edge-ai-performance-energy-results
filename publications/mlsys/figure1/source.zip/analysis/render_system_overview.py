#!/usr/bin/env python3
"""Render the author's boundary-capability schematic from its vector source.

The source preserves the diagram supplied with the 20 October manuscript.
Its two Task Completion labels are corrected. See system_overview_provenance.json.
The paired measurement comparison is explained in the figure caption.
"""
from pathlib import Path
import argparse
import shutil
import fitz

ROOT = Path(__file__).resolve().parents[1]

def render(preview=None):
    source = ROOT / "analysis/system_overview.svg"
    target = ROOT / "figures/system_overview.pdf"
    svg_document = fitz.open(source)
    target.write_bytes(svg_document.convert_to_pdf())
    shutil.copyfile(source, ROOT / "figures/system_overview.svg")
    pdf_document = fitz.open(target)
    pdf_document[0].get_pixmap(matrix=fitz.Matrix(3, 3), alpha=False).save(preview or ROOT / "figures/system_overview.png")
    print(target)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--preview", type=Path)
    render(parser.parse_args().preview)
