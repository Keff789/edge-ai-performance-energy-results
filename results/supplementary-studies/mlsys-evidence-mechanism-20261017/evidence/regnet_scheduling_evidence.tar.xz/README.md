# R14: Nachweise, Rangumkehr und feste Kalibrierung

Auftrag `mlsys_r14_evidence_mechanism_20261017_sm2`, begonnen am 17. Oktober 2026 auf Smartmirror2. Das Manuskript und seine Originaldaten bleiben unverändert. Die Prüfung bezieht sich auf den Ergebnissnapshot `1b01b220b2a80af7e2e3fa186f777a0676582854`. Neue Geräteversuche werden getrennt ausgewiesen.

Arbeitsverzeichnis auf SM2:

```text
/home/kmika/Reports/mlsys_r14_evidence_mechanism_20261017_sm2
```

`REPORT.md` enthält die wissenschaftlichen Entscheidungen, `PAPER_DELTA.md` die kurzen englischen Ersatzpassagen. `CLAIM_STATUS.csv` verbindet Aussagen mit Belegen. Der aktuelle Ausführungsstand steht in `STATUS.md`, der sichere Wiederaufnahmeweg in `RESUME.md`.

## Numerische Reproduktion ohne Gerätezugang

Die Befehle werden im entpackten Paketverzeichnis ausgeführt. Die numerischen Originaltabellen wurden mit `/usr/bin/python3` (Python 3.12.3), dem System-Build von NumPy 1.26.4 und PyYAML 6.0.1 erzeugt. Die Grafik wurde mit der vorhandenen Tool-Umgebung erstellt, die NumPy 1.26.4, PyYAML 6.0.3 und Matplotlib 3.5.2 enthält. Beide Umgebungen stehen in `receipts/REPRODUCTION_ENVIRONMENT.json`. Pandas 2.2.3 ist nur für das zusätzlich mitgelieferte ursprüngliche R14-Reviewprogramm nötig. Die neuen Prüfprogramme benötigen weder ONNX-Modelle noch Zugang zu den Geräten. Die großen Originaldateien werden über Pfade und SHA256 referenziert.

Auf SM2 die unten angegebenen Interpreter verwenden. Das System-Python allein enthält hier kein Matplotlib. Auf anderen Rechnern die Programme in einer Umgebung mit den genannten Abhängigkeiten ausführen. Für Neuberechnungen eine Arbeitskopie des entpackten Pakets verwenden und die gelieferten Hashes vorher prüfen.

Zwei NumPy-Builds derselben Version können letzte Gleitkommastellen unterschiedlich berechnen. Im geprüften Vergleich betrug die größte Vorhersageabweichung 5,69e-13 FPS. Rangfolgen und Zusammenfassungen blieben bytegleich, die unabhängigen numerischen Toleranzprüfungen bestanden. Bytegleichheit sämtlicher Originaltabellen bezieht sich auf die dokumentierte ursprüngliche numerische Umgebung.

```sh
/usr/bin/python3 analysis/reproduce_r14.py
/usr/bin/python3 analysis/audit_evidence.py --check
/usr/bin/python3 analysis/calibration.py
/usr/bin/python3 analysis/review_calibration_independent.py
/usr/bin/python3 analysis/deepx_evidence.py --offline
/usr/bin/python3 analysis/deepx_b135_audit.py --offline
/usr/bin/python3 analysis/review_mechanism_canaries.py --root . --output results/mechanism_canary_reproduced.json --notes-output notes/mechanism_canary_reproduced.md
/usr/bin/python3 analysis/verify_task.py
```

Auf SM2 ist die passende bestehende Python-Umgebung unter `/home/kmika/ONNX-Splitpoint-Tool/.venv/bin/python` verfügbar. Die separat angelegte `.venv-r14` im Arbeitsverzeichnis enthält zusätzlich Pandas für den unveränderten R14-Reviewer. Virtuelle Umgebungen werden nicht in das ZIP kopiert.

`run_mechanism.py` ist der Ausführungscontroller für SM2. Auch seine Vorprüfung ohne `--run` verlangt die dort gepinnten Geräteprofile und Produktquellen. Für die portable Offline-Auswertung ist `summarize_mechanism.py` zuständig.

Die Mechanismusauswertung enthält 40 RegNet-Prozesse und 20 ResNet-Prozesse in je fünf vollständigen Blöcken. Alle 60 sind abgeschlossen und zugelassen. Die vorab definierte Erweiterung wurde nicht ausgelöst. Die 16 Zuordnungspiloten und zwei Dauerpiloten bleiben getrennt. Zusammen mit dem DeepX-Zuordnungsworker wurden 79 neue Workerprozesse abgeschlossen. Historische R14-Werte werden nicht mit der neuen Serie gepoolt.

Das Hauptprotokoll hat SHA256 `bff5aff0a26d8148256a688bccd2dd7e254092d42fcafb36b59f486edb96d9fd`. Der endgültige unveränderliche Snapshot ist `results/mechanism_snapshots/final_8dafb76fcb92c94314a52e43fb06282d87200dc2900416af823b61786e079fa8.json`. Diese Befehle erzeugen neue Ausgaben unter `results/reproduced/` und erhalten die versiegelten Originalquittungen:

```sh
/usr/bin/python3 analysis/summarize_mechanism.py --protocol PROTOCOL.json --progress results/mechanism_snapshots/final_8dafb76fcb92c94314a52e43fb06282d87200dc2900416af823b61786e079fa8.json --output-prefix results/reproduced/mechanism_confirmation --extension-receipt results/reproduced/mechanism_extension_trigger.json --no-figure
/usr/bin/python3 analysis/review_mechanism_results.py --protocol PROTOCOL.json --progress results/mechanism_snapshots/final_8dafb76fcb92c94314a52e43fb06282d87200dc2900416af823b61786e079fa8.json --analysis-prefix results/reproduced/mechanism_confirmation --extension-receipt results/mechanism_extension_trigger.json --output results/reproduced/mechanism_results_review.json
/usr/bin/python3 analysis/review_mechanism_execution.py --scope final --protocol PROTOCOL.json --progress-snapshot results/mechanism_snapshots/final_8dafb76fcb92c94314a52e43fb06282d87200dc2900416af823b61786e079fa8.json --primary-snapshot results/mechanism_snapshots/primary_5c32953af167653272c3259426005712bc01f804cdd17dd2331ef6d6b3dd52fd.json --extension-trigger results/mechanism_extension_trigger.json --output results/reproduced/mechanism_execution_review.json
/usr/bin/python3 analysis/summarize_mechanism_stages.py --protocol PROTOCOL.json --progress results/mechanism_snapshots/final_8dafb76fcb92c94314a52e43fb06282d87200dc2900416af823b61786e079fa8.json --phase primary --phase replication --output-prefix results/reproduced/mechanism_stages
/home/kmika/ONNX-Splitpoint-Tool/.venv/bin/python analysis/make_mechanism_paper_figure.py --summary-json results/reproduced/mechanism_confirmation.json --summary-csv results/reproduced/mechanism_confirmation_summary.csv --blocks-csv results/reproduced/mechanism_confirmation_blocks.csv --output-prefix figures/reproduced/mechanism
```

Die gespeicherten Originalergebnisse und ihre Hashes werden durch diese zusätzlichen Mechanismusausgaben nicht ersetzt. Numerische Tabellen sind maßgeblich für die Reproduktionsprüfung. Neu erzeugte PDF-Dateien können durch Metadaten andere Bytes haben.

Die kompakte historische Referenz unter `evidence/mechanism_historical_references/` wird für die unabhängige Canary-Nachrechnung mitgeliefert. Deren Ausgaben werden bewusst unter neuen Namen geschrieben, damit die im Hauptprotokoll gebundene ursprüngliche Pilotquittung unverändert bleibt. Die frühere Prüferfassung ist unter `receipts/historical_reviewers/` erhalten.

Die Statistiksoftware ist separat unter `receipts/ANALYSIS_CODE_PIN.json` gebunden. Ihre mathematischen Regeln standen bereits im vor dem ersten bestätigenden Prozess eingefrorenen Protokoll. Die zusätzliche Implementierungsquittung entstand nach dessen Start und vor dem ersten vollständigen Block. Die Auswertung liest einen unveränderlichen Ledger-Snapshot, damit Quelldaten und gespeicherter Hash sicher dieselben Bytes bezeichnen.

## Nachweisstruktur

- `EVIDENCE_AUDIT.csv`: 450 Konfigurationen mit Qualitäts-, Artefakt-, Endpunkt-, Timing- und Energiebindung sowie getrenntem numerischem Filter.
- `FLAG_RESOLUTION.csv`: ursprüngliche Einschränkungen und die tragenden Auflösungen. Originalflags bleiben erhalten.
- `analysis/audit_inputs/` und `receipts/`: kompakte Quellbelege und vollständige Pfad-/Hashindizes. Eine Offline-Prüfung reproduziert die Auswertung der gesicherten Belege. Sie behauptet keine erneute Geräteattestierung.
- `results/calibration_*`: feste Methode, Foldparameter, Trainings-IDs, Testvorhersagen, gleiche Kandidatenmengen, exakte Zufallserwartung und Kostenabgrenzung.
- `results/mechanism/`: eingefrorene Serien, sämtliche Versuche, Rohreports und Zustandsbeobachtungen. Prozessreplikate sind von Aufgaben innerhalb eines Prozesses getrennt.
- `input/R14/`: unverändertes Übergabepaket. Einige darin enthaltene historische oder inaktive Tabellen gehören nicht zur aktiven R14-Auswertung.

Produktinstallation, vorhandene HEFs und TensorRT-Engines wurden nicht ersetzt. Es gibt keinen Push, Merge oder Release. Diagnosecode liegt im eigenen Git-Branch. Commit-ID und Diff werden unter `receipts/` gesichert. Das ZIP enthält keine Steuerungstoken der lokalen Prozessleases.

## Paketprüfung

Vor Neuberechnungen die unveränderten gelieferten Dateien prüfen:

```sh
sha256sum -c SHA256SUMS
```

`PACKAGE_CHECK.json` neben dem ZIP bestätigt die CRC-Prüfung, alle Dateihashes und die bytegleiche Kopie nach `/home/kmika/Downloads`. Die Paketdatei wird nicht in ihren eigenen Hashindex aufgenommen.
