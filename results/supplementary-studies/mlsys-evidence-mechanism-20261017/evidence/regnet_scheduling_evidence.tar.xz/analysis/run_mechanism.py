#!/usr/bin/env python3
"""Exclusive, bounded Phase B controller; default operation is offline validation.

Remote work uses the installed product SSHTransport, EvaluationRunLock and
RemoteProcessLeaseRegistry. Only frozen files below this task's remote report
directory are deployed. Existing artifacts and production sources are preserved.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import inspect
import json
import math
import os
from pathlib import Path, PurePosixPath
import random
import re
import shlex
import socket
import statistics
import stat
import sys
import time
import zipfile

SCHEMA = "mechanism-controller-v1"
VARIANTS = {"G_product": ("generic", "product"), "N_product": ("native", "product"),
            "G_single": ("generic", "single"), "N_single": ("native", "single")}
SHA = re.compile(r"[0-9a-f]{64}\Z")
IDENT = re.compile(r"[A-Za-z0-9_.-]+\Z")
EXTENSION_RULE = "primary_ratio_or_interaction_ci_includes_null"


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            result.update(block)
    return result.hexdigest()


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{time.time_ns()}.tmp")
    with temporary.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)
    descriptor = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def owned_local(root, path):
    result = (Path(root) / path).resolve()
    if not result.is_relative_to(Path(root).resolve()):
        raise ValueError("path outside task directory: " + str(path))
    return result


def relative_path(path):
    result = PurePosixPath(path)
    if result.is_absolute() or ".." in result.parts or not result.parts:
        raise ValueError("unsafe remote relative path: " + str(path))
    return str(result)


def owned_remote(base, path):
    candidate = PurePosixPath(path)
    return candidate.is_absolute() and ".." not in candidate.parts and candidate.is_relative_to(PurePosixPath(base))


def pin_valid(pin):
    return (isinstance(pin, dict) and isinstance(pin.get("path"), str)
            and PurePosixPath(pin["path"]).is_absolute() and ".." not in PurePosixPath(pin["path"]).parts
            and SHA.fullmatch(pin.get("sha256", "")) is not None)


def deterministic_schedule(case_ids, variants, blocks, seed):
    rng = random.Random(seed)
    schedule = []
    for block in blocks:
        cells = [(case, variant) for case in case_ids for variant in variants]
        rng.shuffle(cells)
        schedule.extend({"case_id": case, "variant": variant, "block": block} for case, variant in cells)
    return schedule


def local_file(root, path):
    return Path(path).resolve() if Path(path).is_absolute() else owned_local(root, path)


def check_local_pin(root, path, expected, *, max_bytes=None):
    target = local_file(root, path)
    if (not SHA.fullmatch(expected or "") or not target.is_file()
            or (max_bytes is not None and target.stat().st_size > max_bytes)
            or digest(target) != expected):
        raise ValueError("frozen local file mismatch: " + str(path))
    return target


def validate_protocol(protocol, root):
    """Read files only. No product import, lock, SSH, runtime or remote probe."""
    root = Path(root).resolve()
    if protocol.get("schema") != SCHEMA or not IDENT.fullmatch(protocol.get("series_id", "")):
        raise ValueError("invalid protocol schema or series_id")
    if not Path(protocol.get("repository", "")).is_absolute():
        raise ValueError("absolute installed product repository required")
    for key in ("profiles", "admission", "controller", "adapter"):
        pin = protocol[key]
        check_local_pin(root, pin["path"], pin["sha256"], max_bytes=2097152)
    if owned_local(root, protocol["controller"]["path"]) != Path(__file__).resolve():
        raise ValueError("protocol must pin this exact controller")
    for pin in protocol.get("local_code", []):
        check_local_pin(root, pin["path"], pin["sha256"])
    device = protocol["device"]
    expected_root = "/home/nx/Reports/" + root.name + "/" + protocol["series_id"]
    if (device.get("setup_id") != "orin_nx_hailo10_01"
            or device.get("python") != "/home/nx/venvs/hailo10/bin/python"
            or device.get("remote_root") != expected_root or not device.get("expected_identity")):
        raise ValueError("only this task's verified H10 interpreter and report directory are allowed")
    policy = device["state_policy"]
    lo, hi = policy["temperature_band_c"]
    if (not 0 <= lo < hi <= 100 or not 0 < policy["stability_delta_c"] <= 10
            or not 0 < policy["stability_gap_s"] <= 60 or not 0 < policy["max_wait_s"] <= 600
            or not 0 <= policy["min_rest_s"] <= 600 or not policy.get("power_mode")
            or not policy.get("affinity") or not policy.get("cpu_min_max_khz") or not policy.get("gpu_min_max_hz")):
        raise ValueError("bounded, explicit device state policy required")
    recipe = protocol["recipe"]
    if recipe.get("warmup_s") != 30 or recipe.get("window_s") != 60 or not 120 <= recipe.get("timeout_s", 0) <= 600:
        raise ValueError("fixed 30-second warmup, 60-second admission and bounded timeout required")
    if not protocol.get("drift_rules") or not protocol.get("primary_analysis"):
        raise ValueError("drift/exclusion and primary analysis must be declared before execution")
    deployments = {}
    for item in protocol["deploy_files"]:
        relative = relative_path(item["remote_relative"])
        if relative in deployments or relative == "PROTOCOL.json":
            raise ValueError("duplicate or reserved deployment path")
        check_local_pin(root, item["local_path"], item["sha256"], max_bytes=16777216)
        deployments[relative] = item
    adapter = protocol["adapter"]
    if deployments.get(adapter["path"], {}).get("sha256") != adapter["sha256"]:
        raise ValueError("frozen adapter must be deployed at its same relative path")
    cases = {}
    for case in protocol["cases"]:
        case_id = case["case_id"]
        if not IDENT.fullmatch(case_id) or case_id in cases or not re.fullmatch(r"b[0-9]{3}", case["cut"]):
            raise ValueError("invalid or duplicate case identity")
        for kind in ("config", "native_args"):
            path, expected = case[kind + "_path"], case[kind + "_sha256"]
            relative_path(path)
            check_local_pin(root, path, expected, max_bytes=2097152)
            if deployments.get(path, {}).get("sha256") != expected:
                raise ValueError("case config/arguments must be frozen deployed files")
        config = json.loads(owned_local(root, case["config_path"]).read_text())
        identity = config.get("identity", {})
        if (identity.get("model_id") != case["model_id"] or identity.get("setup_id") != device["setup_id"]
                or identity.get("case_id") != case["cut"]
                or config.get("task") != "classification" or config.get("energy_capture")):
            raise ValueError("case's exact product config identity/endpoint mismatch")
        if not case.get("required_artifacts") or not case.get("required_sources"):
            raise ValueError("complete artifact and product source pins required")
        pins = case["required_artifacts"] + case["required_sources"]
        if not all(pin_valid(pin) for pin in pins):
            raise ValueError("remote file requires absolute path and sha256")
        by_path = {pin["path"]: pin["sha256"] for pin in pins}
        for descriptor in [*config["expected_runtime_artifacts"].values(), config["input_binding"]["prepared_input"]]:
            if by_path.get(descriptor["path"]) != descriptor["sha256"]:
                raise ValueError("actual product config's artifact/input absent from frozen pins")
        argv = json.loads(owned_local(root, case["native_args_path"]).read_text())
        if (not isinstance(argv, list) or not all(isinstance(arg, str) for arg in argv)
                or any(arg in argv for arg in ("--build-missing-engine", "--force-rebuild-engine", "--energy-workload-only"))):
            raise ValueError("native argv must reuse existing bound artifacts")
        for flag, expected in (("--expected-hef-sha256", config["expected_runtime_artifacts"]["part1_runtime"]["sha256"]),
                               ("--expected-engine-sha256", config["expected_runtime_artifacts"]["engine"]["sha256"])):
            if argv.count(flag) != 1 or argv.index(flag) + 1 == len(argv) or argv[argv.index(flag) + 1] != expected:
                raise ValueError("native argv exact artifact guard missing: " + flag)
        for chain in ("generic", "native"):
            runner = case["runners"][chain]
            if not pin_valid(runner) or by_path.get(runner["path"]) != runner["sha256"]:
                raise ValueError("product runner not bound to frozen source manifest")
        cases[case_id] = case
    confirmatory = 0
    for phase, spec in protocol["phases"].items():
        if phase not in {"pilot", "primary", "replication", "extension"}:
            raise ValueError("unregistered phase")
        if (not spec["case_ids"] or len(set(spec["case_ids"])) != len(spec["case_ids"])
                or any(key not in cases for key in spec["case_ids"])
                or not spec["variants"] or len(set(spec["variants"])) != len(spec["variants"])
                or any(key not in VARIANTS for key in spec["variants"])
                or spec.get("mode") not in {"duration", "canary"}
                or type(spec.get("seed")) is not int or not spec["blocks"]
                or any(type(block) is not int or block < 0 for block in spec["blocks"])
                or len(set(spec["blocks"])) != len(spec["blocks"])):
            raise ValueError("invalid phase cases, variants, mode, blocks or seed")
        expected = deterministic_schedule(spec["case_ids"], spec["variants"], spec["blocks"], spec["seed"])
        if spec.get("schedule") != expected or spec.get("expected_runs") != len(expected):
            raise ValueError("phase schedule differs from frozen seeded complete blocks")
        model_cut = {(cases[key]["model_id"], cases[key]["cut"]) for key in spec["case_ids"]}
        if phase in {"primary", "extension"}:
            if (model_cut != {("regnet_x_1_6gf", "b052"), ("regnet_x_1_6gf", "b123")}
                    or set(spec["variants"]) != set(VARIANTS) or spec["mode"] != "duration"
                    or spec["blocks"] != (list(range(1, 6)) if phase == "primary" else list(range(6, 11)))
                    or len(expected) != 40):
                raise ValueError("primary/extension requires two RegNet cuts x four variants x five whole blocks")
        if phase == "replication" and (model_cut != {("resnet50", "b002"), ("resnet50", "b095")}
                or len(spec["variants"]) != 2 or spec["blocks"] != list(range(1, 6))
                or spec["mode"] != "duration" or len(expected) != 20):
            raise ValueError("replication requires two ResNet cuts x two variants x five blocks")
        if phase == "pilot" and len(expected) > 16:
            raise ValueError("pilot budget is bounded at sixteen independent processes")
        if phase != "pilot":
            confirmatory += len(expected)
    if confirmatory > 160:
        raise ValueError("confirmatory process budget exceeds160")
    if "extension" in protocol["phases"] and protocol.get("extension_trigger_rule_id") != EXTENSION_RULE:
        raise ValueError("extension must freeze the one predefined ratio/interaction CI trigger")
    return cases


def state_comparison(previous, current, policy, *, end=False):
    readings = current.get("read_only_start_state", {})
    prior = previous.get("read_only_start_state", {})
    key = "/sys/class/thermal/thermal_zone0/temp"
    def temperature(values):
        try:
            result = float(values[key]) / 1000
            return result if math.isfinite(result) else None
        except (KeyError, TypeError, ValueError):
            return None
    first, second = temperature(prior), temperature(readings)
    reasons = []
    if second is None:
        reasons.append("temperature_unknown")
    elif not end and not policy["temperature_band_c"][0] <= second <= policy["temperature_band_c"][1]:
        reasons.append("temperature_outside_predeclared_band")
    if not end and (first is None or second is None or abs(second - first) > policy["stability_delta_c"]):
        reasons.append("temperature_stability_unproven")
    cpu = [f"/sys/devices/system/cpu/cpu{core}/cpufreq/{field}" for core in policy["affinity"]
           for field in ("scaling_min_freq", "scaling_max_freq")]
    if any(str(readings.get(key)) != str(policy["cpu_min_max_khz"]) for key in cpu):
        reasons.append("CPU_frequency_configuration_differs_or_unknown")
    cpu_current = [key for key in readings if key.endswith("/scaling_cur_freq")]
    if any(str(readings[key]) != str(policy["cpu_min_max_khz"]) for key in cpu_current):
        reasons.append("CPU_current_frequency_differs")
    for key in ("/sys/class/devfreq/17000000.gpu/min_freq", "/sys/class/devfreq/17000000.gpu/max_freq"):
        if str(readings.get(key)) != str(policy["gpu_min_max_hz"]):
            reasons.append("GPU_frequency_configuration_differs_or_unknown")
            break
    current_gpu = readings.get("/sys/class/devfreq/17000000.gpu/cur_freq")
    if current_gpu is not None and str(current_gpu) != str(policy["gpu_min_max_hz"]):
        reasons.append("GPU_current_frequency_differs")
    throttle = [key for key, value in readings.items()
                if key.endswith("/type") and isinstance(value, str) and value.endswith("throttle-alert")]
    if not throttle:
        reasons.append("thermal_throttle_alert_visibility_unknown")
    for key in throttle:
        value = readings.get(key.removesuffix("/type") + "/cur_state")
        if str(value) != "0":
            reasons.append("thermal_throttle_alert_active_or_unknown:" + readings[key])
    power = readings.get("power_mode_read_only_query", {})
    if power.get("returncode") != 0 or str(policy["power_mode"]) not in power.get("output", ""):
        reasons.append("power_mode_differs_or_unknown")
    if readings.get("probe_process_cpu_affinity") != policy["affinity"]:
        reasons.append("inherited_affinity_differs_or_unknown")
    return {"comparable": not reasons, "temperature_c": second, "previous_temperature_c": first,
            "reasons": reasons, "end_temperature_descriptive": end}


def admitted(snapshot):
    return (snapshot.get("admission", {}).get("eligible") is True
            and snapshot.get("admission", {}).get("exclusive_start_permission") is True)


def batch_deploy(*, mode, remote_root, manifest, archive_path, archive_sha256):
    """Self-contained metadata probe / no-overwrite ZIP installer sent by product SSH.

    All members and existing destinations are checked before any extraction.
    Atomic no-replace links from fsynced temporary files avoid rename races.
    This function also runs against temporary local directories in offline tests.
    """
    import hashlib
    import os
    import pathlib
    import stat
    import tempfile
    import zipfile

    if mode not in {"inspect", "install"}:
        raise ValueError("unknown deployment mode")
    root = pathlib.Path(remote_root)
    if not root.is_absolute() or ".." in root.parts or len(manifest) > 2048:
        raise ValueError("invalid deployment root or file budget")

    def no_symlink_ancestors(path):
        for part in (path, *path.parents):
            if part.is_symlink():
                raise ValueError("deployment symlink preserved: " + str(part))

    no_symlink_ancestors(root)
    expected = {}
    total = 0
    for item in manifest:
        name = item["remote_relative"]
        path = pathlib.PurePosixPath(name)
        sha = item["sha256"]
        size = item["size_bytes"]
        if (not name or "\\" in name or "\x00" in name or path.is_absolute()
                or ".." in path.parts or str(path) != name or name in expected
                or len(sha) != 64 or any(char not in "0123456789abcdef" for char in sha)
                or type(size) is not int or not 0 <= size <= 16777216):
            raise ValueError("invalid deployment member declaration")
        expected[name] = item
        total += size
    if total > 67108864 or not expected:
        raise ValueError("deployment byte budget exceeded or empty manifest")
    for name in expected:
        if any(str(parent) in expected for parent in pathlib.PurePosixPath(name).parents):
            raise ValueError("deployment file/directory collision")

    def file_hash(path):
        result = hashlib.sha256()
        with path.open("rb") as stream:
            for data in iter(lambda: stream.read(1048576), b""):
                result.update(data)
        return result.hexdigest()

    missing = []
    for name, item in expected.items():
        path = root / name
        no_symlink_ancestors(path)
        try:
            info = path.lstat()
        except FileNotFoundError:
            missing.append(name)
            continue
        if (not stat.S_ISREG(info.st_mode) or info.st_size != item["size_bytes"]
                or file_hash(path) != item["sha256"]):
            raise ValueError("existing deployment file mismatch preserved: " + name)
    archive = pathlib.Path(archive_path)
    if not archive.is_absolute() or archive.parent != root or ".." in archive.parts:
        raise ValueError("archive outside own deployment root")
    no_symlink_ancestors(archive)
    final_archive = root / ("_deployment-" + archive_sha256 + ".zip")
    if len(archive_sha256) != 64 or any(char not in "0123456789abcdef" for char in archive_sha256):
        raise ValueError("invalid archive identity")
    no_symlink_ancestors(final_archive)
    for candidate in {archive, final_archive}:
        if candidate.exists() and (not candidate.is_file() or candidate.stat().st_size > 69206016
                                   or file_hash(candidate) != archive_sha256):
            raise ValueError("existing deployment archive mismatch preserved")
    if mode == "inspect":
        return {"status": "ready" if not missing else "missing", "missing": missing,
                "archive_available": final_archive.is_file(), "verified_files": len(expected) - len(missing)}
    if not archive.is_file():
        raise ValueError("declared deployment archive unavailable")
    payloads = {}
    with zipfile.ZipFile(archive) as bundle:
        infos = bundle.infolist()
        if len(infos) != len(expected) or {item.filename for item in infos} != set(expected):
            raise ValueError("ZIP member allowlist differs from frozen declarations")
        for info in infos:
            item = expected[info.filename]
            mode_bits = info.external_attr >> 16
            if (not stat.S_ISREG(mode_bits) or info.is_dir() or info.flag_bits & 1
                    or info.file_size != item["size_bytes"]
                    or info.compress_type not in {zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED}):
                raise ValueError("ZIP member type, size or encoding rejected")
            data = bundle.read(info)
            if hashlib.sha256(data).hexdigest() != item["sha256"]:
                raise ValueError("ZIP member byte hash differs from frozen declaration")
            payloads[info.filename] = data
    # No directory or member write occurs before all payloads have passed.
    root.mkdir(parents=True, exist_ok=True)
    installed = []
    for name in missing:
        target = root / name
        no_symlink_ancestors(target)
        target.parent.mkdir(parents=True, exist_ok=True)
        descriptor, temporary_name = tempfile.mkstemp(prefix=".mechanism-deploy-", dir=target.parent)
        temporary = pathlib.Path(temporary_name)
        try:
            with os.fdopen(descriptor, "wb") as stream:
                stream.write(payloads[name])
                stream.flush()
                os.fsync(stream.fileno())
            # link() is atomic and refuses an existing destination. Unlike
            # replace()/POSIX rename(), it cannot overwrite a concurrent file.
            try:
                os.link(temporary, target)
            except FileExistsError:
                no_symlink_ancestors(target)
                if not target.is_file() or file_hash(target) != expected[name]["sha256"]:
                    raise ValueError("concurrent deployment destination mismatch preserved")
            installed.append(name)
        finally:
            temporary.unlink(missing_ok=True)
    if archive != final_archive:
        try:
            os.link(archive, final_archive)
        except FileExistsError:
            no_symlink_ancestors(final_archive)
            if not final_archive.is_file() or file_hash(final_archive) != archive_sha256:
                raise ValueError("concurrent archive mismatch preserved")
        archive.unlink()
    for name in expected:
        directory = root / pathlib.PurePosixPath(name).parent
        descriptor = os.open(directory, os.O_RDONLY)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    return {"status": "installed", "installed_files": len(installed), "verified_files": len(expected),
            "archive_path": str(final_archive), "archive_sha256": archive_sha256}


class ProductRuntime:
    def __init__(self, protocol, root, protocol_sha256):
        self.protocol, self.root, self.protocol_sha256 = protocol, Path(root), protocol_sha256
        sys.path.insert(0, protocol["repository"])
        from onnx_splitpoint_tool.remote.process_lease import RemoteProcessLeaseRegistry, RemoteProcessLeaseScope
        from onnx_splitpoint_tool.remote.ssh_transport import HostConfig, SSHTransport
        from onnx_splitpoint_tool.workflow.run_control import EvaluationRunLock
        pin = protocol["admission"]
        source = importlib.util.spec_from_file_location("mechanism_bound_admission", pin["path"])
        module = importlib.util.module_from_spec(source)
        source.loader.exec_module(module)
        self.admission = module
        setup = protocol["device"]["setup_id"]
        self.owner = {"pid": os.getpid(), "run_id": protocol["series_id"],
                      "session_id": "mechanism-" + protocol_sha256,
                      "hostname": socket.gethostname(), "purpose": "authorized_mlsys_phaseB_mechanism"}
        host = module.registered_host_for_setup(Path(protocol["profiles"]["path"]), setup,
                                                repo=Path(protocol["repository"]))
        self.lock = EvaluationRunLock.for_resource("dut:" + host["host"], owner=self.owner)
        self.scope = RemoteProcessLeaseScope(protocol["series_id"], self.owner["session_id"])
        self.registry = RemoteProcessLeaseRegistry()
        self.registry.configure_journal(scope=self.scope,
            journal_dir=self.root / "receipts" / "mechanism" / protocol_sha256 / "remote_leases")
        self.transport = SSHTransport(HostConfig.from_dict(host), remote_lease_scope=self.scope,
                                      remote_lease_registry=self.registry)
        self.transport.diagnostics_dir = self.root / "receipts" / "mechanism" / protocol_sha256 / "ssh_diagnostics"

    def snapshot(self, pins):
        p, d = self.protocol, self.protocol["device"]
        return self.admission.collect_device(root=self.root, repo=Path(p["repository"]),
            profiles_path=Path(p["profiles"]["path"]), setup_id=d["setup_id"],
            required_artifacts=pins, expected_identity=d["expected_identity"], own_owner=self.owner)

    def unclean(self):
        return self.registry.cancelled or self.registry.active_count() != 0

    def reconcile(self):
        # Exact product lease identities and guardian drain token; inspect only.
        probe = """import json,os,pathlib,sys
r,s,i,t,base=sys.argv[1:]
p=(pathlib.Path(base) if base else pathlib.Path('/tmp')/('onnx_splitpoint-process-leases-%d'%os.getuid()))/r/s
state='unknown'
try:
 q=json.loads((p/(i+'.lease.json')).read_text()); assert q['token']==t and q['operation_id']==i and q['run_sha256']==r and q['session_sha256']==s
 d=p/(i+'.drained'); drained=d.is_file() and d.read_text().strip()==t
 f=pathlib.Path('/proc/%d/stat'%q['pid'])
 if f.exists():
  z=f.read_text(); a=z[z.rfind(')')+2:].split(); live=int(a[19])==q['start_time_ticks'] and a[0]!='Z'
 else: live=False
 state='active' if live else 'drained' if drained else 'unknown'
except (OSError,ValueError,KeyError,AssertionError): pass
print(json.dumps({'state':state}))
"""
        for operation in self.registry.recover_journaled_operations():
            rc, raw = self.transport.run_read_only(shlex.join(["python3", "-B", "-c", probe,
                operation.scope.run_sha256, operation.scope.session_sha256, operation.operation_id,
                operation.token, operation.scope.lease_root]), timeout_s=20)
            observation = json.loads(raw) if rc == 0 else {"state": "unknown"}
            if observation.get("state") == "drained":
                self.registry.unregister(operation, reason="remote_drained_on_resume")
        return not self.unclean()


class Controller:
    def __init__(self, root, protocol_path, *, runtime=None, sleeper=time.sleep, wall_clock=time.time):
        self.root = Path(root).resolve()
        self.protocol_path = owned_local(self.root, protocol_path)
        self.protocol_sha256 = digest(self.protocol_path)
        self.protocol = json.loads(self.protocol_path.read_text())
        self.cases = validate_protocol(self.protocol, self.root)
        self.directory = self.root / "results" / "mechanism" / self.protocol_sha256
        self.progress_path = self.directory / "PROGRESS.json"
        self.runtime, self.sleep, self.wall_clock = runtime, sleeper, wall_clock
        self._deployment_verified = False
        self.progress = {"schema": "mechanism-progress-v1", "protocol_sha256": self.protocol_sha256,
                         "series_id": self.protocol["series_id"], "attempts": [], "events": []}
        if self.progress_path.exists():
            self.progress = json.loads(self.progress_path.read_text())
            if self.progress.get("protocol_sha256") != self.protocol_sha256:
                raise ValueError("existing progress belongs to another protocol")

    def persist(self, **event):
        if event:
            self.progress["events"].append({"observed_at_utc": now(), **event})
        self.progress["updated_utc"] = now()
        atomic_json(self.progress_path, self.progress)

    def action(self, phase, cell):
        case = self.cases[cell["case_id"]]
        config = json.loads(owned_local(self.root, case["config_path"]).read_text())
        identity = {"protocol_sha256": self.protocol_sha256, "artifact_identity": config["expected_runtime_artifacts"],
                    "case_id": case["case_id"], "cut": case["cut"], "variant": cell["variant"],
                    "block": cell["block"], "phase": phase, "mode": self.protocol["phases"][phase]["mode"]}
        return {**identity, "run_id": canonical_hash(identity)}

    def snapshots(self, action, label, pins):
        value = self.runtime.snapshot(pins)
        path = self.directory / "snapshots" / f"{action['run_id']}_{label}_{time.time_ns()}.json"
        atomic_json(path, value)
        return value, str(path)

    def pins(self, case, *, staged):
        deployments = {self.remote(item["remote_relative"]) for item in self.protocol["deploy_files"]}
        pins = [pin for pin in case["required_artifacts"] + case["required_sources"]
                if staged or pin["path"] not in deployments]
        if staged:
            pins += [{"path": self.remote(item["remote_relative"]), "sha256": item["sha256"]}
                     for item in self.protocol["deploy_files"]]
            pins.append({"path": self.remote("PROTOCOL.json"), "sha256": self.protocol_sha256})
        unique = {}
        for pin in pins:
            if pin["path"] in unique and unique[pin["path"]]["sha256"] != pin["sha256"]:
                raise ValueError("conflicting frozen remote file hashes")
            unique[pin["path"]] = pin
        return list(unique.values())

    def remote(self, relative):
        return self.protocol["device"]["remote_root"] + "/" + relative_path(relative)

    def stage(self, case):
        snapshot = self.runtime.snapshot(self.pins(case, staged=False))
        if not admitted(snapshot):
            self.persist(status="deferred", reason="fresh_exclusive_admission_failed_before_staging", snapshot=snapshot)
            return False
        if self._deployment_verified:
            return True
        files = [*self.protocol["deploy_files"], {"local_path": str(self.protocol_path),
                  "remote_relative": "PROTOCOL.json", "sha256": self.protocol_sha256}]
        archive, manifest = self.deployment_archive(files)
        sha = digest(archive)
        remote_archive = self.remote("_deployment-" + sha + ".zip")
        transport = self.runtime.transport
        params = {"mode": "inspect", "remote_root": self.protocol["device"]["remote_root"],
                  "manifest": manifest, "archive_path": remote_archive, "archive_sha256": sha}
        rc, raw = transport.run_read_only(self.batch_command(params), timeout_s=60)
        if rc:
            raise ValueError("existing remote deployment mismatched or unknown; preserved: " + raw[-2048:])
        state = json.loads(raw)
        if state.get("status") == "ready":
            self._deployment_verified = True
            self.persist(status="stage_verified", archive_sha256=sha, file_count=len(manifest))
            return True
        if state.get("status") != "missing":
            raise ValueError("unknown batch deployment inspection state")
        self.persist(status="stage_started", archive_path=remote_archive, archive_sha256=sha,
                     file_count=len(manifest), missing_files=len(state["missing"]))
        if state.get("archive_available") is not True:
            rc, raw = transport.run("mkdir -p " + shlex.quote(self.protocol["device"]["remote_root"]), timeout_s=20)
            if rc or self.runtime.unclean():
                self.persist(status="stage_failed", returncode=rc, output_tail=raw[-2048:])
                return False
            upload_path = remote_archive + f".upload.{os.getpid()}.{time.time_ns()}.partial"
            rc, raw = transport.scp_upload(str(archive), upload_path, timeout_s=120)
            if rc:
                self.persist(status="stage_failed", returncode=rc, output_tail=raw[-2048:])
                return False
            params["archive_path"] = upload_path
        params["mode"] = "install"
        rc, raw = transport.run(self.batch_command(params), timeout_s=120)
        self.persist(status="stage_completed" if rc == 0 else "stage_failed", archive_path=remote_archive,
                     archive_sha256=sha, file_count=len(manifest), returncode=rc, output_tail=raw[-2048:])
        if rc or self.runtime.unclean():
            return False
        installed = json.loads(raw)
        if installed.get("verified_files") != len(manifest) or installed.get("status") != "installed":
            raise ValueError("batch installer did not verify every frozen file")
        self._deployment_verified = True
        return True

    @staticmethod
    def batch_command(params):
        code = "import json,sys\n" + inspect.getsource(batch_deploy)
        code += "\nprint(json.dumps(batch_deploy(**json.loads(sys.argv[1])),sort_keys=True))\n"
        return shlex.join(["python3", "-B", "-c", code, json.dumps(params, separators=(",", ":"))])

    def deployment_archive(self, files):
        """Deterministic metadata, sorted members and pinned bytes; no extra files."""
        self.directory.mkdir(parents=True, exist_ok=True)
        temporary = self.directory / f".deployment.{os.getpid()}.{time.time_ns()}.zip.partial"
        manifest = []
        with zipfile.ZipFile(temporary, "x", compression=zipfile.ZIP_STORED) as bundle:
            for item in sorted(files, key=lambda value: value["remote_relative"]):
                relative = relative_path(item["remote_relative"])
                path = check_local_pin(self.root, item["local_path"], item["sha256"], max_bytes=16777216)
                data = path.read_bytes()
                if hashlib.sha256(data).hexdigest() != item["sha256"]:
                    raise ValueError("frozen source changed during ZIP construction")
                info = zipfile.ZipInfo(relative, date_time=(1980, 1, 1, 0, 0, 0))
                info.create_system = 3
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                info.compress_type = zipfile.ZIP_STORED
                bundle.writestr(info, data)
                manifest.append({"remote_relative": relative, "sha256": item["sha256"], "size_bytes": len(data)})
        sha = digest(temporary)
        final = self.directory / ("deployment-" + sha + ".zip")
        if final.exists():
            if digest(final) != sha:
                raise ValueError("existing local deployment archive mismatch preserved")
            temporary.unlink()
        else:
            temporary.replace(final)
        return final, manifest

    def before_run(self, action, case):
        policy = self.protocol["device"]["state_policy"]
        finishes = [row.get("finished_wall_time") for row in self.progress["attempts"] if row.get("finished_wall_time")]
        if finishes:
            remaining = max(0, max(finishes) + policy["min_rest_s"] - self.wall_clock())
            if remaining:
                self.persist(status="fixed_rest_wait", run_id=action["run_id"], remaining_s=remaining)
            while remaining > 0:
                self.sleep(min(30, remaining))
                remaining = max(0, max(finishes) + policy["min_rest_s"] - self.wall_clock())
        deadline = self.wall_clock() + policy["max_wait_s"]
        prior, _ = self.snapshots(action, "stability", self.pins(case, staged=True))
        while True:
            if not admitted(prior):
                return None
            self.sleep(min(policy["stability_gap_s"], max(0, deadline - self.wall_clock())))
            current, path = self.snapshots(action, "before", self.pins(case, staged=True))
            state = state_comparison(prior, current, policy)
            if not admitted(current):
                return None
            if state["comparable"]:
                return current, path, state
            self.persist(status="state_wait", run_id=action["run_id"], state_check=state)
            if self.wall_clock() >= deadline:
                return None
            prior = current

    def argv(self, action, remote_out):
        case, device = self.cases[action["case_id"]], self.protocol["device"]
        chain, schedule = VARIANTS[action["variant"]]
        runner = case["runners"][chain]
        return [device["python"], "-B", self.remote(self.protocol["adapter"]["path"]),
            "--chain", chain, "--schedule", schedule, "--mode", action["mode"],
            "--product-runner", runner["path"], "--expected-runner-sha256", runner["sha256"],
            "--config", self.remote(case["config_path"]), "--native-args-json", self.remote(case["native_args_path"]),
            "--protocol", self.remote("PROTOCOL.json"), "--protocol-sha256", self.protocol_sha256,
            "--block", str(action["block"]), "--warmup-duration-s", str(self.protocol["recipe"]["warmup_s"]),
            "--out", remote_out]

    def validate_report(self, action, report):
        case = self.cases[action["case_id"]]
        config = json.loads(owned_local(self.root, case["config_path"]).read_text())
        chain, schedule = VARIANTS[action["variant"]]
        identity = {"protocol_sha256": self.protocol_sha256, "identity": config["identity"],
                    "artifact_identity": config["expected_runtime_artifacts"], "chain": chain,
                    "schedule": schedule, "block": action["block"], "mode": action["mode"]}
        expected = {**identity, "run_id": canonical_hash(identity), "schema": "mechanism-product-workers-v1",
                    "status": "complete", "adapter_sha256": self.protocol["adapter"]["sha256"],
                    "config_sha256": case["config_sha256"], "diagnostic_adapter": True, "energy_measured": False,
                    "product_runner_sha256": case["runners"][chain]["sha256"]}
        if any(report.get(key) != value for key, value in expected.items()):
            raise ValueError("remote result identity/source/config differs from frozen series")
        sources = {item["path"]: item["sha256"] for item in case["required_sources"]}
        loaded = report.get("loaded_source_hashes")
        if not loaded or any(sources.get(path) != sha for path, sha in loaded.items()):
            raise ValueError("loaded product source missing or changed against frozen source closure")
        if report.get("worker_cpu_affinity") != self.protocol["device"]["state_policy"]["affinity"]:
            raise ValueError("actual worker CPU affinity absent or differs from frozen policy")
        if action["mode"] == "canary":
            if report.get("canary_pass") is not True or len(report.get("sequence", [])) != 32:
                raise ValueError("mixed input canary has no complete32-task identity proof")
        else:
            count, seconds, fps = (report.get(key) for key in ("completed_work_units", "measurement_time_seconds", "completed_task_fps"))
            if (type(count) is not int or count <= 0 or not isinstance(seconds, (int, float))
                    or not math.isfinite(seconds) or seconds < 60 or not isinstance(fps, (int, float))
                    or not math.isfinite(fps) or not math.isclose(fps, count / seconds, rel_tol=1e-9)
                    or report.get("admission_window_seconds") != 60 or report.get("warmup_duration_s") != 30
                    or report.get("accepted_work_drained") is not True):
                raise ValueError("duration result violates full60-second admission plus accepted-task drain")
        return report

    def collect(self, action, attempt):
        remote = attempt["remote_out"] + "/result.json"
        if not owned_remote(self.protocol["device"]["remote_root"], remote):
            raise ValueError("result outside task remote directory")
        transport = self.runtime.transport
        probe = "import pathlib,hashlib,json,sys;p=pathlib.Path(sys.argv[1]);assert p.is_file() and not p.is_symlink();assert p.stat().st_size<=8388608;print(json.dumps({'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))"
        rc, raw = transport.run_read_only(shlex.join(["python3", "-B", "-c", probe, remote]), timeout_s=20)
        if rc:
            return None
        sha = json.loads(raw)["sha256"]
        local = self.directory / "reports" / (attempt["attempt_id"] + ".json")
        if local.exists():
            if digest(local) != sha:
                raise ValueError("existing report differs from remote; both preserved")
        else:
            local.parent.mkdir(parents=True, exist_ok=True)
            temporary = local.with_suffix(".partial")
            rc, _ = transport.scp_download(remote, str(temporary), timeout_s=30)
            if rc:
                return None
            if digest(temporary) != sha:
                raise ValueError("downloaded result hash mismatch")
            temporary.replace(local)
        report = self.validate_report(action, json.loads(local.read_text()))
        if action["mode"] == "canary":
            self.collect_canary_arrays(attempt, report)
        return report, str(local), sha

    def collect_canary_arrays(self, attempt, report):
        """Keep the small mixed-input reference tensors in the local evidence pack."""
        manifest = report.get("reference_manifest", [])
        if len(manifest) != 2:
            raise ValueError("canary must preserve both distinct input/reference tensor manifests")
        tensors = []
        for item in manifest:
            tensors.append({"path": item["input_path"], "sha256": item["input_sha256"]})
            tensors.extend(item["outputs"].values())
        saved, names = [], set()
        for tensor in tensors:
            remote = tensor["path"]
            if not owned_remote(attempt["remote_out"], remote) or not SHA.fullmatch(tensor["sha256"]):
                raise ValueError("canary tensor is not pinned inside this exact process output directory")
            name = PurePosixPath(remote).name
            if name in names:
                raise ValueError("duplicate canary tensor filename")
            names.add(name)
            probe = "import pathlib,hashlib,json,sys;p=pathlib.Path(sys.argv[1]);assert p.is_file() and not p.is_symlink();assert p.stat().st_size<=4194304;print(hashlib.sha256(p.read_bytes()).hexdigest())"
            rc, raw = self.runtime.transport.run_read_only(shlex.join(["python3", "-B", "-c", probe, remote]), timeout_s=20)
            if rc or raw.strip() != tensor["sha256"]:
                raise ValueError("canary tensor missing or changed")
            local = self.directory / "reports" / (attempt["attempt_id"] + "_canary") / name
            local.parent.mkdir(parents=True, exist_ok=True)
            if not local.exists():
                temporary = local.with_suffix(".partial")
                rc, _ = self.runtime.transport.scp_download(remote, str(temporary), timeout_s=30)
                if rc or digest(temporary) != tensor["sha256"]:
                    raise ValueError("canary tensor download failed or changed")
                temporary.replace(local)
            elif digest(local) != tensor["sha256"]:
                raise ValueError("existing local canary tensor changed; preserved")
            saved.append({**tensor, "local_path": str(local)})
        attempt["canary_tensors"] = saved

    def reusable(self, action, attempt):
        if attempt.get("status") != "completed" or attempt.get("protocol_sha256") != self.protocol_sha256:
            return False
        path = owned_local(self.root, attempt["report_path"])
        if digest(path) != attempt["report_sha256"]:
            raise ValueError("completed immutable report changed")
        self.validate_report(action, json.loads(path.read_text()))
        return True

    def finish(self, action, attempt, collected, *, recovered=False):
        if collected is None:
            attempt.update(status="uncertain", reason="started_process_has_no_complete_matching_report")
            self.persist(status="run_uncertain", run_id=action["run_id"])
            return False
        report, path, sha = collected
        if attempt.get("after_snapshot"):
            end_path = attempt["after_snapshot"]
            end = json.loads(owned_local(self.root, end_path).read_text())
        else:
            end, end_path = self.snapshots(action, "after", self.pins(self.cases[action["case_id"]], staged=True))
        state = self.end_state(end)
        attempt.update(status="completed", report_path=path, report_sha256=sha, recovered=recovered,
                       finished_at_utc=now(), finished_wall_time=self.wall_clock(), after_snapshot=end_path,
                       state_check=state, included=state["comparable"], completed_task_fps=report.get("completed_task_fps"))
        self.persist(status="run_completed", run_id=action["run_id"])
        return state["comparable"]

    def end_state(self, end):
        state = state_comparison(end, end, self.protocol["device"]["state_policy"], end=True)
        if not admitted(end):
            state["reasons"].append("end_competing_work_or_admission_problem")
            state["comparable"] = False
        return state

    def perform(self, action, *, retry_cause=None):
        attempts = [row for row in self.progress["attempts"] if row["run_id"] == action["run_id"]]
        if attempts:
            latest = attempts[-1]
            if self.reusable(action, latest):
                return latest.get("included") is True
            if latest.get("status") in {"started", "hardware_finished", "uncertain"}:
                return self.finish(action, latest, self.collect(action, latest), recovered=True)
            if latest.get("status") == "failed":
                if not retry_cause or retry_cause.get("run_id") != action["run_id"]:
                    return False
                if (retry_cause.get("cause_corrected") is not True or not retry_cause.get("reason")
                        or retry_cause.get("protocol_sha256") != self.protocol_sha256
                        or retry_cause.get("technical_error") not in {"launcher", "transport", "implementation"}):
                    raise ValueError("failed process retry requires documented corrected technical cause under same frozen protocol")
        is_pilot = action["phase"] == "pilot"
        if sum((row["phase"] == "pilot") == is_pilot for row in self.progress["attempts"]) >= (16 if is_pilot else 160):
            raise ValueError("global160 confirmation or16 pilot process bound exhausted")
        case = self.cases[action["case_id"]]
        before = self.before_run(action, case)
        if before is None:
            self.persist(status="deferred", run_id=action["run_id"], reason="fresh_admission_or_start_state_failed")
            return False
        snapshot, path, state = before
        attempt_id = action["run_id"] + f"_attempt{len(attempts) + 1:02d}"
        remote_out = self.remote("runs/" + action["phase"] + "/" + attempt_id)
        argv = self.argv(action, remote_out)
        attempt = {**action, "attempt_id": attempt_id, "status": "started", "started_at_utc": now(),
                   "before_snapshot": path, "before_state_check": state, "remote_out": remote_out,
                   "argv": argv, "retry_cause": retry_cause if attempts else None}
        self.progress["attempts"].append(attempt)
        self.persist(status="run_started", run_id=action["run_id"])
        command = "cd " + shlex.quote(self.protocol["device"]["remote_root"]) + " && exec " + shlex.join(argv)
        rc, output = self.runtime.transport.run(command, timeout_s=self.protocol["recipe"]["timeout_s"],
            env={"PYTHONDONTWRITEBYTECODE": "1", "PYTHONPATH": self.protocol["device"]["remote_root"]})
        attempt.update(status="hardware_finished", returncode=rc, finished_wall_time=self.wall_clock())
        log_path = self.directory / "logs" / (attempt_id + ".log")
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_path.write_text(output[-65536:])
        attempt["log_path"] = str(log_path)
        self.persist(status="hardware_finished", run_id=action["run_id"], returncode=rc)
        if self.runtime.unclean():
            attempt.update(status="uncertain", reason="own_remote_cleanup_unproven")
            self.persist(status="cleanup_unproven", run_id=action["run_id"])
            return False
        end, end_path = self.snapshots(action, "after", self.pins(case, staged=True))
        attempt.update(after_snapshot=end_path, state_check=self.end_state(end))
        self.persist(status="end_metadata_recorded", run_id=action["run_id"])
        if rc:
            attempt.update(status="failed", reason="remote_process_nonzero_exit_preserved")
            self.persist(status="run_failed", run_id=action["run_id"], returncode=rc)
            return False
        return self.finish(action, attempt, self.collect(action, attempt))

    def check_extension(self, receipt):
        if (not receipt or receipt.get("protocol_sha256") != self.protocol_sha256
                or receipt.get("rule_id") != EXTENSION_RULE or receipt.get("extend") is not True):
            raise ValueError("extension requires explicit matching trigger receipt")
        complete, rates = {}, {}
        for cell in self.protocol["phases"]["primary"]["schedule"]:
            action = self.action("primary", cell)
            attempts = [row for row in self.progress["attempts"] if row["run_id"] == action["run_id"]]
            if not attempts or not self.reusable(action, attempts[-1]) or not attempts[-1].get("included"):
                raise ValueError("extension requires five complete admitted primary blocks")
            attempt = attempts[-1]
            complete[action["run_id"]] = attempt["report_sha256"]
            report = json.loads(owned_local(self.root, attempt["report_path"]).read_text())
            rates[(cell["block"], action["variant"], action["cut"])] = report["completed_task_fps"]
        if receipt.get("primary_report_sha256") != complete:
            raise ValueError("extension trigger receipt does not bind all40 exact primary reports")
        values = {variant: [math.log(rates[(block, variant, "b123")] / rates[(block, variant, "b052")])
                            for block in range(1, 6)] for variant in VARIANTS}
        values["interaction"] = [values["N_product"][i] - values["G_product"][i]
                                  - values["N_single"][i] + values["G_single"][i] for i in range(5)]
        intervals = {}
        for key in ("G_product", "N_product", "interaction"):
            mean = statistics.mean(values[key])
            half = 2.7764451051977987 * statistics.stdev(values[key]) / math.sqrt(5)
            intervals[key] = [mean - half, mean + half]
        if not any(lo <= 0 <= hi for lo, hi in intervals.values()):
            raise ValueError("predefined complete-block extension trigger is false")
        return intervals

    def execute(self, phase, *, resume=False, retry_cause=None, extension_trigger=None):
        validate_protocol(self.protocol, self.root)  # Recheck all local pins immediately before use.
        if digest(self.protocol_path) != self.protocol_sha256:
            raise ValueError("protocol changed since controller construction")
        if phase not in self.protocol["phases"]:
            raise ValueError("phase not frozen in protocol")
        if self.progress["attempts"] and not resume:
            raise ValueError("existing attempts require explicit --resume")
        if phase == "extension":
            intervals = self.check_extension(extension_trigger)
            self.persist(status="extension_trigger_verified", log_ratio_intervals95=intervals,
                         trigger_receipt_sha256=canonical_hash(extension_trigger))
        if self.runtime is None:
            self.runtime = ProductRuntime(self.protocol, self.root, self.protocol_sha256)
        acquired = False
        try:
            self.runtime.lock.acquire()
            acquired = True
            self.persist(status="physical_product_lock_acquired", phase=phase)
            if not self.runtime.reconcile():
                self.persist(status="deferred", reason="prior_own_remote_lease_active_or_unknown")
                return False
            spec = self.protocol["phases"][phase]
            for case_id in spec["case_ids"]:
                if not self.stage(self.cases[case_id]):
                    return False
            for cell in spec["schedule"]:
                # Fail closed if local protocol, code or config changes mid-series.
                validate_protocol(self.protocol, self.root)
                if digest(self.protocol_path) != self.protocol_sha256:
                    raise ValueError("frozen protocol changed during series")
                if not self.perform(self.action(phase, cell), retry_cause=retry_cause):
                    return False
            self.persist(status="phase_completed", phase=phase)
            return True
        finally:
            if acquired:
                try:
                    if self.runtime.unclean():
                        self.runtime.lock.commit_quarantine_fence({**self.runtime.owner,
                            "reason": "mechanism_own_remote_cleanup_unproven", "protocol_sha256": self.protocol_sha256})
                finally:
                    self.runtime.lock.release()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--protocol", default="PROTOCOL.json")
    parser.add_argument("--run", action="store_true", help="execute explicitly frozen bounded hardware phase")
    parser.add_argument("--phase", choices=["pilot", "primary", "replication", "extension"], default="pilot")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--retry-cause", type=Path, help="task-owned JSON corrected technical failure evidence")
    parser.add_argument("--extension-trigger", type=Path, help="explicit receipt binding all40 primary reports and predefined CI trigger")
    args = parser.parse_args(argv)
    controller = Controller(args.root, args.protocol)
    if not args.run:
        print(json.dumps({"status": "VALIDATED_OFFLINE", "hardware_execution": False,
            "protocol_sha256": controller.protocol_sha256,
            "phase_runs": {key: spec["expected_runs"] for key, spec in controller.protocol["phases"].items()}}))
        return 0
    retry = json.loads(owned_local(args.root, args.retry_cause).read_text()) if args.retry_cause else None
    trigger = json.loads(owned_local(args.root, args.extension_trigger).read_text()) if args.extension_trigger else None
    complete = controller.execute(args.phase, resume=args.resume, retry_cause=retry, extension_trigger=trigger)
    print(json.dumps({"status": "PHASE_COMPLETED" if complete else "STOPPED_WITH_EVIDENCE",
                      "phase": args.phase, "progress_path": str(controller.progress_path)}))
    return 0 if complete else 2


if __name__ == "__main__":
    raise SystemExit(main())
