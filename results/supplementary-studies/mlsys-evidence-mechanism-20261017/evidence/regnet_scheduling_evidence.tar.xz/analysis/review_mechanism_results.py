#!/usr/bin/env python3
"""Independent, stdlib-only mechanism review from immutable ledgers/raw reports.

This program neither imports nor invokes summarize_mechanism.py. It computes
Student t quantiles from the incomplete beta function, rather than its t table.
Use --progress with a phase-exit snapshot, never an active PROGRESS.json.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import random
import re
import sys

RULE = "primary_ratio_or_interaction_ci_includes_null"
VARIANTS = {"G_product": ("generic", "product"), "N_product": ("native", "product"),
            "G_single": ("generic", "single"), "N_single": ("native", "single")}
SHA = re.compile(r"[a-f0-9]{64}\Z")


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def read_json(path, expected=None):
    raw = Path(path).read_bytes()  # The parsed bytes and their digest are identical.
    sha = hashlib.sha256(raw).hexdigest()
    if expected is not None and sha != expected:
        raise ValueError("hash_mismatch:" + str(path))
    return json.loads(raw), sha


def near(a, b):
    return math.isclose(float(a), float(b), rel_tol=1e-11, abs_tol=1e-11)


def beta_fraction(a, b, x):
    """Lentz continued fraction for the regularized incomplete beta function."""
    tiny, tolerance = 1e-300, 3e-14
    qab, qap, qam = a+b, a+1, a-1
    c, d = 1.0, 1-qab*x/qap
    d = 1/max(abs(d), tiny) * (1 if d >= 0 else -1)
    h = d
    for m in range(1, 10001):
        for aa in (m*(b-m)*x/((qam+2*m)*(a+2*m)),
                   -(a+m)*(qab+m)*x/((a+2*m)*(qap+2*m))):
            d = 1+aa*d
            if abs(d) < tiny:
                d = tiny
            c = 1+aa/c
            if abs(c) < tiny:
                c = tiny
            d = 1/d
            change = d*c
            h *= change
        if abs(change-1) < tolerance:
            return h
    raise ArithmeticError("incomplete_beta_did_not_converge")


def beta_regularized(a, b, x):
    if x <= 0:
        return 0.0
    if x >= 1:
        return 1.0
    front = math.exp(math.lgamma(a+b)-math.lgamma(a)-math.lgamma(b)
                     +a*math.log(x)+b*math.log1p(-x))
    if x < (a+1)/(a+b+2):
        return front*beta_fraction(a, b, x)/a
    return 1-front*beta_fraction(b, a, 1-x)/b


def student_cdf(value, df):
    tail = 0.5*beta_regularized(df/2, 0.5, df/(df+value*value))
    return 1-tail if value >= 0 else tail


def student_quantile95(df):
    low, high = 0.0, 1.0
    while student_cdf(high, df) < 0.975:
        high *= 2
    for _ in range(90):
        middle = (low+high)/2
        if student_cdf(middle, df) < 0.975:
            low = middle
        else:
            high = middle
    return (low+high)/2


def statistics_from_logs(values):
    n = len(values)
    if n < 2:
        raise ValueError("at_least_two_independent_blocks_required")
    mean = math.fsum(values)/n
    sd = math.sqrt(math.fsum((value-mean)**2 for value in values)/(n-1))
    se = sd/math.sqrt(n)
    t = student_quantile95(n-1)
    lo, hi = mean-t*se, mean+t*se
    return {"n_blocks": n, "mean_log": mean, "sd_log": sd, "se_log": se,
            "df": n-1, "t95": t, "log_ci95_low": lo, "log_ci95_high": hi,
            "geometric_mean": math.exp(mean), "ci95_low": math.exp(lo),
            "ci95_high": math.exp(hi), "ci_includes_null": lo <= 0 <= hi}


def resolve_task(root, value, original):
    path = Path(value)
    if not path.is_absolute():
        result = root/path
    elif path.is_relative_to(root):
        result = path
    else:
        prefixes = {Path(home)/"Reports"/name for home in ("/home/kmika", "/home/nx")
                    for name in (original, root.name)}
        found = [prefix for prefix in prefixes if path.is_relative_to(prefix)]
        if len(found) != 1:
            raise ValueError("path_not_in_known_task_root:" + str(path))
        result = root/path.relative_to(found[0])
    result = result.resolve()
    if not result.is_relative_to(root):
        raise ValueError("path_escapes_task_root")
    return result


def schedule_check(protocol, cases):
    if set(protocol["phases"]) != {"primary", "extension", "replication"}:
        raise ValueError("confirmatory_three_phase_protocol_required_no_pilot_pool")
    for phase, spec in protocol["phases"].items():
        blocks = list(range(6, 11)) if phase == "extension" else list(range(1, 6))
        expected_variants = set(VARIANTS) if phase != "replication" else {"N_product", "N_single"}
        identities = {(cases[key]["model_id"], cases[key]["cut"]) for key in spec["case_ids"]}
        expected_identities = ({("resnet50", "b002"), ("resnet50", "b095")} if phase == "replication"
                               else {("regnet_x_1_6gf", "b052"), ("regnet_x_1_6gf", "b123")})
        if (spec["blocks"] != blocks or spec["mode"] != "duration"
                or set(spec["variants"]) != expected_variants or len(spec["variants"]) != len(expected_variants)
                or len(spec["case_ids"]) != 2 or identities != expected_identities
                or type(spec["seed"]) is not int):
            raise ValueError("frozen_design_drift:" + phase)
        rng, expected = random.Random(spec["seed"]), []
        for block in blocks:
            order = [(c, v) for c in spec["case_ids"] for v in spec["variants"]]
            rng.shuffle(order)
            expected.extend({"case_id": c, "variant": v, "block": block} for c, v in order)
        if spec["schedule"] != expected or spec["expected_runs"] != len(expected):
            raise ValueError("seeded_schedule_drift:" + phase)


def validate_raw(protocol, protocol_sha, case, config, action, report):
    chain, schedule = VARIANTS[action["variant"]]
    runtime_id = {"protocol_sha256": protocol_sha, "identity": config["identity"],
                  "artifact_identity": config["expected_runtime_artifacts"], "chain": chain,
                  "schedule": schedule, "block": action["block"], "mode": "duration"}
    required = {**runtime_id, "run_id": canonical(runtime_id), "schema": "mechanism-product-workers-v1",
                "status": "complete", "adapter_sha256": protocol["adapter"]["sha256"],
                "config_sha256": case["config_sha256"], "diagnostic_adapter": True,
                "energy_measured": False, "product_runner_sha256": case["runners"][chain]["sha256"],
                "worker_cpu_affinity": protocol["device"]["state_policy"]["affinity"],
                "accepted_work_drained": True, "warmup_duration_s": 30, "admission_window_seconds": 60}
    errors = ["raw_identity:"+key for key, value in required.items() if report.get(key) != value]
    loaded, allowed = report.get("loaded_source_hashes"), {s["path"]: s["sha256"] for s in case["required_sources"]}
    if not loaded or not isinstance(loaded, dict) or any(not isinstance(sha, str) or not SHA.fullmatch(sha)
          or allowed.get(path) != sha for path, sha in loaded.items()):
        errors.append("loaded_source_pin_mismatch")
    count, duration, rate = [report.get(k) for k in ("completed_work_units", "measurement_time_seconds", "completed_task_fps")]
    if (type(count) is not int or count <= 0 or type(duration) not in (int, float)
            or not math.isfinite(duration) or duration < 60 or type(rate) not in (int, float)
            or not math.isfinite(rate) or rate <= 0 or not near(rate, count/duration)):
        errors.append("invalid_full_makespan_rate_or_count")
    if (type(report.get("pid")) is not int or type(report.get("started_time_ns")) is not int
            or type(report.get("finished_time_ns")) is not int
            or report["finished_time_ns"] <= report["started_time_ns"]):
        errors.append("missing_independent_process_identity")
    return errors


def cells_from_reports(protocol, protocol_sha, progress, root, original):
    cases = {case["case_id"]: case for case in protocol["cases"]}
    if len(cases) != len(protocol["cases"]):
        raise ValueError("duplicate_case_id")
    schedule_check(protocol, cases)
    configs = {}
    for key, case in cases.items():
        config, _ = read_json(resolve_task(root, case["config_path"], original), case["config_sha256"])
        if config["identity"]["model_id"] != case["model_id"] or config["identity"]["case_id"] != case["cut"]:
            raise ValueError("config_case_mismatch:" + key)
        configs[key] = config
    by_run, rows, known, raw_processes, schedule_positions = {}, [], set(), {}, {}
    for index, attempt in enumerate(progress["attempts"]):
        by_run.setdefault(attempt.get("run_id"), []).append((index, attempt))
    for phase, spec in protocol["phases"].items():
        for schedule_position, cell in enumerate(spec["schedule"]):
            case, config = cases[cell["case_id"]], configs[cell["case_id"]]
            identity = {"protocol_sha256": protocol_sha, "artifact_identity": config["expected_runtime_artifacts"],
                        "case_id": case["case_id"], "cut": case["cut"], "variant": cell["variant"],
                        "block": cell["block"], "phase": phase, "mode": "duration"}
            action = {**identity, "run_id": canonical(identity)}
            run_id = action["run_id"]
            if run_id in known:
                raise ValueError("duplicate_scheduled_run_id")
            known.add(run_id)
            schedule_positions[run_id] = schedule_position
            attempts, errors = by_run.get(run_id, []), []
            row = {**cell, "phase": phase, "model": case["model_id"], "cut": case["cut"],
                   "run_id": run_id, "included": False, "attempt_count": len(attempts), "errors": errors}
            if not attempts:
                errors.append("not_started")
            else:
                for i, (_, attempt) in enumerate(attempts):
                    if attempt.get("attempt_id") != f"{run_id}_attempt{i+1:02d}":
                        errors.append("attempt_sequence_changed")
                    if any(attempt.get(k) != v for k, v in action.items()):
                        errors.append("attempt_identity_changed")
                    if i:
                        cause = attempt.get("retry_cause") or {}
                        if (attempts[i-1][1].get("status") != "failed" or cause.get("cause_corrected") is not True
                                or cause.get("technical_error") not in {"launcher", "transport", "implementation"}
                                or cause.get("run_id") != run_id or cause.get("protocol_sha256") != protocol_sha
                                or not cause.get("reason")):
                            errors.append("inadmissible_retry_lineage")
                last = attempts[-1][1]
                row.update(last_status=last.get("status"), last_attempt_id=last.get("attempt_id"))
                if last.get("status") != "completed" or last.get("included") is not True:
                    errors.append("last_attempt_not_admitted_completed")
                if last.get("state_check", {}).get("comparable") is not True:
                    errors.append("end_state_not_comparable")
                if last.get("before_state_check", {}).get("comparable") is not True:
                    errors.append("before_state_not_comparable")
                if last.get("status") == "completed":
                    try:
                        sha = last["report_sha256"]
                        if not isinstance(sha, str) or not SHA.fullmatch(sha):
                            raise ValueError("malformed_report_hash")
                        report, _ = read_json(resolve_task(root, last["report_path"], original), sha)
                        errors.extend(validate_raw(protocol, protocol_sha, case, config, action, report))
                        row.update(report_sha256=sha, report_path=last["report_path"],
                                   completed_work_units=report["completed_work_units"],
                                   measurement_time_seconds=report["measurement_time_seconds"],
                                   completed_task_fps=report["completed_work_units"]/report["measurement_time_seconds"],
                                   pid=report.get("pid"), started_time_ns=report.get("started_time_ns"),
                                   finished_time_ns=report.get("finished_time_ns"), progress_index=attempts[-1][0])
                        raw_processes.setdefault((report.get("pid"), report.get("started_time_ns")), []).append(row)
                    except (OSError, ValueError, KeyError, TypeError, ZeroDivisionError) as error:
                        errors.append("raw_report_invalid:"+str(error))
            rows.append(row)
    for repeated in raw_processes.values():
        if len(repeated) > 1:
            for row in repeated:
                row["errors"].append("reused_process_identity")
    first_observed, observed_order, latest_position, delayed_retries = set(), {}, {}, set()
    for attempt in progress["attempts"]:
        key = attempt.get("run_id")
        if key in known and key not in first_observed:
            first_observed.add(key)
            observed_order.setdefault(attempt["phase"], []).append(schedule_positions[key])
            latest_position[attempt["phase"]] = schedule_positions[key]
        elif key in known and schedule_positions[key] != latest_position.get(attempt["phase"]):
            delayed_retries.add(key)
    for phase, positions in observed_order.items():
        if positions != list(range(len(positions))):
            for row in rows:
                if row["phase"] == phase:
                    row["errors"].append("observed_execution_order_differs_from_frozen_schedule_prefix")
    for row in rows:
        if row["run_id"] in delayed_retries:
            row["errors"].append("retry_after_advancing_frozen_schedule_violates_stop_on_failure")
    previous = None
    for row in sorted((r for r in rows if "progress_index" in r), key=lambda r: r["progress_index"]):
        if (previous is not None and type(row.get("started_time_ns")) is int
                and type(previous.get("finished_time_ns")) is int
                and row["started_time_ns"] < previous["finished_time_ns"]):
            row["errors"].append("raw_process_chronology_overlaps_or_reverses")
            previous["errors"].append("raw_process_chronology_overlaps_or_reverses")
        previous = row
    for row in rows:
        row["included"] = not row["errors"]
    unknown = [i for i, attempt in enumerate(progress["attempts"]) if attempt.get("run_id") not in known]
    return rows, unknown


def paired_statistics(cells, phase, spec):
    selected = [r for r in cells if r["phase"] == phase]
    phase_info = {"phase": phase, "expected_cells": len(spec["schedule"]),
                  "admitted_cells": sum(r["included"] for r in selected),
                  "missing_or_excluded_cells": [r for r in selected if not r["included"]],
                  "complete": all(r["included"] for r in selected)}
    if not phase_info["complete"]:
        return [], [], phase_info  # No premature partial-series scientific result.
    early, late = ("b002", "b095") if phase == "replication" else ("b052", "b123")
    all_blocks, grouped = [], {}
    for block in spec["blocks"]:
        rates = {(r["variant"], r["cut"]): r["completed_task_fps"] for r in selected if r["block"] == block}
        logs = {v: math.log(rates[v, late])-math.log(rates[v, early]) for v in spec["variants"]}
        if "N_single" in logs:
            logs["native_schedule_effect"] = logs["N_product"]-logs["N_single"]
        if "G_single" in logs:
            logs["generic_schedule_effect"] = logs["G_product"]-logs["G_single"]
            logs["interaction"] = ((logs["N_product"]-logs["G_product"])
                                   -(logs["N_single"]-logs["G_single"]))
        for contrast, value in logs.items():
            all_blocks.append({"cohort": phase, "block": block, "model": selected[0]["model"],
                               "contrast": contrast, "numerator_cut": late, "denominator_cut": early,
                               "log_ratio": value, "ratio": math.exp(value)})
            grouped.setdefault(contrast, []).append(value)
    summary = [{"cohort": phase, "model": selected[0]["model"], "contrast": contrast,
                **statistics_from_logs(values)} for contrast, values in grouped.items()]
    return all_blocks, summary, phase_info


def authorization(protocol_sha, progress, trigger, primary_reports, receipt_path):
    if not trigger.get("extend"):
        return {"authorized": False, "reason": "original_five_block_trigger_not_true"}
    if receipt_path is None:
        return {"authorized": False, "reason": "exact_controller_trigger_receipt_required"}
    receipt, file_sha = read_json(receipt_path)
    intervals = receipt.get("log_ratio_intervals95", {})
    if (receipt.get("protocol_sha256") != protocol_sha or receipt.get("rule_id") != RULE
            or receipt.get("extend") is not True or receipt.get("primary_report_sha256") != primary_reports
            or set(intervals) != set(trigger["log_ratio_intervals95"])
            or any(len(intervals[k]) != 2 or not all(near(x, y) for x, y in zip(intervals[k], expected))
                   for k, expected in trigger["log_ratio_intervals95"].items())):
        return {"authorized": False, "reason": "trigger_receipt_does_not_bind_independent_primary_result"}
    receipt_hash = canonical(receipt)
    events = []
    for event in progress.get("events", []):
        candidate = event.get("log_ratio_intervals95", {})
        if (event.get("status") == "extension_trigger_verified"
                and event.get("trigger_receipt_sha256") == receipt_hash and set(candidate) == set(intervals)
                and all(len(candidate[k]) == 2 and all(near(x, y) for x, y in zip(candidate[k], intervals[k]))
                        for k in intervals)):
            events.append(event)
    return {"authorized": bool(events), "reason": "exact_receipt_and_controller_event" if events else "matching_controller_event_missing",
            "receipt_file_sha256": file_sha, "receipt_canonical_sha256": receipt_hash,
            "matching_event_count": len(events)}


def historical_separate(protocol, root, original):
    source = protocol.get("historical_source_manifest")
    if not source:
        return {"status": "not_provided", "pooled": False}
    data, sha = read_json(resolve_task(root, source["path"], original), source["sha256"])
    by_model, cut_records = {}, []
    for pair in data["pairs"]:
        native = sorted(row["raw"]["completed_frames"]*1000/row["raw"]["makespan_ms"]
                        for row in pair["native_repeats"])
        generic = sorted(row["completed_task_count"]/row["measured_makespan_seconds"] for row in pair["generic_repeats"])
        if len(native) != 3 or len(generic) != 3:
            raise ValueError("historical_exact_three_repeats_required")
        if not near(native[1], pair["native_fps_median"]) or not near(generic[1], pair["generic_fps_median"]):
            raise ValueError("historical_manifest_median_mismatch")
        row = {"model": pair["model"], "cut": pair["case"], "native_median_fps": native[1],
               "generic_median_fps": generic[1], "native_repeat_count": 3, "generic_repeat_count": 3}
        cut_records.append(row)
        by_model.setdefault(pair["model"], {})[pair["case"]] = row
    ratios = []
    for model, pair in by_model.items():
        first, second = ("b002", "b095") if model == "resnet50" else ("b052", "b123")
        ratios.append({"model": model, "numerator_cut": second, "denominator_cut": first,
                       "generic_ratio_of_historical_medians": pair[second]["generic_median_fps"]/pair[first]["generic_median_fps"],
                       "native_ratio_of_historical_medians": pair[second]["native_median_fps"]/pair[first]["native_median_fps"]})
    return {"status": "separate_historical_three_repeat_medians", "pooled": False,
            "source_sha256": sha, "cuts": cut_records, "ratios": ratios,
            "note": "Embedded original observations only; historical device conditions are not matched by this current-code intervention."}


def compare_analysis(summary, block_rows, prefix, protocol_sha=None, progress_sha=None):
    if prefix is None:
        return {"status": "not_requested"}
    prefix = Path(prefix)
    published_json, _ = read_json(Path(str(prefix)+".json"))
    if (published_json.get("protocol_sha256") != protocol_sha
            or published_json.get("progress_sha256") != progress_sha):
        raise ValueError("published_analysis_protocol_or_snapshot_pin_mismatch")
    with Path(str(prefix)+"_summary.csv").open(newline="") as stream:
        published = list(csv.DictReader(stream))
    count = 0
    largest_t_delta = 0.0
    fields = ["n_blocks", "mean_log", "sd_log", "se_log", "df", "t95", "log_ci95_low", "log_ci95_high",
              "geometric_mean", "ci95_low", "ci95_high"]
    for row in summary:
        matches = [r for r in published if all(r[k] == str(row[k]) for k in ("cohort", "model", "contrast"))]
        if len(matches) != 1:
            raise ValueError("published_summary_key_missing_or_duplicated")
        observed_t = float(matches[0]["t95"])
        largest_t_delta = max(largest_t_delta, abs(observed_t-row["t95"]))
        # Check the independently computed mean/SE and the verified tabulated
        # critical value together. This avoids a false mismatch from the tiny
        # df9 table approximation propagating into an interval at large SE.
        low = row["mean_log"]-observed_t*row["se_log"]
        high = row["mean_log"]+observed_t*row["se_log"]
        interval_check = {"log_ci95_low": low, "log_ci95_high": high,
                          "ci95_low": math.exp(low), "ci95_high": math.exp(high)}
        for key in fields:
            equal = (math.isclose(float(matches[0][key]), row[key], abs_tol=1e-9, rel_tol=0)
                     if key == "t95" else near(matches[0][key], interval_check.get(key, row[key])))
            if not equal:
                raise ValueError("published_summary_numeric_mismatch:"+str((row["cohort"], row["contrast"], key)))
            count += 1
    expected_keys = {(r["cohort"], r["model"], r["contrast"]) for r in summary}
    observed_keys = {(r["cohort"], r["model"], r["contrast"]) for r in published if int(r["n_blocks"]) >= 5}
    if observed_keys != expected_keys:
        raise ValueError("published_complete_summary_series_not_independently_authorized")
    with Path(str(prefix)+"_blocks.csv").open(newline="") as stream:
        published_blocks = list(csv.DictReader(stream))
    for row in block_rows:
        matches = [r for r in published_blocks if r["phase"] == row["cohort"] and r["model"] == row["model"]
                   and r["contrast"] == row["contrast"] and int(r["block"]) == row["block"]]
        if len(matches) != 1 or not near(matches[0]["log_ratio"], row["log_ratio"]) or not near(matches[0]["ratio"], row["ratio"]):
            raise ValueError("published_block_numeric_mismatch")
        count += 2
    pins = {}
    for suffix in (".json", "_summary.csv", "_blocks.csv"):
        path = Path(str(prefix)+suffix)
        pins[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
    return {"status": "PASS", "numeric_values_checked": count, "published_sha256": pins,
            "maximum_tabulated_t95_difference": largest_t_delta,
            "CI_comparison": "independent_mean_and_SE_with_independently_verified_published_critical_value",
            "independent_output_CI_uses_exact_inverse_CDF": True}


def review(protocol_path, progress_path, root=None, extension_receipt=None, analysis_prefix=None):
    protocol_path, progress_path = Path(protocol_path).resolve(), Path(progress_path).resolve()
    root = Path(root).resolve() if root else protocol_path.parent
    if progress_path.name == "PROGRESS.json":
        raise ValueError("active_ledger_forbidden_use_immutable_phase_exit_snapshot")
    protocol, protocol_sha = read_json(protocol_path)
    progress, progress_sha = read_json(progress_path)
    if (protocol.get("schema") != "mechanism-controller-v1" or progress.get("schema") != "mechanism-progress-v1"
            or progress.get("protocol_sha256") != protocol_sha or protocol.get("extension_trigger_rule_id") != RULE
            or protocol.get("pilot_results_in_confirmatory_estimates") is not False):
        raise ValueError("snapshot_protocol_or_frozen_rule_mismatch")
    original = Path(protocol["device"]["remote_root"]).parent.name
    cells, unknown = cells_from_reports(protocol, protocol_sha, progress, root, original)
    if unknown:
        raise ValueError("unregistered_or_pilot_attempts_in_confirmatory_ledger:"+str(unknown))
    blocks, summaries, phases = [], [], []
    for phase, spec in protocol["phases"].items():
        block_rows, rows, status = paired_statistics(cells, phase, spec)
        phases.append(status)
        blocks.extend(block_rows)
        summaries.extend(rows)
    primary_complete = next(p["complete"] for p in phases if p["phase"] == "primary")
    primary = {r["contrast"]: r for r in summaries if r["cohort"] == "primary"}
    trigger = {"extend": None, "status": "five_complete_primary_blocks_required", "rule_id": RULE}
    primary_hashes = {r["run_id"]: r["report_sha256"] for r in cells if r["phase"] == "primary" and r["included"]}
    if primary_complete:
        intervals = {key: [primary[key]["log_ci95_low"], primary[key]["log_ci95_high"]]
                     for key in ("G_product", "N_product", "interaction")}
        trigger.update(extend=any(lo <= 0 <= hi for lo, hi in intervals.values()), status="evaluated_original_five_blocks",
                       log_ratio_intervals95=intervals, primary_report_sha256=primary_hashes)
    auth = authorization(protocol_sha, progress, trigger, primary_hashes, extension_receipt)
    extension_complete = next(p["complete"] for p in phases if p["phase"] == "extension")
    combined = bool(auth["authorized"] and extension_complete)
    if combined:
        for contrast in primary:
            values = [r["log_ratio"] for r in blocks if r["cohort"] in {"primary", "extension"} and r["contrast"] == contrast]
            if len(values) != 10:
                raise ValueError("authorized_combination_requires_ten_distinct_fixed_blocks")
            summaries.append({"cohort": "primary_extension_combined", "model": "regnet_x_1_6gf",
                              "contrast": contrast, **statistics_from_logs(values)})
    extension_attempts = [a for a in progress["attempts"] if a.get("phase") == "extension"]
    invalid_extension = bool(extension_attempts and not auth["authorized"])
    if not primary_complete:
        blocks, summaries = [], []  # Do not publish a premature primary verdict.
    final_ready = primary_complete and next(p["complete"] for p in phases if p["phase"] == "replication")
    final_ready = final_ready and (trigger["extend"] is False or combined) and not invalid_extension
    report = {"schema": "mechanism-independent-review-v1", "status": "PASS_final" if final_ready else
              "PASS_primary_final_pending" if primary_complete and not invalid_extension else
              "FAIL_unauthorized_extension" if invalid_extension else "PENDING_no_primary_verdict",
              "reviewer_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "protocol_sha256": protocol_sha, "progress_snapshot_sha256": progress_sha,
              "progress_snapshot_path": str(progress_path), "independent_statistics": True,
              "sealed_analyzer_imported_or_invoked": False, "hardware_or_SSH": False,
              "student_t_method": "independent_incomplete_beta_CDF_bisection_0.975_quantile",
              "phases": phases, "cells": cells, "all_attempts": progress["attempts"],
              "block_ratios": blocks, "summaries": summaries, "original_five_block_extension_trigger": trigger,
              "extension_authorization": auth, "combined_ten_blocks_included": combined,
              "pilots_pooled": False, "historical": historical_separate(protocol, root, original),
              "replication_scope": "Native-only ResNet product/single intervention; no full Generic/Native rank-reversal replication",
              "limitations": ["Nominal t intervals, no sequential/simultaneous coverage guarantee from optional extension",
                              "Whole-chain intervention does not isolate copies/layout/language or reconstruct the historical cause",
                              "Required immutable snapshot is a caller assertion; this offline program cannot know whether its source controller has exited"]}
    report["published_analysis_comparison"] = compare_analysis(summaries, blocks, analysis_prefix, protocol_sha, progress_sha)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--progress", type=Path, required=True)
    parser.add_argument("--root", type=Path)
    parser.add_argument("--extension-receipt", type=Path)
    parser.add_argument("--analysis-prefix", type=Path, help="Optional read-only comparison to existing analyzer CSVs")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = review(args.protocol, args.progress, args.root, args.extension_receipt, args.analysis_prefix)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False)+"\n")
    print(json.dumps({"status": result["status"], "protocol_sha256": result["protocol_sha256"],
                      "progress_snapshot_sha256": result["progress_snapshot_sha256"],
                      "combined_ten_blocks_included": result["combined_ten_blocks_included"]}))
    return int(result["status"].startswith("FAIL"))


if __name__ == "__main__":
    sys.exit(main())
