#!/usr/bin/env python3
"""CPU-only synthetic process evidence tests; no real report is a fixture."""
import importlib.util
import json
import math
from pathlib import Path
import statistics
import shutil
import sys
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import summarize_mechanism as analysis


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2)+'\n')


def fixture(root, *, null_generic=False, with_extension=False):
    variants = list(analysis.VARIANTS)
    cases = []
    for cut in ('b052', 'b123'):
        case_id = 'regnet_' + cut
        config = {'identity': {'model_id': 'regnet_x_1_6gf', 'case_id': cut,
                               'setup_id': 'orin_nx_hailo10_01'},
                  'expected_runtime_artifacts': {'engine': {'path': '/remote/'+cut+'.engine', 'sha256': 'a'*64},
                                                 'part1_runtime': {'path': '/remote/'+cut+'.hef', 'sha256': 'b'*64}}}
        config_path = root/'inputs'/f'{case_id}.json'
        write(config_path, config)
        cases.append({'case_id': case_id, 'model_id': 'regnet_x_1_6gf', 'cut': cut,
            'config_path': str(config_path.relative_to(root)), 'config_sha256': analysis.digest(config_path),
            'required_sources': [{'path': '/remote/source.py', 'sha256': 'c'*64}],
            'runners': {'generic': {'sha256': 'd'*64}, 'native': {'sha256': 'e'*64}}})
    schedule = analysis.deterministic_schedule([c['case_id'] for c in cases], variants, list(range(1,6)), 20261017)
    protocol = {'schema': 'mechanism-controller-v1', 'series_id': 'synthetic',
        'adapter': {'sha256': 'f'*64}, 'cases': cases,
        'device': {'state_policy': {'affinity': [0, 1]},
                   'remote_root': '/home/nx/Reports/'+root.name+'/synthetic'},
        'extension_trigger_rule_id': analysis.RULE,
        'phases': {'primary': {'schedule': schedule, 'expected_runs': 40,
            'case_ids': [c['case_id'] for c in cases], 'variants': variants,
            'blocks': [1, 2, 3, 4, 5], 'mode': 'duration', 'seed': 20261017}}}
    if with_extension:
        extension = {**protocol['phases']['primary'], 'blocks': [6, 7, 8, 9, 10], 'seed': 20261018}
        extension['schedule'] = analysis.deterministic_schedule(extension['case_ids'], variants, extension['blocks'], extension['seed'])
        protocol['phases']['extension'] = extension
    protocol_path = root/'PROTOCOL.json'
    write(protocol_path, protocol)
    protocol_sha = analysis.digest(protocol_path)
    base_logs = {'G_product': 0 if null_generic else -.4, 'N_product': .8,
                 'G_single': -.5, 'N_single': -.3}
    perturbation = [-.02, -.01, 0, .01, .02]
    attempts = []
    all_cells = [(phase, cell) for phase, spec in protocol['phases'].items() for cell in spec['schedule']]
    for phase, cell in all_cells:
        case = next(c for c in cases if c['case_id'] == cell['case_id'])
        config = analysis.load_json(root/case['config_path'])
        action = analysis.action_for(protocol, protocol_sha, case, config, phase, cell)
        chain, policy = analysis.VARIANTS[cell['variant']]
        fps = 100 * (math.exp(base_logs[cell['variant']] + perturbation[(cell['block']-1)%5]) if case['cut']=='b123' else 1)
        count = math.ceil(fps * 60.05)
        identity = {'protocol_sha256': protocol_sha, 'identity': config['identity'],
            'artifact_identity': config['expected_runtime_artifacts'], 'chain': chain,
            'schedule': policy, 'block': cell['block'], 'mode': 'duration'}
        report = {**identity, 'run_id': analysis.canonical_hash(identity),
            'schema': 'mechanism-product-workers-v1', 'status': 'complete',
            'adapter_sha256': protocol['adapter']['sha256'], 'config_sha256': case['config_sha256'],
            'diagnostic_adapter': True, 'energy_measured': False,
            'product_runner_sha256': case['runners'][chain]['sha256'],
            'loaded_source_hashes': {'/remote/source.py': 'c'*64}, 'worker_cpu_affinity': [0, 1],
            'completed_work_units': count, 'measurement_time_seconds': count/fps,
            'completed_task_fps': fps, 'admission_window_seconds': 60,
            'warmup_duration_s': 30, 'accepted_work_drained': True}
        report_path = root/'reports'/(action['run_id']+'.json')
        write(report_path, report)
        attempts.append({**action, 'attempt_id': action['run_id']+'_attempt01',
            'status': 'completed', 'included': True, 'state_check': {'comparable': True, 'reasons': []},
            'report_path': str(report_path), 'report_sha256': analysis.digest(report_path)})
    progress = {'schema': 'mechanism-progress-v1', 'protocol_sha256': protocol_sha,
                'series_id': 'synthetic', 'attempts': attempts, 'events': []}
    progress_path = root/'results/mechanism'/protocol_sha/'PROGRESS.json'
    write(progress_path, progress)
    if with_extension:
        data = analysis.read_data(protocol_path)
        _, summaries, _ = analysis.analyze_blocks(data)
        receipt = analysis.extension_receipt(data, summaries)
        progress['events'].append({'status': 'extension_trigger_verified',
            'log_ratio_intervals95': receipt['log_ratio_intervals95'],
            'trigger_receipt_sha256': analysis.canonical_hash(receipt)})
        write(progress_path, progress)
    return protocol_path, progress_path, protocol, progress


class MechanismAnalysisTests(unittest.TestCase):
    def test_forty_processes_geomean_sd_t_ci_and_fixed_interaction(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            protocol, progress, _, _ = fixture(root)
            receipt_path = root/'analysis_output/extension.json'
            report = analysis.summarize(protocol, root/'analysis_output/summary', extension_path=receipt_path, figure=False)
            rows = {r['contrast']: r for r in report['summaries']}
            self.assertEqual(report['status'], 'complete')
            self.assertEqual(rows['G_product']['n_blocks'], 5)
            self.assertAlmostEqual(rows['G_product']['geometric_mean'], math.exp(-.4), places=12)
            sd = statistics.stdev([-.02, -.01, 0, .01, .02])
            self.assertAlmostEqual(rows['G_product']['sd_log'], sd, places=12)
            self.assertAlmostEqual(rows['G_product']['log_ci95_low'], -.4-analysis.T95[4]*sd/math.sqrt(5), places=12)
            self.assertAlmostEqual(rows['interaction']['mean_log'], 1, places=12)
            receipt = analysis.load_json(receipt_path)
            self.assertFalse(receipt['extend'])
            self.assertEqual(len(receipt['primary_report_sha256']), 40)

    def test_trigger_receipt_accepted_by_actual_controller_check(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            protocol_path, _, protocol, progress = fixture(root, null_generic=True)
            report = analysis.summarize(protocol_path, root/'out/summary', figure=False)
            receipt = report['extension_trigger']
            self.assertTrue(receipt['extend'])
            # Importing this controller defines orchestration only. No product
            # runtime is constructed and no execute/stage/probe method is used.
            spec = importlib.util.spec_from_file_location('mechanism_controller_analysis_test', HERE/'run_mechanism.py')
            controller_module = importlib.util.module_from_spec(spec)
            sys.modules[spec.name] = controller_module
            spec.loader.exec_module(controller_module)
            controller = controller_module.Controller.__new__(controller_module.Controller)
            controller.root, controller.protocol = root, protocol
            controller.protocol_sha256 = analysis.digest(protocol_path)
            controller.cases = {c['case_id']: c for c in protocol['cases']}
            controller.progress = progress
            expected = controller.check_extension(receipt)
            for key, interval in expected.items():
                for actual, target in zip(receipt['log_ratio_intervals95'][key], interval):
                    self.assertAlmostEqual(actual, target, places=14)

    def test_failed_latest_attempt_excludes_whole_block_without_zero(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            protocol, progress_path, _, progress = fixture(root)
            last = {**progress['attempts'][-1], 'attempt_id': progress['attempts'][-1]['run_id']+'_attempt02',
                    'status': 'failed', 'included': False, 'reason': 'synthetic failure'}
            progress['attempts'].append(last)
            write(progress_path, progress)
            report = analysis.summarize(protocol, root/'out/summary', figure=False)
            self.assertEqual(report['status'], 'partial')
            self.assertTrue(all(r['n_blocks']==4 for r in report['summaries']))
            self.assertIsNone(report['extension_trigger']['extend'])
            import csv
            with (root/'out/summary_blocks.csv').open() as stream:
                rows = list(csv.DictReader(stream))
            self.assertTrue(all(r['ratio']=='' for r in rows if r['block']=='5'))
            with (root/'out/summary_attempts.csv').open() as stream:
                attempts = list(csv.DictReader(stream))
            self.assertEqual(len(attempts), 41)

    def test_changed_report_hash_is_excluded_and_remaining_sources_unchanged(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            protocol, _, _, progress = fixture(root)
            path = Path(progress['attempts'][0]['report_path'])
            raw = analysis.load_json(path)
            raw['completed_task_fps'] *= 2
            write(path, raw)
            data = analysis.read_data(protocol)
            self.assertIn('raw_report_hash_mismatch', '|'.join(data['cells'][0]['exclusion_reasons']))
            blocks, summaries, _ = analysis.analyze_blocks(data)
            self.assertTrue(all(r['n_blocks']==4 for r in summaries))
            self.assertTrue(all(r['log_ratio'] is None for r in blocks if r['block']==1))

    def test_no_progress_and_plot_are_explicitly_pending(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            protocol, progress_path, _, _ = fixture(root)
            progress_path.unlink()
            report = analysis.summarize(protocol, root/'out/summary', figure=True)
            self.assertEqual(report['status'], 'no_confirmatory_data')
            self.assertTrue(all(r['geometric_mean'] is None for r in report['summaries']))
            self.assertTrue((root/'out/summary.svg').is_file())
            self.assertTrue((root/'out/summary.pdf').is_file())

    def test_one_block_has_no_invented_standard_deviation_or_ci(self):
        result = analysis.log_summary([math.log(2)])
        self.assertEqual(result['geometric_mean'], 2)
        self.assertIsNone(result['sd_log'])
        self.assertIsNone(result['ci95_low'])
        empty = analysis.log_summary([])
        self.assertIsNone(empty['geometric_mean'])

    def test_pilot_canary_never_enters_throughput_or_primary_estimates(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            protocol_path, _, protocol, _ = fixture(root)
            primary = protocol['phases'].pop('primary')
            primary.update(mode='canary', blocks=[0], schedule=analysis.deterministic_schedule(
                primary['case_ids'], primary['variants'], [0], primary['seed']), expected_runs=8)
            protocol['phases']['pilot'] = primary
            write(protocol_path, protocol)
            report = analysis.summarize(protocol_path, root/'out/summary', figure=False)
            self.assertEqual(report['status'], 'no_confirmatory_data')
            self.assertEqual(report['summaries'], [])
            self.assertEqual(report['phases'][0]['phase'], 'pilot')
            self.assertFalse(report['phases'][0]['required_for_series_completion'])

    def test_authorized_extension_adds_ten_block_df9_preserves_original_fives(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            protocol, progress_path, _, progress = fixture(root, null_generic=True, with_extension=True)
            report = analysis.summarize(protocol, root/'out/summary', figure=False)
            combined = [r for r in report['summaries'] if r['cohort']=='primary_extension_combined']
            self.assertEqual(len(combined), 7)
            self.assertTrue(all(r['n_blocks']==10 and r['df']==9 for r in combined))
            self.assertTrue(all(r['n_blocks']==5 for r in report['summaries'] if r['cohort'] in {'primary','extension'}))
            self.assertTrue(report['combined_extension']['included'])
            self.assertEqual(report['status'], 'complete')
            progress['events'] = []
            write(progress_path, progress)
            without_auth = analysis.summarize(protocol, root/'out/without_auth', figure=False)
            self.assertFalse(without_auth['combined_extension']['included'])
            self.assertFalse(any(r['cohort']=='primary_extension_combined' for r in without_auth['summaries']))

    def test_review_zip_can_be_extracted_to_renamed_directory(self):
        with tempfile.TemporaryDirectory() as td:
            old_root = Path(td)/'original_task'
            old_root.mkdir()
            protocol, progress_path, _, progress = fixture(old_root)
            for attempt in progress['attempts']:
                relative = Path(attempt['report_path']).relative_to(old_root)
                attempt['report_path'] = str(Path('/home/kmika/Reports/original_task')/relative)
            write(progress_path, progress)
            renamed = Path(td)/'arbitrary_extraction_name'
            shutil.copytree(old_root, renamed)
            shutil.rmtree(old_root)
            report = analysis.summarize(renamed/'PROTOCOL.json', renamed/'out/summary', figure=False)
            self.assertEqual(report['status'], 'complete')
            self.assertTrue(all(r['n_blocks']==5 for r in report['summaries']))

    def test_successful_selective_or_undocumented_retry_excludes_whole_block(self):
        for prior_status in ('completed', 'failed'):
            with self.subTest(prior=prior_status), tempfile.TemporaryDirectory() as td:
                root = Path(td)
                protocol, progress_path, _, progress = fixture(root)
                old = progress['attempts'][0]
                new = {**old, 'attempt_id': old['run_id']+'_attempt02'}
                old['status'] = prior_status
                old['included'] = prior_status == 'completed'
                progress['attempts'].append(new)
                write(progress_path, progress)
                data = analysis.read_data(protocol)
                reasons = '|'.join(data['cells'][0]['exclusion_reasons'])
                self.assertIn('retry_lineage', reasons)
                _, summaries, _ = analysis.analyze_blocks(data)
                self.assertTrue(all(r['n_blocks']==4 for r in summaries))

    def test_malformed_matrix_and_unseeded_order_are_rejected(self):
        for mutation in ('matrix', 'order'):
            with self.subTest(mutation=mutation), tempfile.TemporaryDirectory() as td:
                root = Path(td)
                protocol_path, _, protocol, _ = fixture(root)
                schedule = protocol['phases']['primary']['schedule']
                if mutation == 'matrix':
                    schedule[0] = dict(schedule[1])
                else:
                    schedule[0], schedule[1] = schedule[1], schedule[0]
                write(protocol_path, protocol)
                with self.assertRaisesRegex(ValueError, 'frozen_seeded_full_cartesian'):
                    analysis.read_data(protocol_path)


if __name__ == '__main__':
    unittest.main()
