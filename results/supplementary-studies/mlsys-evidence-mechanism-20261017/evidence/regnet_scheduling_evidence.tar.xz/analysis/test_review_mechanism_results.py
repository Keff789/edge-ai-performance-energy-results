#!/usr/bin/env python3
"""Offline independent-review tests. No product or sealed analyzer imports."""
import copy
import csv
import json
import math
from pathlib import Path
import random
import shutil
import tempfile
import unittest

import review_mechanism_results as reviewer


class IndependentReviewTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.protocol = {"schema": "mechanism-controller-v1", "pilot_results_in_confirmatory_estimates": False,
                         "extension_trigger_rule_id": reviewer.RULE, "adapter": {"sha256": "a"*64},
                         "device": {"remote_root": "/home/nx/Reports/original_task/confirmation_v1",
                                    "state_policy": {"affinity": [0, 1]}}, "cases": [], "phases": {}}
        for model, cut in [("regnet_x_1_6gf", "b052"), ("regnet_x_1_6gf", "b123"),
                           ("resnet50", "b002"), ("resnet50", "b095")]:
            key = model+"_"+cut
            config = {"identity": {"model_id": model, "case_id": cut},
                      "expected_runtime_artifacts": {"engine": {"sha256": "e"*64, "path": "/device/engine"}}}
            path = self.root/(key+".json")
            path.write_text(json.dumps(config))
            _, sha = reviewer.read_json(path)
            self.protocol["cases"].append({"case_id": key, "model_id": model, "cut": cut,
                "config_path": path.name, "config_sha256": sha,
                "required_sources": [{"path": "/device/source.py", "sha256": "b"*64}],
                "runners": {"generic": {"sha256": "c"*64}, "native": {"sha256": "d"*64}}})
        for phase in ["primary", "extension", "replication"]:
            spec = {"case_ids": [c["case_id"] for c in self.protocol["cases"]
                                  if c["model_id"] == ("resnet50" if phase == "replication" else "regnet_x_1_6gf")],
                    "variants": ["N_product", "N_single"] if phase == "replication" else list(reviewer.VARIANTS),
                    "blocks": list(range(6, 11)) if phase == "extension" else list(range(1, 6)),
                    "mode": "duration", "seed": 20261017}
            rng, schedule = random.Random(spec["seed"]), []
            for block in spec["blocks"]:
                cells = [(c, v) for c in spec["case_ids"] for v in spec["variants"]]
                rng.shuffle(cells)
                schedule.extend({"case_id": c, "variant": v, "block": block} for c, v in cells)
            spec.update(schedule=schedule, expected_runs=len(schedule))
            self.protocol["phases"][phase] = spec
        self.protocol_path = self.root/"PROTOCOL.json"
        self.protocol_path.write_text(json.dumps(self.protocol))
        _, self.protocol_sha = reviewer.read_json(self.protocol_path)
        self.progress = {"schema": "mechanism-progress-v1", "protocol_sha256": self.protocol_sha,
                         "attempts": [], "events": []}
        self.serial = 0

    def tearDown(self):
        self.temp.cleanup()

    def add_phase(self, phase, trigger=True):
        cases = {c["case_id"]: c for c in self.protocol["cases"]}
        for cell in self.protocol["phases"][phase]["schedule"]:
            case = cases[cell["case_id"]]
            config, _ = reviewer.read_json(self.root/case["config_path"])
            identity = {"protocol_sha256": self.protocol_sha,
                        "artifact_identity": config["expected_runtime_artifacts"], "case_id": case["case_id"],
                        "cut": case["cut"], "variant": cell["variant"], "block": cell["block"],
                        "phase": phase, "mode": "duration"}
            action = {**identity, "run_id": reviewer.canonical(identity)}
            chain, schedule = reviewer.VARIANTS[cell["variant"]]
            raw_identity = {"protocol_sha256": self.protocol_sha, "identity": config["identity"],
                            "artifact_identity": config["expected_runtime_artifacts"], "chain": chain,
                            "schedule": schedule, "block": cell["block"], "mode": "duration"}
            ratios = {"G_product": 1 if trigger else 0.8, "G_single": 1,
                      "N_product": 3, "N_single": 1 if trigger else 2}
            count = int(1000*ratios[cell["variant"]]) if case["cut"] in {"b123", "b095"} else 1000
            self.serial += 1
            report = {**raw_identity, "run_id": reviewer.canonical(raw_identity),
                      "schema": "mechanism-product-workers-v1", "status": "complete", "adapter_sha256": "a"*64,
                      "config_sha256": case["config_sha256"], "diagnostic_adapter": True, "energy_measured": False,
                      "product_runner_sha256": case["runners"][chain]["sha256"], "worker_cpu_affinity": [0, 1],
                      "accepted_work_drained": True, "warmup_duration_s": 30, "admission_window_seconds": 60,
                      "loaded_source_hashes": {"/device/source.py": "b"*64}, "completed_work_units": count,
                      "measurement_time_seconds": 60.0, "completed_task_fps": count/60.0,
                      "pid": self.serial, "started_time_ns": 100000+self.serial,
                      "finished_time_ns": 100001+self.serial}
            report_path = self.root/(action["run_id"]+".json")
            report_path.write_text(json.dumps(report))
            _, sha = reviewer.read_json(report_path)
            self.progress["attempts"].append({**action, "attempt_id": action["run_id"]+"_attempt01",
                "status": "completed", "included": True, "state_check": {"comparable": True},
                "before_state_check": {"comparable": True}, "report_path": report_path.name, "report_sha256": sha})

    def run_review(self, receipt=None):
        path = self.root/"immutable_snapshot.json"
        path.write_text(json.dumps(self.progress))
        return reviewer.review(self.protocol_path, path, extension_receipt=receipt)

    def test_student_t_independent_quantiles_and_moments(self):
        self.assertAlmostEqual(reviewer.student_quantile95(1), math.tan(math.pi*0.475), places=10)
        self.assertAlmostEqual(reviewer.student_quantile95(4), 2.7764451051977987, places=12)
        # The sealed SciPy-style df9 tabulation differs from the mathematical
        # inverse CDF by 5.6e-11; both give the same reported precision.
        self.assertAlmostEqual(reviewer.student_quantile95(9), 2.2621571628540993, places=9)
        result = reviewer.statistics_from_logs([1, 2, 3, 4, 5])
        self.assertEqual(result["mean_log"], 3)
        self.assertAlmostEqual(result["sd_log"], math.sqrt(2.5))
        self.assertAlmostEqual(result["se_log"], math.sqrt(0.5))

    def test_published_df9_interval_approximation_and_source_pins(self):
        independent = {"cohort": "primary_extension_combined", "model": "regnet_x_1_6gf", "contrast": "N_product",
                       **reviewer.statistics_from_logs([float(i) for i in range(-5, 5)])}
        published = dict(independent)
        published["t95"] = 2.2621571628540993
        for side, sign in [("low", -1), ("high", 1)]:
            value = published["mean_log"]+sign*published["t95"]*published["se_log"]
            published["log_ci95_"+side] = value
            published["ci95_"+side] = math.exp(value)
        prefix = self.root/"published"
        Path(str(prefix)+".json").write_text(json.dumps({"protocol_sha256": "p", "progress_sha256": "q"}))
        with Path(str(prefix)+"_summary.csv").open("w", newline="") as stream:
            writer = csv.DictWriter(stream, list(published))
            writer.writeheader()
            writer.writerow(published)
        Path(str(prefix)+"_blocks.csv").write_text("phase,model,contrast,block,log_ratio,ratio\n")
        result = reviewer.compare_analysis([independent], [], prefix, "p", "q")
        self.assertEqual(result["status"], "PASS")
        self.assertGreater(result["maximum_tabulated_t95_difference"], 5e-11)
        with self.assertRaisesRegex(ValueError, "protocol_or_snapshot_pin_mismatch"):
            reviewer.compare_analysis([independent], [], prefix, "p", "wrong")

    def test_incomplete_primary_withholds_all_statistics(self):
        self.add_phase("primary")
        self.progress["attempts"].pop()
        report = self.run_review()
        self.assertEqual(report["status"], "PENDING_no_primary_verdict")
        self.assertEqual(report["summaries"], [])
        self.assertIsNone(report["original_five_block_extension_trigger"]["extend"])

    def test_primary_trigger_false_and_native_only_final(self):
        self.add_phase("primary", trigger=False)
        self.add_phase("replication")
        report = self.run_review()
        self.assertEqual(report["status"], "PASS_final")
        self.assertFalse(report["original_five_block_extension_trigger"]["extend"])
        self.assertFalse(report["combined_ten_blocks_included"])
        replication = [r for r in report["summaries"] if r["cohort"] == "replication"]
        self.assertEqual({r["contrast"] for r in replication}, {"N_product", "N_single", "native_schedule_effect"})
        self.assertTrue(all(r["n_blocks"] == 5 and r["df"] == 4 for r in replication))

    def test_authorized_extension_combined_ten_and_exact_receipt(self):
        self.add_phase("primary")
        first = self.run_review()["original_five_block_extension_trigger"]
        receipt = {**first, "protocol_sha256": self.protocol_sha}
        path = self.root/"trigger.json"
        path.write_text(json.dumps(receipt))
        self.progress["events"].append({"status": "extension_trigger_verified",
            "trigger_receipt_sha256": reviewer.canonical(receipt),
            "log_ratio_intervals95": first["log_ratio_intervals95"]})
        self.add_phase("extension")
        self.add_phase("replication")
        report = self.run_review(path)
        self.assertEqual(report["status"], "PASS_final")
        combined = [r for r in report["summaries"] if r["cohort"] == "primary_extension_combined"]
        self.assertEqual(len(combined), 7)
        self.assertTrue(all(r["n_blocks"] == 10 and r["df"] == 9 for r in combined))
        self.progress["events"][0]["trigger_receipt_sha256"] = "f"*64
        self.assertEqual(self.run_review(path)["status"], "FAIL_unauthorized_extension")

    def test_unauthorized_extension_does_not_combine(self):
        self.add_phase("primary")
        self.add_phase("extension")
        report = self.run_review()
        self.assertEqual(report["status"], "FAIL_unauthorized_extension")
        self.assertFalse(report["combined_ten_blocks_included"])

    def test_completed_selective_retry_invalidates_primary(self):
        self.add_phase("primary")
        second = copy.deepcopy(self.progress["attempts"][0])
        second["attempt_id"] = second["run_id"]+"_attempt02"
        second["retry_cause"] = {"run_id": second["run_id"], "protocol_sha256": self.protocol_sha,
                                 "cause_corrected": True, "technical_error": "transport", "reason": "test"}
        self.progress["attempts"].append(second)
        report = self.run_review()
        self.assertEqual(report["status"], "PENDING_no_primary_verdict")
        self.assertTrue(any("inadmissible_retry_lineage" in c["errors"] for c in report["cells"]))

    def test_documented_corrected_failed_attempt_preserved(self):
        self.add_phase("primary")
        retry = copy.deepcopy(self.progress["attempts"][0])
        self.progress["attempts"][0].update(status="failed", included=False, reason="transport test failure")
        retry["attempt_id"] = retry["run_id"]+"_attempt02"
        retry["retry_cause"] = {"run_id": retry["run_id"], "protocol_sha256": self.protocol_sha,
                                "cause_corrected": True, "technical_error": "transport", "reason": "corrected fixture"}
        self.progress["attempts"].insert(1, retry)
        report = self.run_review()
        self.assertEqual(report["status"], "PASS_primary_final_pending")
        self.assertEqual(len(report["all_attempts"]), 41)
        self.assertEqual(report["all_attempts"][0]["status"], "failed")

    def test_relocated_exact_known_absolute_report_prefix(self):
        self.add_phase("primary", trigger=False)
        self.add_phase("replication")
        for attempt in self.progress["attempts"]:
            attempt["report_path"] = "/home/kmika/Reports/original_task/"+attempt["report_path"]
        snapshot = self.root/"immutable_snapshot.json"
        snapshot.write_text(json.dumps(self.progress))
        relocated = self.root/"renamed_extraction"
        relocated.mkdir()
        for path in self.root.iterdir():
            if path.is_file():
                shutil.copyfile(path, relocated/path.name)
        report = reviewer.review(relocated/"PROTOCOL.json", relocated/snapshot.name, root=relocated)
        self.assertEqual(report["status"], "PASS_final")
        with self.assertRaisesRegex(ValueError, "path_not_in_known_task_root"):
            reviewer.resolve_task(relocated, "/home/kmika/Reports/similar_but_other_task/a.json", "original_task")

    def test_active_ledger_and_pilot_attempt_rejected(self):
        live = self.root/"PROGRESS.json"
        live.write_text(json.dumps(self.progress))
        with self.assertRaisesRegex(ValueError, "active_ledger_forbidden"):
            reviewer.review(self.protocol_path, live)
        self.progress["attempts"].append({"run_id": "pilot", "phase": "pilot"})
        with self.assertRaisesRegex(ValueError, "unregistered_or_pilot"):
            self.run_review()

    def test_seed_and_report_hash_fail_closed(self):
        self.add_phase("primary")
        path = self.root/self.progress["attempts"][0]["report_path"]
        path.write_text(path.read_text()+" ")
        report = self.run_review()
        self.assertEqual(report["status"], "PENDING_no_primary_verdict")
        self.protocol["phases"]["primary"]["schedule"].reverse()
        cases = {c["case_id"]: c for c in self.protocol["cases"]}
        with self.assertRaisesRegex(ValueError, "seeded_schedule_drift"):
            reviewer.schedule_check(self.protocol, cases)

    def test_actual_execution_order_and_process_overlap_rejected(self):
        self.add_phase("primary", trigger=False)
        self.add_phase("replication")
        self.progress["attempts"][0], self.progress["attempts"][1] = self.progress["attempts"][1], self.progress["attempts"][0]
        report = self.run_review()
        self.assertEqual(report["status"], "PENDING_no_primary_verdict")
        self.assertTrue(any("observed_execution_order_differs_from_frozen_schedule_prefix" in r["errors"] for r in report["cells"]))
        self.progress["attempts"][0], self.progress["attempts"][1] = self.progress["attempts"][1], self.progress["attempts"][0]
        attempt = self.progress["attempts"][1]
        path = self.root/attempt["report_path"]
        raw, _ = reviewer.read_json(path)
        raw["started_time_ns"] = 1
        path.write_text(json.dumps(raw))
        _, attempt["report_sha256"] = reviewer.read_json(path)
        report = self.run_review()
        self.assertEqual(report["status"], "PENDING_no_primary_verdict")
        self.assertTrue(any("raw_process_chronology_overlaps_or_reverses" in r["errors"] for r in report["cells"]))


if __name__ == "__main__":
    unittest.main()
