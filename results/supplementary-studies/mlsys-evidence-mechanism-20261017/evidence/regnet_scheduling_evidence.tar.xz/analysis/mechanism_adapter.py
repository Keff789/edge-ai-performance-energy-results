#!/usr/bin/env python3
"""Bounded H10 diagnostic using the product's real initialization and workers.

This is a diagnostic adapter, not a product measurement/import replacement.
The controller owns leases, source deployment, telemetry, randomized blocks and
device admission. This file never builds, connects over SSH or changes clocks.
The only timed intervention is a global one-task gate, when requested. Native
also requires one async slot so its initial submission loop cannot deadlock.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import inspect
import json
import os
from pathlib import Path
import sys
import threading
import time
from typing import Any


VERSION = "mechanism-product-workers-v1"


def sha256(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for data in iter(lambda: f.read(1048576), b""):
            h.update(data)
    return h.hexdigest()


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def atomic_json(path, value):
    path = Path(path)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    os.replace(temporary, path)


class AdapterFinished(BaseException):
    def __init__(self, report):
        self.report = report


class TaskGate:
    """Admission is released after synchronized outputs and actual task tail."""
    def __init__(self, enabled):
        self.enabled = enabled
        self.gate = threading.BoundedSemaphore(1)

    def acquire(self):
        if self.enabled and not self.gate.acquire(timeout=120):
            raise RuntimeError("single_task_gate_timed_out")

    def release(self):
        if self.enabled:
            self.gate.release()


class GatedProcessor:
    def __init__(self, processor, gate):
        self.processor, self.gate = processor, gate

    def __getattr__(self, name):
        return getattr(self.processor, name)

    def process(self, outputs):
        result = self.processor.process(outputs)
        self.gate.release()
        return result


def input_pair(inputs):
    import numpy as np
    if len(inputs) != 1:
        raise ValueError("single_bound_input_required")
    name, original = next(iter(inputs.items()))
    original = np.asarray(original)
    if original.dtype != np.uint8:
        raise ValueError("H10_UINT8_canary_required")
    alternative = np.ascontiguousarray(np.uint8(255) - original)
    if np.array_equal(original, alternative):
        raise ValueError("canary_inputs_not_distinct")
    return [{name: np.array(original, copy=True)}, {name: alternative}]


def compare_outputs(outputs, reference, *, rtol=1e-5, atol=1e-5):
    import numpy as np
    if set(outputs) != set(reference):
        raise RuntimeError("mixed_input_output_names_mismatch")
    for name, expected in reference.items():
        value = np.asarray(outputs[name])
        if (value.shape != expected.shape or value.dtype != expected.dtype
                or not np.isfinite(value).all()
                or not np.allclose(value, expected, rtol=rtol, atol=atol)):
            raise RuntimeError("mixed_input_output_mismatch:" + name)


def own_outputs(outputs):
    import numpy as np
    return {name: np.array(value, copy=True) for name, value in outputs.items()}


def check_bound_reference(outputs, config, *, module=None, processor_class=None):
    """Preserve the product's outside-timer functional reference binding."""
    import numpy as np
    reference = {}
    for name, descriptor in config["functional_reference"]["outputs"].items():
        path = Path(descriptor["path"])
        if sha256(path) != descriptor["sha256"]:
            raise ValueError("historical_functional_reference_file_changed")
        if descriptor.get("format") in {"raw", "raw_bin", "binary"}:
            value = np.fromfile(path, dtype=np.dtype(descriptor["dtype"])).reshape(descriptor["shape"])
        else:
            value = np.load(path, allow_pickle=False)
        if list(value.shape) != descriptor["shape"] or str(value.dtype) != descriptor["dtype"]:
            raise ValueError("historical_functional_reference_shape_dtype_changed")
        reference[name] = value
    if set(outputs) != set(reference) or any(
            np.asarray(outputs[name]).shape != reference[name].shape
            or np.asarray(outputs[name]).dtype != reference[name].dtype
            or not np.isfinite(outputs[name]).all() for name in reference):
        raise ValueError("historical_functional_reference_physical_endpoint_mismatch")
    if module is not None and hasattr(module, "_proxy_validate_classification"):
        names = list(reference)
        ref_logits = module._classification_logits_vector(names, [reference[name] for name in names])
        new_logits = module._classification_logits_vector(names, [outputs[name] for name in names])
        metrics, passed = module._proxy_validate_classification(ref_logits, new_logits)
    else:
        if processor_class is None:
            from onnx_splitpoint_tool.runners.harness.classification import ClassificationCompletion
            processor_class = ClassificationCompletion
        old_processor, new_processor = processor_class(), processor_class()
        old_processor.process(reference)
        new_processor.process(outputs)
        passed = bool(np.array_equal(old_processor.last_result["top1"], new_processor.last_result["top1"]))
        metrics = {"top1_match": passed}
    if not passed:
        raise RuntimeError("historical_product_functional_reference_control_failed")
    metrics["numerical_allclose"] = all(np.allclose(outputs[name], reference[name], rtol=1e-5, atol=1e-5)
                                        for name in reference)
    metrics.update(numerical_rtol=1e-5, numerical_atol=1e-5)
    metrics["max_abs_all_outputs"] = max(float(np.max(np.abs(np.asarray(outputs[name], dtype=np.float64)
                                                            - reference[name]))) for name in reference)
    return metrics


def distinct_references(references):
    import numpy as np
    if set(references[0]) != set(references[1]):
        raise RuntimeError("canary_reference_names_differ")
    if all(np.allclose(references[0][name], references[1][name], rtol=1e-5, atol=1e-5)
           for name in references[0]):
        raise RuntimeError("canary_inconclusive_distinct_inputs_same_outputs")


def canary_manifest(pair, references, out):
    import numpy as np
    manifest = []
    for i, feeds in enumerate(pair):
        input_file = out / f"canary_input_{i}.npy"
        np.save(input_file, next(iter(feeds.values())), allow_pickle=False)
        item = {"input_id": i, "input_path": str(input_file), "input_sha256": sha256(input_file),
                "outputs": {}}
        for j, (name, array) in enumerate(references[i].items()):
            output_file = out / f"canary_reference_{i}_{j}.npy"
            np.save(output_file, array, allow_pickle=False)
            item["outputs"][name] = {"path": str(output_file), "sha256": sha256(output_file),
                                     "shape": list(array.shape), "dtype": str(array.dtype)}
        manifest.append(item)
    return manifest


def generic_callback(module, args, config, out_dir, stage1, transfer, stage2,
                     runtime_artifacts, *, clone_payload, repetition_index=None):
    import numpy as np
    try:
        from splitpoint_runners.task_completion import measure_split_completion
        from splitpoint_runners.harness.classification import ClassificationCompletion
    except ImportError:
        from onnx_splitpoint_tool.runners.task_completion import measure_split_completion
        from onnx_splitpoint_tool.runners.harness.classification import ClassificationCompletion
    if config["task"] != "classification":
        raise ValueError("bounded_adapter_classification_only")
    for role, descriptor in config["expected_runtime_artifacts"].items():
        if Path(runtime_artifacts[role]).resolve() != Path(descriptor["path"]).resolve():
            raise ValueError("actual_product_artifact_path_mismatch:" + role)
        if sha256(descriptor["path"]) != descriptor["sha256"]:
            raise ValueError("actual_product_artifact_hash_mismatch:" + role)

    if args.mode == "canary":
        spec = config["input_binding"]["prepared_input"]
        # The optional stage1(override) branch re-enters image preparation and
        # quantization. Rotate the already prepared mapping captured by the
        # exact default stage1() closure instead, so UINT8 is not quantized twice.
        cached_inputs = inspect.getclosurevars(stage1).nonlocals.get("p1_inputs_hailo")
        if not isinstance(cached_inputs, dict) or len(cached_inputs) != 1:
            raise ValueError("exact_product_cached_Hailo_input_closure_unavailable")
        slot_name, original_cached_input = next(iter(cached_inputs.items()))
        expected_input = np.load(spec["path"], allow_pickle=False)
        if (original_cached_input.shape != expected_input.shape
                or original_cached_input.dtype != expected_input.dtype
                or not np.array_equal(original_cached_input, expected_input)):
            raise ValueError("cached_product_prepared_input_differs_from_bound_tensor")
        pair = input_pair({slot_name: expected_input})
        def prepared_stage1(label):
            cached_inputs[slot_name] = pair[label][slot_name]
            return stage1()
        try:
            references = [own_outputs(stage2(transfer(prepared_stage1(label)))) for label in (0, 1)]
        finally:
            cached_inputs[slot_name] = original_cached_input
        historical_reference_metrics = check_bound_reference(references[0], config, module=module)
        distinct_references(references)
        sequence = [0, 1, 1, 0, 1, 0, 0, 1] * 4
        submitted = 0
        checked = []

        def mixed_stage1():
            nonlocal submitted
            label = sequence[submitted]
            outputs = prepared_stage1(label)
            submitted += 1
            return outputs

        def checked_stage2(feeds):
            outputs = stage2(feeds)
            label = sequence[len(checked)]
            compare_outputs(outputs, references[label])
            checked.append(label)
            return outputs

        gate = TaskGate(args.schedule == "single")
        def admitted_stage1():
            gate.acquire()
            return mixed_stage1()
        try:
            metrics = measure_split_completion(admitted_stage1, transfer, checked_stage2,
                GatedProcessor(ClassificationCompletion(), gate), warmup=0, tasks=len(sequence),
                queue_depth=int(config.get("queue_depth", 2)), clone_payload=clone_payload, timeout_s=120)
        finally:
            cached_inputs[slot_name] = original_cached_input
        if checked != sequence or submitted != len(sequence):
            raise RuntimeError("mixed_canary_sequence_or_drain_mismatch")
        report = {"canary_pass": True, "sequence": sequence, "checked_input_ids": checked,
                  "historical_functional_reference_match": True,
                  "historical_reference_metrics": historical_reference_metrics,
                  "reference_scope": "same_artifact_serial_product_workers_no_accuracy_claim",
                  "input_transform": "input1=255-input0_UINT8_outside_timer",
                  "required_canary_deviation": "rotate_actual_cached_prepared_input_mapping_before_default_stage1_no_requantization",
                  "reference_manifest": canary_manifest(pair, references, Path(out_dir)),
                  "metrics_diagnostic_only": metrics}
    else:
        gate = TaskGate(args.schedule == "single")
        def admitted_stage1():
            gate.acquire()
            return stage1()
        # Same stage closures and clone policy. Warmup is fully drained before
        # the duration function creates/releases its parked measurement workers.
        warmup = measure_split_completion(admitted_stage1, transfer, stage2,
            GatedProcessor(ClassificationCompletion(), gate), warmup=0, tasks=None,
            duration_s=args.warmup_duration_s,
            queue_depth=int(config.get("queue_depth", 2)), clone_payload=clone_payload, timeout_s=120)
        metrics = measure_split_completion(admitted_stage1, transfer, stage2,
            GatedProcessor(ClassificationCompletion(), gate), warmup=0, tasks=None,
            duration_s=60.0, queue_depth=int(config.get("queue_depth", 2)),
            clone_payload=clone_payload, timeout_s=180)
        report = {"completed_work_units": metrics["completed_work_units"],
                  "measurement_time_seconds": metrics["measured_makespan_seconds"],
                  "completed_task_fps": metrics["completed_task_fps"],
                  "warmup_completed_count": warmup["completed_task_count"], "metrics": metrics,
                  "warmup_duration_s": args.warmup_duration_s,
                  "accepted_work_drained": True, "admission_window_seconds": 60.0}
    report["runtime_artifacts"] = config["expected_runtime_artifacts"]
    raise AdapterFinished(report)


class SessionProxy:
    def __init__(self, session, *, gate=None, pair=None, sequence=None):
        self.session, self.gate = session, gate
        self.pair, self.sequence = pair, sequence
        self.submitted = 0
        self.slot_labels = {}

    def __getattr__(self, name):
        return getattr(self.session, name)

    def _submit_reusable_slot(self, slot, infer_inputs, *, copy_inputs):
        if self.gate is not None:
            self.gate.acquire()
        try:
            if self.pair is not None:
                label = self.sequence[self.submitted]
                self.session._wait_reusable_slot(slot)
                self.session._fill_reusable_slot_inputs(slot, self.pair[label])
                self.slot_labels[id(slot)] = (self.submitted, label)
                self.submitted += 1
            return self.session._submit_reusable_slot(slot, infer_inputs, copy_inputs=copy_inputs)
        except BaseException:
            if self.gate is not None:
                self.gate.release()
            raise


class TRTProxy:
    def __init__(self, trt, *, labels=None, references=None):
        self.trt, self.labels, self.references = trt, labels, references
        self.captured = None
        self.checked = []
        self.current = None

    def __getattr__(self, name):
        return getattr(self.trt, name)

    def prepare_inputs(self, feeds):
        if self.labels is not None:
            value = next(iter(feeds.values()))
            self.current = self.labels.pop(id(value))
        return self.trt.prepare_inputs(feeds)

    def run_prepared(self):
        outputs = self.trt.run_prepared()
        if self.references is not None:
            request_id, label = self.current
            compare_outputs(outputs, self.references[label])
            self.checked.append({"request_id": request_id, "input_id": label})
        else:
            self.captured = own_outputs(outputs)
        return outputs

    def run(self, feeds):
        self.prepare_inputs(feeds)
        return self.run_prepared()


def native_callback(module, original, args, sess, inputs, trt, **kwargs):
    if kwargs.get("task", "classification") != "classification":
        raise ValueError("bounded_adapter_classification_only")
    if getattr(args, "config", None) is not None:
        import numpy as np
        config = json.loads(Path(args.config).read_text())
        bound = config["input_binding"]["prepared_input"]
        # Native may retain the sealed raw HEF input name while the Generic
        # graph uses its canonical alias. The product validates slot names;
        # compare the sole actual tensor bytes without inventing name equality.
        if len(inputs) != 1:
            raise ValueError("native_single_bound_input_required")
        actual = np.asarray(next(iter(inputs.values())))
        expected = np.load(bound["path"], allow_pickle=False)
        if (actual.shape != expected.shape or actual.dtype != expected.dtype
                or not np.array_equal(actual, expected)):
            raise ValueError("native_preparation_differs_from_exact_bound_Generic_input")
        actual_hef = Path(sess.hef_path).resolve()
        expected_hef = config["expected_runtime_artifacts"]["part1_runtime"]
        if (actual_hef != Path(expected_hef["path"]).resolve()
                or sha256(actual_hef) != expected_hef["sha256"]):
            raise ValueError("native_actual_HEF_differs_from_bound_Generic_artifact")
    gate = TaskGate(args.schedule == "single")
    original_completion = module.ClassificationCompletion
    module.ClassificationCompletion = lambda: GatedProcessor(original_completion(), gate)
    try:
        if args.mode == "canary":
            pair = input_pair(inputs)
            # Serial references use the very same async worker and real TRT.
            references = []
            for feeds in pair:
                capture = TRTProxy(trt)
                original(SessionProxy(sess, gate=gate), feeds, capture, frames=1, warmup=0,
                         inflight=1, queue_depth=3, task="classification")
                references.append(capture.captured)
            distinct_references(references)
            reference_metrics = (check_bound_reference(references[0], config, processor_class=original_completion)
                                 if getattr(args, "config", None) is not None else None)
            sequence = [0, 1, 1, 0, 1, 0, 0, 1] * 4
            prepared_pair = [sess._prepare_infer_inputs(feeds) for feeds in pair]
            proxy = SessionProxy(sess, gate=gate, pair=prepared_pair, sequence=sequence)
            labels = {}
            original_extract = module._extract_slot_outputs
            def extract(session, slot):
                outputs = original_extract(session, slot)
                identity = proxy.slot_labels[id(slot)]
                for value in outputs.values():
                    labels[id(value)] = identity
                return outputs
            module._extract_slot_outputs = extract
            checked_trt = TRTProxy(trt, labels=labels, references=references)
            try:
                metrics = original(proxy, pair[0], checked_trt, frames=len(sequence), warmup=0,
                    inflight=1 if args.schedule == "single" else 8, queue_depth=3, task="classification")
            finally:
                module._extract_slot_outputs = original_extract
            checked = checked_trt.checked
            if (sorted(r["request_id"] for r in checked) != list(range(len(sequence)))
                    or any(r["input_id"] != sequence[r["request_id"]] for r in checked)
                    or proxy.submitted != len(sequence) or labels):
                raise RuntimeError("native_mixed_identity_or_drain_mismatch")
            report = {"canary_pass": True, "sequence": sequence, "checked_requests": checked,
                      "historical_functional_reference_match": reference_metrics is not None,
                      "historical_reference_metrics": reference_metrics,
                      "reference_scope": "same_artifact_serial_product_workers_no_accuracy_claim",
                      "input_transform": "input1=255-input0_UINT8_outside_timer",
                      "required_canary_deviation": "fill_real_reusable_input_slot_on_each_submit",
                      "reference_manifest": canary_manifest(pair, references, Path(args.out)),
                      "metrics_diagnostic_only": metrics}
        else:
            # Keep regular Native workers. Limit 1 alone is insufficient: the
            # gate lasts through the actual task completion on the suffix lane.
            warmup = original(SessionProxy(sess, gate=gate), inputs, trt, frames=0, warmup=0,
                duration_s=args.warmup_duration_s, inflight=1 if args.schedule == "single" else 8,
                queue_depth=3, task="classification")
            if warmup["produced_frames"] != warmup["consumed_frames"]:
                raise RuntimeError("native_warmup_not_drained")
            metrics = original(SessionProxy(sess, gate=gate), inputs, trt, frames=0, warmup=0,
                duration_s=60.0, inflight=1 if args.schedule == "single" else 8,
                queue_depth=3, task="classification")
            count = metrics["consumed_frames"]
            if count != metrics["produced_frames"] or count <= 0:
                raise RuntimeError("native_accepted_work_not_drained")
            seconds = metrics["makespan_ms"] / 1000
            if seconds < 60:
                raise RuntimeError("native_duration_window_shorter_than_60_seconds")
            report = {"completed_work_units": count, "measurement_time_seconds": seconds,
                      "completed_task_fps": count / seconds, "metrics": metrics,
                      "warmup_completed_count": warmup["consumed_frames"],
                      "warmup_duration_s": args.warmup_duration_s, "admission_window_seconds": 60.0,
                      "accepted_work_drained": True}
    finally:
        module.ClassificationCompletion = original_completion
    raise AdapterFinished(report)


def loaded_sources():
    sources = {}
    for name, value in list(sys.modules.items()):
        path = getattr(value, "__file__", None)
        if path and (name.startswith(("onnx_splitpoint_tool", "splitpoint_runners"))
                     or name == "mechanism_bound_product"):
            path = Path(path)
            if path.is_file() and path.suffix in {".py", ".txt"}:
                sources[str(path.resolve())] = sha256(path)
    return sources


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--chain", choices=["generic", "native"], required=True)
    parser.add_argument("--schedule", choices=["product", "single"], required=True)
    parser.add_argument("--mode", choices=["duration", "canary"], required=True)
    parser.add_argument("--product-runner", type=Path, required=True)
    parser.add_argument("--expected-runner-sha256", required=True)
    parser.add_argument("--config", type=Path, required=True,
                        help="Bound Generic config, also guards Native's exact shared artifacts")
    parser.add_argument("--native-args-json", type=Path)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--protocol-sha256", required=True)
    parser.add_argument("--block", type=int, required=True)
    parser.add_argument("--warmup-duration-s", type=float, default=30.0)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    if (args.block < 0 or args.warmup_duration_s != 30.0 or not args.out.is_absolute()
            or sha256(args.product_runner) != args.expected_runner_sha256
            or sha256(args.protocol) != args.protocol_sha256):
        raise ValueError("block_path_source_or_protocol_guard_failed")
    config = json.loads(args.config.read_text())
    if config["task"] != "classification" or config["identity"]["setup_id"] != "orin_nx_hailo10_01":
        raise ValueError("bounded_adapter_requires_H10_classification")
    if config["identity"]["model_id"] not in {"regnet_x_1_6gf", "resnet50"}:
        raise ValueError("bounded_adapter_model_outside_fixed_case_families")
    specs = [*config["expected_runtime_artifacts"].values(), config["input_binding"]["prepared_input"]]
    for descriptor in specs:
        if sha256(descriptor["path"]) != descriptor["sha256"]:
            raise ValueError("bound_runtime_file_mismatch:" + descriptor["path"])
    if config.get("energy_capture"):
        raise ValueError("diagnostic_adapter_cannot_impersonate_collector_capture")
    args.out.mkdir(parents=True, exist_ok=False)
    identity = {"protocol_sha256": args.protocol_sha256, "identity": config["identity"],
                "artifact_identity": config["expected_runtime_artifacts"], "chain": args.chain,
                "schedule": args.schedule, "block": args.block, "mode": args.mode}
    metadata = {"schema": VERSION, **identity, "run_id": canonical_hash(identity),
                "adapter_sha256": sha256(__file__), "product_runner": str(args.product_runner),
                "product_runner_sha256": args.expected_runner_sha256, "config_sha256": sha256(args.config),
                "pid": os.getpid(), "worker_cpu_affinity": sorted(os.sched_getaffinity(0)),
                "status": "started", "started_time_ns": time.time_ns(),
                "energy_measured": False, "diagnostic_adapter": True,
                "schedule_description": ("unchanged_product_parallelism" if args.schedule == "product" else
                    "one_global_outstanding_task_until_classification_tail_complete"),
                "F2_scope": "whole_Generic_Native_runtime_and_handoff_chain_bundle",
                "deviations": ["60_second_admission_window_instead_of_1000_fixed_tasks",
                    "independent_process_diagnostic_report_no_product_import",
                    "30_second_warmup_fully_drained_then_measurement_workers_recreated"]}
    atomic_json(args.out / "status.json", metadata)
    sys.path.insert(0, str(args.product_runner.parent))
    spec = importlib.util.spec_from_file_location("mechanism_bound_product", args.product_runner)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    if args.chain == "generic":
        original_callback = module._run_generic_split_completion
        module._run_generic_split_completion = lambda *a, **kw: generic_callback(module, args, *a, **kw)
        product_argv = [str(args.product_runner), "--generic-completion-config", str(args.config),
                        "--generic-completion-repetition", "1", "--out-dir", str(args.out)]
    else:
        if args.native_args_json is None:
            raise ValueError("native_product_argv_required")
        argv = json.loads(args.native_args_json.read_text())
        if (not isinstance(argv, list) or not all(isinstance(x, str) for x in argv)
                or any(x in argv for x in ("--build-missing-engine", "--force-rebuild-engine",
                                           "--energy-workload-only"))):
            raise ValueError("unsafe_or_invalid_native_argv")
        for flag, expected in (("--expected-hef-sha256", config["expected_runtime_artifacts"]["part1_runtime"]["sha256"]),
                               ("--expected-engine-sha256", config["expected_runtime_artifacts"]["engine"]["sha256"])):
            if argv.count(flag) != 1 or argv[argv.index(flag) + 1] != expected:
                raise ValueError("native_actual_artifact_guard_required:" + flag)
        original_trt_class = module.NativeTRT
        expected_engine = config["expected_runtime_artifacts"]["engine"]
        class GuardedNativeTRT(original_trt_class):
            def __init__(self, engine_path):
                if (Path(engine_path).resolve() != Path(expected_engine["path"]).resolve()
                        or sha256(engine_path) != expected_engine["sha256"]):
                    raise ValueError("native_actual_loaded_engine_differs_from_bound_Generic_artifact")
                super().__init__(engine_path)
        GuardedNativeTRT.__module__ = original_trt_class.__module__
        module.NativeTRT = GuardedNativeTRT
        original_hotloop = module._hailo10_async_fifo_run
        module._hailo10_async_fifo_run = lambda *a, **kw: native_callback(module, original_hotloop, args, *a, **kw)
        product_argv = [str(args.product_runner), *argv, "--producer-impl", "async_fifo",
                        "--repetitions", "1", "--out-dir", str(args.out)]
    original_argv = sys.argv
    try:
        sys.argv = product_argv
        module.main()
        raise RuntimeError("product_returned_without_bound_worker_callback")
    except AdapterFinished as completed:
        report = {**metadata, **completed.report, "status": "complete", "finished_time_ns": time.time_ns(),
                  "loaded_source_hashes": loaded_sources(), "product_argv": product_argv}
        atomic_json(args.out / "result.json", report)
        atomic_json(args.out / "status.json", {**metadata, "status": "complete", "result_sha256": sha256(args.out / "result.json")})
        print(json.dumps({k: report.get(k) for k in ("run_id", "status", "canary_pass", "completed_task_fps")}))
        return 0
    except BaseException as failure:
        atomic_json(args.out / "status.json", {**metadata, "status": "failed",
                    "failure": type(failure).__name__ + ": " + str(failure), "finished_time_ns": time.time_ns()})
        raise
    finally:
        sys.argv = original_argv


if __name__ == "__main__":
    raise SystemExit(main())
