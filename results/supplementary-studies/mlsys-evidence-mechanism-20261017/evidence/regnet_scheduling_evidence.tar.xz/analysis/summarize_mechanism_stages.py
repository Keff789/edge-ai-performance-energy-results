#!/usr/bin/env python3
"""Offline descriptive stage diagnostics from immutable product-worker reports.

This companion never imports hardware runtimes or changes frozen statistics.
A phase contributes stage values only after every scheduled duration run is
admitted. Saved per-process means are summarized with median/min/max; individual
frames are not statistical replicates. Missing measurements remain null.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import statistics
import sys

HERE = Path(__file__).resolve().parent
FROZEN_ANALYZER_SHA = "0d60339e353af9e97276aaa54d9c56f1fa91a4d8d5f827f675e3dfef44a5fd17"
NATIVE_REL = "results/mechanism_source_bundle/product_native/scripts/native_hailo10_trt_e2e_from_benchmarkset.py"
GENERIC_REL = "results/mechanism_source_bundle/product_generic/splitpoint_runners/task_completion.py"

# These are descriptions of the actual saved code, not isolated service costs.
METRICS = {
    "pipeline_cycle_ms": ("ms/task", "Total measured makespan / completed tasks; includes pipeline fill and accepted-work drain."),
    "p1_ms": ("ms/request", "Native before-slot-submission to producer collection; response/poll wait, not accelerator compute. Single schedule also includes pre-submit global-gate wait."),
    "p1_effective_cycle_ms": ("ms/task", "Producer thread span / completed tasks; includes asynchronous execution, polling, backpressure and global-gate waits."),
    "consumer_effective_cycle_ms": ("ms/task", "Consumer thread span / completed tasks; includes input starvation and consumer service."),
    "output_extract_ms": ("ms/task", "Native output extraction and output selection, including the owned contiguous boundary copy."),
    "trt_input_copy_ms": ("ms/task", "Native TensorRT input preparation, possible reshape/cast/contiguity conversion and CPU copy into pinned input; not H2D alone."),
    "p2_run_ms": ("ms/task", "Native TensorRT H2D + execute + D2H + stream synchronization; not isolated GPU compute or PCIe cost."),
    "completion_tail_ms": ("ms/task", "Classification completion processing; single schedule also releases the global task gate."),
    "p2_thread_ms": ("ms/task", "Already saved sum of three serial consumer sections: input preparation, synchronized TensorRT run, and completion tail."),
    "fifo_put_block_ms": ("ms/task", "Producer bounded queue put elapsed time including blocking/backpressure and push work."),
    "queue_wait_ms": ("ms/task", "Consumer dequeue time minus timestamp taken before producer put; includes producer put blocking plus queue residency/scheduling, overlapping other waits."),
    "handoff_ms": ("ms/task", "Saved legacy composite extraction + zero extra payload copy + FIFO put + input preparation; includes backpressure and is not isolated transfer cost."),
    "consumer_active_fraction": ("fraction", "Saved serial consumer service mean / total pipeline cycle: consumer timed-section occupancy, not independent capacity."),
    "producer_fifo_put_fraction": ("fraction", "Saved queue-put mean / total pipeline cycle: producer time in bounded queue puts. Does not include all producer waiting."),
    "isolated_prefix_compute_ms": ("ms/task", "Unavailable: no isolated prefix compute measurement in these uninstrumented runs."),
    "isolated_gpu_compute_ms": ("ms/task", "Unavailable: TensorRT run includes transfers and synchronization."),
    "isolated_pcie_transfer_ms": ("ms/task", "Unavailable: no PCIe-only timing or independently switched transfer factor."),
}
SAVED = [key for key in METRICS if key not in {
    "pipeline_cycle_ms", "consumer_active_fraction", "producer_fifo_put_fraction",
    "isolated_prefix_compute_ms", "isolated_gpu_compute_ms", "isolated_pcie_transfer_ms"}]
LIMITS = [
    "Descriptive saved process means; no stage instrumentation or hardware execution was added.",
    "Generic reports contain overall completion timing but no separate measured stage or queue timings; null means unavailable, never zero.",
    "Do not sum Native p1 response, queue wait, producer/consumer effective cycles or handoff composite to predict makespan: they overlap and include waiting.",
    "Native producer/consumer effective cycles are pipeline-context lane spans and cannot independently establish prefix/suffix capacity.",
    "Native single-schedule p1 response includes adapter gate waiting because the product submission timestamp precedes the gate acquisition.",
    "Consumer active fraction describes the timed serial consumer sections within the observed run, not an independently measured stage capacity.",
    "Queue residency includes the blocking producer put; FIFO put and queue wait must not be added or treated as disjoint costs.",
    "Generic/Native is the coupled runtime/handoff chain factor. These diagnostics do not identify an isolated copying, layout, dequantization, or PCIe effect.",
    "Scheduling intervention effects belong to the frozen paired-block analysis; this companion supplies supporting timing context without a new causal contrast.",
    "Primary, extension, replication and pilots remain separate; historical capacities from other cuts/protocols are not pooled.",
]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def finite_nonnegative(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def load_frozen():
    path = HERE / "summarize_mechanism.py"
    if sha(path) != FROZEN_ANALYZER_SHA:
        raise ValueError("frozen_analyzer_source_pin_mismatch")
    spec = importlib.util.spec_from_file_location("mechanism_frozen_for_stages", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def extract_metrics(report):
    """Return values and explicit availability; never synthesize missing costs."""
    values = {key: None for key in METRICS}
    availability = {key: "unavailable_unmeasured" for key in METRICS}
    errors = []
    count, seconds = report["completed_work_units"], report["measurement_time_seconds"]
    values["pipeline_cycle_ms"] = 1000.0 * seconds / count
    availability["pipeline_cycle_ms"] = "derived_exact_count_and_makespan"
    metrics = report.get("metrics", {})
    if report["chain"] != "native":
        for key in SAVED + ["consumer_active_fraction", "producer_fifo_put_fraction"]:
            availability[key] = "unavailable_generic_uninstrumented"
        return values, availability, errors
    for key in SAVED:
        value = metrics.get(key)
        if value is None:
            availability[key] = "unavailable_not_saved"
        elif not finite_nonnegative(value):
            errors.append("invalid_native_metric:" + key)
            availability[key] = "invalid_saved_value"
        else:
            values[key] = float(value)
            availability[key] = "saved_native_process_mean"
    # Native invariants check that summaries describe the exact admitted run.
    for key in ("produced_frames", "consumed_frames", "completed_frames", "completed_work_units"):
        if key in metrics and metrics[key] != count:
            errors.append("native_stage_count_mismatch:" + key)
    comparisons = []
    if "makespan_ms" in metrics:
        comparisons.append((metrics["makespan_ms"], seconds * 1000, "makespan_ms"))
    if "hailo_latency_ms" in metrics and values["p1_ms"] is not None:
        comparisons.append((metrics["hailo_latency_ms"], values["p1_ms"], "p1_alias"))
    for key, span in (("p1_effective_cycle_ms", "producer_makespan_ms"),
                      ("consumer_effective_cycle_ms", "consumer_makespan_ms")):
        if span in metrics and values[key] is not None:
            if finite_nonnegative(metrics[span]):
                comparisons.append((metrics[span] / count, values[key], key))
            else:
                errors.append("invalid_native_metric:" + span)
    serial = [values[key] for key in ("trt_input_copy_ms", "p2_run_ms", "completion_tail_ms")]
    if all(value is not None for value in serial) and values["p2_thread_ms"] is not None:
        comparisons.append((sum(serial), values["p2_thread_ms"], "serial_consumer_sections"))
    for observed, expected, label in comparisons:
        if not finite_nonnegative(observed) or not math.isclose(observed, expected, rel_tol=1e-9, abs_tol=1e-9):
            errors.append("native_stage_internal_mismatch:" + label)
    for output, numerator in (("consumer_active_fraction", "p2_thread_ms"),
                              ("producer_fifo_put_fraction", "fifo_put_block_ms")):
        if values[numerator] is not None:
            value = values[numerator] / values["pipeline_cycle_ms"]
            if value > 1 + 1e-6:
                errors.append("native_stage_occupancy_outside_run:" + output)
                availability[output] = "invalid_occupancy"
            else:
                values[output] = value
                availability[output] = "derived_saved_section_mean_over_pipeline_cycle"
    return values, availability, errors


def aggregate_groups(rows):
    groups = {}
    for row in rows:
        group_key = tuple(row[key] for key in ("phase", "model", "cut", "variant"))
        groups.setdefault(group_key, []).append(row)
    summaries = []
    for group_key, runs in sorted(groups.items()):
        base = dict(zip(("phase", "model", "cut", "variant"), group_key))
        for metric, (unit, definition) in METRICS.items():
            present = [run[metric] for run in runs if run["stage_included"] and run[metric] is not None]
            reasons = sorted({run["availability"][metric] for run in runs if run[metric] is None})
            summaries.append({**base, "metric": metric, "unit": unit,
                "n_scheduled": len(runs), "n_stage_included": sum(run["stage_included"] for run in runs),
                "n_available": len(present), "median_process_mean": statistics.median(present) if present else None,
                "min_process_mean": min(present) if present else None,
                "max_process_mean": max(present) if present else None,
                "missing_reasons": reasons, "interpretation": definition})
    return summaries


def source_bindings(root, protocol):
    result = []
    source_specs = [(NATIVE_REL, "native", "815-1130"),
                    (GENERIC_REL, "generic_task_completion", "105-340"),
                    (protocol["adapter"]["path"], "adapter", "53-78,294-313,344-435")]
    for relative, role, lines in source_specs:
        path = root / relative
        digest = sha(path)
        if role == "adapter":
            expected = protocol["adapter"]["sha256"]
        elif role == "native":
            expected_values = {case["runners"]["native"]["sha256"] for case in protocol["cases"]}
            if len(expected_values) != 1:
                raise ValueError("stage_semantics_require_one_bound_native_source")
            expected = expected_values.pop()
        else:
            expected_values = {item["sha256"] for case in protocol["cases"] for item in case["required_sources"]
                               if item["path"].endswith("/splitpoint_runners/task_completion.py")}
            if len(expected_values) != 1:
                raise ValueError("stage_semantics_require_one_bound_generic_completion_source")
            expected = expected_values.pop()
        if digest != expected:
            raise ValueError("stage_semantics_source_pin_mismatch:" + role)
        result.append({"role": role, "path": str(path), "sha256": digest, "relevant_lines": lines})
    return result


def summarize(protocol_path, progress_path, output_prefix, *, phases=None, task_root=None):
    frozen = load_frozen()
    protocol_path, progress_path = Path(protocol_path).resolve(), Path(progress_path).resolve()
    root = Path(task_root).resolve() if task_root else protocol_path.parent
    if progress_path.name == "PROGRESS.json":
        raise ValueError("stage_diagnostics_require_immutable_progress_snapshot")
    # Snapshot hashes bracket the sealed reader. No runtime/controller imports.
    progress_sha, protocol_sha = sha(progress_path), sha(protocol_path)
    data = frozen.read_data(protocol_path, progress_path, root=root)
    if sha(progress_path) != progress_sha or data["progress_sha256"] != progress_sha or sha(protocol_path) != protocol_sha:
        raise ValueError("immutable_inputs_changed_during_stage_analysis")
    selected_phases = phases or ["primary"]
    if len(set(selected_phases)) != len(selected_phases):
        raise ValueError("duplicate_phase_selection")
    phase_status, rows = [], []
    for phase in selected_phases:
        if phase not in data["protocol"]["phases"]:
            raise ValueError("phase_not_in_protocol:" + phase)
        spec = data["protocol"]["phases"][phase]
        cells = [cell for cell in data["cells"] if cell["phase"] == phase]
        complete = (spec["mode"] == "duration" and len(cells) == spec["expected_runs"]
                    and bool(cells) and all(cell["included"] for cell in cells))
        phase_status.append({"phase": phase, "expected_runs": spec["expected_runs"],
            "admitted_runs": sum(cell["included"] for cell in cells),
            "mode": spec["mode"], "phase_complete": complete,
            "stage_values_released": complete,
            "reason": None if complete else "stage_values_withheld_until_all_scheduled_duration_runs_admitted"})
        for cell in cells:
            row = {key: cell[key] for key in ("phase", "model", "case_id", "cut", "variant", "block",
                "controller_run_id", "report_path", "report_sha256")}
            row.update(global_analysis_included=cell["included"], phase_complete=complete,
                       stage_included=False, stage_errors=[], exclusion_reasons=cell["exclusion_reasons"])
            values = {key: None for key in METRICS}
            availability = {key: "withheld_phase_incomplete" for key in METRICS}
            if complete:
                values, availability, errors = extract_metrics(data["reports"][cell["controller_run_id"]])
                row.update(stage_errors=errors, stage_included=not errors)
                if errors:
                    values = {key: None for key in METRICS}
                    availability = {key: "excluded_stage_internal_validation" for key in METRICS}
            row.update(values)
            row["availability"] = availability
            rows.append(row)
    bindings = source_bindings(root, data["protocol"])
    groups = aggregate_groups(rows)
    report = {"schema": "mechanism-stage-diagnostics-v1", "hardware_executed": False,
        "new_stage_instrumentation": False, "status": "complete" if all(row["phase_complete"] for row in phase_status)
            and all(row["stage_included"] for row in rows) else "incomplete_or_stage_invalid",
        "protocol_path": str(protocol_path), "protocol_sha256": protocol_sha,
        "immutable_progress_path": str(progress_path), "immutable_progress_sha256": progress_sha,
        "code_sha256": sha(__file__), "frozen_analyzer_sha256": FROZEN_ANALYZER_SHA,
        "selected_phases": selected_phases, "phase_status": phase_status,
        "source_bindings": bindings, "limits": LIMITS,
        "metrics": {key: {"unit": unit, "definition": definition} for key, (unit, definition) in METRICS.items()},
        "groups": groups, "runs": rows,
        "aggregation": "Separate phase/model/cut/variant medians and ranges of admitted process means; no frame pooling, no stage confidence intervals, no overlapping-latency sum.",
        "raw_report_sha256": {row["controller_run_id"]: row["report_sha256"] for row in rows if row["stage_included"]}}
    prefix = Path(output_prefix).resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    frozen.write_csv(Path(str(prefix)+"_runs.csv"), rows, ["phase", "cut", "variant", "stage_included"])
    frozen.write_csv(Path(str(prefix)+"_summary.csv"), groups, ["phase", "cut", "variant", "metric", "n_available"])
    report["output_hashes"] = {suffix: sha(str(prefix)+suffix) for suffix in ("_runs.csv", "_summary.csv")}
    Path(str(prefix)+".json").write_text(json.dumps(report, indent=2, allow_nan=False)+"\n")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--progress", type=Path, required=True)
    parser.add_argument("--output-prefix", type=Path, required=True)
    parser.add_argument("--phase", action="append", dest="phases")
    parser.add_argument("--task-root", type=Path)
    args = parser.parse_args()
    report = summarize(args.protocol, args.progress, args.output_prefix, phases=args.phases, task_root=args.task_root)
    print(json.dumps({"status": report["status"], "phase_status": report["phase_status"],
                      "raw_report_pins": len(report["raw_report_sha256"])}))


if __name__ == "__main__":
    main()
