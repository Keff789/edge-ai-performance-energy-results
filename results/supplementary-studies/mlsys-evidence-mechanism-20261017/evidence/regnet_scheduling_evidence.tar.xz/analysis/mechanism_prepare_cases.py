#!/usr/bin/env python3
"""Copy compact existing R14 case configs and derive guarded Native CLI argv.

No remote access and no runtime. Large artifacts remain uniquely referenced.
The controller assigns isolated product sources and remote deployment paths.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    source_root = Path('/home/kmika/Reports/native-fairness-rev3-20261007')
    tool = Path('/home/kmika/ONNX-Splitpoint-Tool')
    native_runner = tool / 'scripts/native_hailo10_trt_e2e_from_benchmarkset.py'
    out = args.root / 'results/mechanism_source_cases'
    out.mkdir(exist_ok=True)
    source = json.loads((args.root / 'results/mechanism_source_r14_raw.json').read_text())
    cases = []
    for pair in source['pairs']:
        model, cut = pair['model'], pair['case']
        case_id = ('regnet_' if model.startswith('regnet') else 'resnet_') + cut
        batch = 'regnet20' if model.startswith('regnet') else 'resnet19'
        config_source = source_root / f'generic_followup/batches/final_20261008_hailo10_{batch}/staging/orin_nx_hailo10_01/{model}/{cut}/generic_completion_config.json'
        config_path = out / (case_id + '_generic_config.json')
        shutil.copyfile(config_source, config_path)
        config = json.loads(config_path.read_text())
        summary = json.loads(Path(pair['native_summary']).read_text())
        original_plan = json.loads(Path(summary['plan']).read_text())
        original_argv = original_plan['runs'][0]['argv']
        first_flag = next(i for i, value in enumerate(original_argv) if value.startswith('--'))
        native_argv = original_argv[first_flag:]
        # The adapter owns these duplicate options and its fresh output path.
        for flag in ('--out-dir', '--producer-impl', '--repetitions'):
            while flag in native_argv:
                i = native_argv.index(flag)
                del native_argv[i:i+2]
        i = native_argv.index('--expected-runner-sha256')
        native_argv[i+1] = sha(native_runner)
        argv_path = out / (case_id + '_native_argv.json')
        write(argv_path, native_argv)
        raw = json.loads(Path(summary['rows'][0]['raw_report']).read_text())
        contract = raw['native_command_contract']
        required = {}
        for role, descriptor in pair['native_runtime_artifacts'].items():
            required[descriptor['path']] = {**descriptor, 'role': role}
        prepared = config['input_binding']['prepared_input']
        required[prepared['path']] = {**prepared, 'role': 'exact_R14_prepared_input'}
        for descriptor in config.get('runtime_source_files', []):
            # Historical Python code is replaced by the controller's explicitly
            # pinned isolated current source closure. Keep data/graph contracts.
            if Path(descriptor['path']).suffix != '.py':
                required[descriptor['path']] = {**descriptor, 'role': 'generic_graph_contract_or_reference'}
        for descriptor in config['functional_reference']['outputs'].values():
            required[descriptor['path']] = {**descriptor, 'role': 'generic_existing_functional_reference'}
        quality_binding = native_argv[native_argv.index('--native-split-quality-binding')+1]
        original_binding_file = next(row for row in original_plan['stage_files']
                                     if row['remote'] == quality_binding)
        if sha(original_binding_file['local']) != original_binding_file['sha256']:
            raise ValueError('native_quality_binding_source_file_changed')
        required[quality_binding] = {'path': quality_binding,
            'sha256': original_binding_file['sha256'], 'role': 'native_quality_binding',
            'binding_canonical_sha256': contract['native_split_quality_binding_sha256'],
            'local_source_if_restage_needed': original_binding_file['local']}
        # Add existing native benchmark declarations and exact symlink/copy
        # source descriptors only for the actually reused first repeat.
        benchmark_set = native_argv[native_argv.index('--benchmark-set')+1]
        for descriptor in original_plan.get('stage_files', []):
            if descriptor['remote'].startswith(benchmark_set + '/'):
                required.setdefault(descriptor['remote'], {'path': descriptor['remote'],
                    'sha256': descriptor['sha256'], 'role': 'native_existing_staged_benchmark',
                    'local_source_if_restage_needed': descriptor['local']})
        cases.append({'case_id': case_id, 'model': model, 'cut': cut,
            'setup_id': 'orin_nx_hailo10_01', 'config_path': str(config_path),
            'config_sha256': sha(config_path), 'config_original_source': str(config_source),
            'native_args_path': str(argv_path), 'native_args_sha256': sha(argv_path),
            'native_original_plan': summary['plan'], 'native_original_plan_sha256': sha(summary['plan']),
            'native_original_raw': summary['rows'][0]['raw_report'],
            'native_product_runner_source': str(native_runner), 'native_product_runner_sha256': sha(native_runner),
            'generic_product_runner_template': str(tool/'onnx_splitpoint_tool/resources/templates/run_split_onnxruntime.py.txt'),
            'artifact_identity': config['expected_runtime_artifacts'],
            'prepared_input': prepared, 'required_artifacts': list(required.values()),
            'native_benchmark_set': benchmark_set,
            'historical_python_source_fields_preserved_in_config': True,
            'actual_python_source_closure_authority': 'new_frozen_protocol_required_sources',
            'native_argv_changes': ['removed out-dir/producer-impl/repetitions because adapter supplies fresh values',
                'expected-runner-sha256 set to explicitly selected current product runner source'],
            'scope': 'references_existing_R14_graphs_and_artifacts_no_build_or_hardware_execution'})
    manifest = {'schema': 'mechanism_source_cases/v1', 'cases': cases,
        'generic_config_copy_policy': 'byte_identical_original_product_config',
        'note': 'Controller stages current product sources separately and must preflight every required remote file. '
                'Old runtime_source_files Python descriptors remain historical metadata, not current source authority.'}
    write(args.root / 'results/mechanism_source_case_manifest.json', manifest)
    print(json.dumps({'cases': len(cases), 'manifest': str(args.root/'results/mechanism_source_case_manifest.json'),
                      'required_artifact_descriptors': sum(len(c['required_artifacts']) for c in cases)}))


if __name__ == '__main__':
    main()
