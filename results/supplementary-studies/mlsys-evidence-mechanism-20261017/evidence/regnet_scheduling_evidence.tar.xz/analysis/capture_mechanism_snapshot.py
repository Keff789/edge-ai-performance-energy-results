#!/usr/bin/env python3
"""Save one immutable, byte-bound controller ledger for offline analysis."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--protocol', type=Path, default=ROOT / 'PROTOCOL.json')
    parser.add_argument('--label', required=True)
    parser.add_argument('--phases', nargs='+', required=True)
    args = parser.parse_args()
    if not re.fullmatch('[A-Za-z0-9_-]+', args.label):
        raise ValueError('Invalid label')
    protocol_bytes = args.protocol.read_bytes()
    protocol = json.loads(protocol_bytes)
    protocol_sha = hashlib.sha256(protocol_bytes).hexdigest()
    source = ROOT / 'results/mechanism' / protocol_sha / 'PROGRESS.json'
    # One read is essential: the controller replaces its ledger atomically.
    data = source.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    progress = json.loads(data)
    if progress['protocol_sha256'] != protocol_sha:
        raise ValueError('Progress/protocol mismatch')
    for phase in args.phases:
        spec = protocol['phases'][phase]
        latest = {}
        for attempt in progress['attempts']:
            if attempt['phase'] == phase:
                latest[attempt['run_id']] = attempt
        if (len(latest) != spec['expected_runs']
                or not all(a.get('status') == 'completed' and a.get('included') is True for a in latest.values())
                or not any(e.get('status') == 'phase_completed' and e.get('phase') == phase for e in progress['events'])):
            raise ValueError('Requested phase is not complete and admitted: ' + phase)
    directory = ROOT / 'results/mechanism_snapshots'
    directory.mkdir(exist_ok=True)
    snapshot = directory / (args.label + '_' + digest + '.json')
    if snapshot.exists():
        if snapshot.read_bytes() != data:
            raise ValueError('Snapshot identity collision')
    else:
        with snapshot.open('xb') as stream:
            stream.write(data)
    receipt = snapshot.with_suffix('.receipt.json')
    metadata = {'created_at_utc': datetime.now(timezone.utc).isoformat(),
        'protocol_path': str(args.protocol.resolve()), 'protocol_sha256': protocol_sha,
        'original_ledger_path': str(source), 'snapshot_path': str(snapshot),
        'snapshot_sha256': digest, 'required_completed_phases': args.phases,
        'single_read_bytes_saved_unchanged': True,
        'scope': 'Immutable source for the sealed offline analyzer. No device access or statistical-rule change.'}
    if not receipt.exists():
        with receipt.open('x') as stream:
            json.dump(metadata, stream, indent=2)
            stream.write('\n')
    print(str(snapshot))

if __name__ == '__main__':
    main()
