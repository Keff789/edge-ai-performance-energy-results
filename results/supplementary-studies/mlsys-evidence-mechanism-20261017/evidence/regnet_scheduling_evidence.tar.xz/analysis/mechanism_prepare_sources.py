#!/usr/bin/env python3
"""Prepare isolated unchanged product sources with the normal Generic writer.

No model builds, hardware execution, deployment, or productive source changes.
"""
from __future__ import annotations
import argparse
import ast
import hashlib
import json
from pathlib import Path
import shutil
import sys


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def native_closure(repo, entry):
    pending = [entry, repo/'onnx_splitpoint_tool/__init__.py']
    selected = set()
    def add_module(name):
        if not name.startswith('onnx_splitpoint_tool'):
            return
        parts = name.split('.')
        for count in range(1, len(parts)+1):
            init = repo.joinpath(*parts[:count], '__init__.py')
            if init.is_file() and init not in selected:
                pending.append(init)
        for path in (repo.joinpath(*parts).with_suffix('.py'), repo.joinpath(*parts, '__init__.py')):
            if path.is_file() and path not in selected:
                pending.append(path)
    while pending:
        path = pending.pop()
        if path in selected:
            continue
        selected.add(path)
        module_parts = list(path.relative_to(repo).with_suffix('').parts)
        if module_parts[-1] == '__init__':
            module_parts.pop()
        else:
            module_parts.pop()
        for node in ast.walk(ast.parse(path.read_text())):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    add_module(alias.name)
            elif isinstance(node, ast.ImportFrom):
                if node.level:
                    base = module_parts[:len(module_parts)-node.level+1]
                    name = '.'.join(base + ((node.module or '').split('.') if node.module else []))
                else:
                    name = node.module or ''
                add_module(name)
                for alias in node.names:
                    if alias.name != '*':
                        add_module(name + '.' + alias.name)
    return sorted(selected)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    repo = Path('/home/kmika/ONNX-Splitpoint-Tool')
    sys.path.insert(0, str(repo))
    from onnx_splitpoint_tool.workflow.generic_completed_task import prepare_runner_bundle
    out = args.root/'results/mechanism_source_bundle'
    out.mkdir(exist_ok=True)
    generic = out/'product_generic'
    if not generic.exists():
        prepare_runner_bundle(generic)
    native = out/'product_native'
    native_entry = repo/'scripts/native_hailo10_trt_e2e_from_benchmarkset.py'
    closure = native_closure(repo, native_entry)
    for source in closure:
        target = native/source.relative_to(repo)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
    shutil.copyfile(args.root/'analysis/mechanism_adapter.py', out/'mechanism_adapter.py')
    files = []
    for path in sorted(out.rglob('*.py')):
        if '__pycache__' in path.parts:
            continue
        files.append({'local': str(path), 'remote_relative_path': path.relative_to(out).as_posix(),
                      'sha256': sha(path), 'size_bytes': path.stat().st_size})
    manifest = {'schema': 'mechanism_product_deploy/v1', 'bundle_root': str(out), 'deploy_files': files,
        'generic_product_runner_relative': 'product_generic/runner/run_split_onnxruntime.py',
        'native_product_runner_relative': 'product_native/scripts/native_hailo10_trt_e2e_from_benchmarkset.py',
        'adapter_relative': 'mechanism_adapter.py',
        'generic_generation_function': 'onnx_splitpoint_tool.workflow.generic_completed_task.prepare_runner_bundle',
        'native_package_policy': 'unchanged_current_product_files_static_AST_import_closure',
        'native_closure_file_count': len(closure),
        'source_deviation': 'current_dirty_db729b9fcde00e4bcadf9200d43282977d7bf1cc_product_code_not_historical_reconstruction',
        'hardware_executed': False, 'build_allowed': False,
        'required_sources_policy': 'prefix_each_remote_relative_path_with_actual_isolated_remote_root_and_pin_SHA_before_run'}
    target = args.root/'results/mechanism_source_deploy_manifest.json'
    target.write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({'manifest': str(target), 'files': len(files),
                      'bytes': sum(row['size_bytes'] for row in files), 'native_closure_files': len(closure)}))


if __name__ == '__main__':
    main()
