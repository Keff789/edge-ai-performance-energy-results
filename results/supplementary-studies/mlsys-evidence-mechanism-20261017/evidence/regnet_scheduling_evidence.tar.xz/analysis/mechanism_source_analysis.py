#!/usr/bin/env python3
"""Reproduce compact R14 mechanism diagnostics without hardware or imports."""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
from pathlib import Path
from statistics import median


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1048576), b''):
            h.update(block)
    return h.hexdigest()


def csv_write(path, rows):
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open('w', newline='') as f:
        writer = csv.DictWriter(f, fields)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    source = args.root / 'results/mechanism_source_r14_raw.json'
    evidence = json.loads(source.read_text())
    summaries, repeats = [], []
    for pair in evidence['pairs']:
        native = pair['native_repeats']
        generic = pair['generic_repeats']
        if len(native) != 3 or len(generic) != 3:
            raise ValueError('exact_R14_three_process_repetitions_required')
        n_median = median(r['fps'] for r in native)
        g_median = median(r['completed_task_fps'] for r in generic)
        if n_median != pair['native_fps_median'] or g_median != pair['generic_fps_median']:
            raise ValueError('R14_exact_median_join_failed')
        if not pair['same_hef_and_trt_hashes_all_native_and_generic_repetitions']:
            raise ValueError('same_artifact_binding_failed')
        summary = {'model': pair['model'], 'cut': pair['case'],
            'cohort': 'R14_exact_20261008_process_repeats',
            'native_fps_median': n_median, 'generic_fps_median': g_median,
            'native_processes': len(native), 'generic_processes': len(generic),
            'native_inflight': 8, 'native_queue_depth': 3,
            'generic_workers': 2, 'generic_queue_depth': 2,
            'repeated_input_only': True, 'different_input_historical_mapping_verified': False,
            'same_recorded_hef_engine_hashes': True,
            'native_source': pair['native_summary'], 'native_source_sha256': pair['native_summary_sha256'],
            'generic_source': pair['generic_result'], 'generic_source_sha256': pair['generic_result_sha256'],
            'source_manifest_sha256': sha(source)}
        stage_keys = ['p1_ms', 'p1_effective_cycle_ms', 'p2_run_ms', 'p2_thread_ms',
                      'fifo_put_block_ms', 'queue_wait_ms', 'trt_input_copy_ms',
                      'handoff_ms', 'completion_tail_ms']
        for key in stage_keys:
            summary['native_median_' + key] = median(r['raw'][key] for r in native)
        summaries.append(summary)
        for r in native:
            row = {'model': pair['model'], 'cut': pair['case'], 'runner': 'native',
                'process_repeat': r['repeat'], 'cohort': summary['cohort'],
                'completed_task_fps': r['fps'], 'completed_tasks': r['raw']['completed_frames'],
                'measurement_time_seconds': r['raw']['makespan_ms'] / 1000,
                'runtime_instance_id': r['raw']['runtime_instance_id'],
                'source': r['raw_report'], 'source_sha256': r['raw_sha256'],
                'paired_randomized_block': False}
            row.update({key: r['raw'][key] for key in stage_keys})
            repeats.append(row)
        for r in generic:
            repeats.append({'model': pair['model'], 'cut': pair['case'], 'runner': 'generic',
                'process_repeat': r['repetition_index'], 'cohort': summary['cohort'],
                'completed_task_fps': r['completed_task_fps'],
                'completed_tasks': r['completed_task_count'],
                'measurement_time_seconds': r['measured_makespan_seconds'],
                'runtime_instance_id': r['runtime_instance_id'],
                'source': pair['generic_result'], 'source_sha256': pair['generic_result_sha256'],
                'paired_randomized_block': False})
    contrasts = []
    for model, first, second in [('regnet_x_1_6gf', 'b052', 'b123'), ('resnet50', 'b002', 'b095')]:
        rows = {r['cut']: r for r in summaries if r['model'] == model}
        g = rows[second]['generic_fps_median'] / rows[first]['generic_fps_median']
        n = rows[second]['native_fps_median'] / rows[first]['native_fps_median']
        contrasts.append({'model': model, 'denominator_cut': first, 'numerator_cut': second,
            'generic_ratio_of_historical_medians': g, 'native_ratio_of_historical_medians': n,
            'ratio_change_native_over_generic': n/g,
            'historical_rank_reversal': g < 1 < n,
            'causal_intervention_completed': False, 'paired_block_uncertainty_available': False})
    csv_write(args.root / 'results/mechanism_source_summary.csv', summaries)
    csv_write(args.root / 'results/mechanism_source_repetitions.csv', repeats)
    csv_write(args.root / 'results/mechanism_source_contrasts.csv', contrasts)
    validation = {'summary_rows': len(summaries), 'repetition_rows': len(repeats),
                  'contrast_rows': len(contrasts), 'R14_medians_reproduced': True,
                  'source_manifest_sha256': sha(source), 'hardware_executed': False,
                  'statistical_limit': 'historical repetition indices are not paired randomized blocks'}
    (args.root / 'results/mechanism_source_validation.json').write_text(json.dumps(validation, indent=2)+'\n')
    print(json.dumps(validation))


if __name__ == '__main__':
    main()
