#!/usr/bin/env python3
"""Freeze explicit Phase B pilot or confirmation plans before device execution."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import random

ROOT=Path(__file__).resolve().parents[1]
TOOL=Path('/home/kmika/ONNX-Splitpoint-Tool')
ADMISSION=Path('/home/kmika/Reports/stage_cost_composition_20261014/20261014T102852Z/scripts/stage_cost_admission.py')

def sha(p):
    with Path(p).open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()

def pin(p): return {'path':str(p),'sha256':sha(p)}

def phase(cases,variants,blocks,mode):
    rng=random.Random(20261017);schedule=[]
    for block in blocks:
        cells=[(c,v) for c in cases for v in variants];rng.shuffle(cells)
        schedule += [{'case_id':c,'variant':v,'block':block} for c,v in cells]
    return {'case_ids':cases,'variants':variants,'blocks':blocks,'mode':mode,
            'seed':20261017,'schedule':schedule,'expected_runs':len(schedule)}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--kind',choices=['pilot_canary','pilot_timing','confirmation'],required=True)
    ap.add_argument('--series',required=True)
    ap.add_argument('--output',required=True)
    args=ap.parse_args()
    output=ROOT/args.output
    if output.exists(): raise ValueError('Frozen file already exists. Use a new series/file, never overwrite.')
    remote='/home/nx/Reports/'+ROOT.name+'/'+args.series
    bundle=json.loads((ROOT/'results/mechanism_source_deploy_manifest.json').read_text())
    source_cases=json.loads((ROOT/'results/mechanism_source_case_manifest.json').read_text())['cases']
    deploy=[]
    for f in bundle['deploy_files']:
        if f['remote_relative_path']==bundle['adapter_relative']: continue
        deploy.append({'local_path':str(Path(f['local']).relative_to(ROOT)),
                       'remote_relative':f['remote_relative_path'],'sha256':f['sha256']})
    adapter='analysis/mechanism_adapter.py'
    deploy.append({'local_path':adapter,'remote_relative':adapter,'sha256':sha(ROOT/adapter)})
    sources=[{'path':remote+'/'+f['remote_relative'],'sha256':f['sha256']} for f in deploy]
    cases=[]
    for c in source_cases:
        row={'case_id':c['case_id'],'cut':c['cut'],'model_id':c['model'],
             'required_artifacts':c['required_artifacts'],'required_sources':sources,
             'artifact_identity':c['artifact_identity']}
        for kind in ['config','native_args']:
            name=str(Path(c[kind+'_path']).relative_to(ROOT))
            row[kind+'_path']=name;row[kind+'_sha256']=sha(ROOT/name)
            if row[kind+'_sha256'] != c[kind+'_sha256']:raise ValueError('Source case changed: '+name)
            deploy.append({'local_path':name,'remote_relative':name,'sha256':row[kind+'_sha256']})
        row['runners']={}
        for chain in ['generic','native']:
            name=bundle[chain+'_product_runner_relative']
            item=next(d for d in deploy if d['remote_relative']==name)
            row['runners'][chain]={'path':remote+'/'+name,'sha256':item['sha256']}
        cases.append(row)
    reg=[c['case_id'] for c in cases if c['model_id']=='regnet_x_1_6gf']
    res=[c['case_id'] for c in cases if c['model_id']=='resnet50']
    variants=['G_product','N_product','G_single','N_single']
    if args.kind=='pilot_canary':
        phases={'pilot':phase(reg+res,variants,[0],'canary')}
    elif args.kind=='pilot_timing':
        phases={'pilot':phase([reg[0]],['G_product','N_product'],[0],'duration')}
    else:
        phases={'primary':phase(reg,variants,list(range(1,6)),'duration'),
                'extension':phase(reg,variants,list(range(6,11)),'duration'),
                'replication':phase(res,['N_product','N_single'],list(range(1,6)),'duration')}
    local=['remote/ssh_transport.py','remote/process_lease.py','workflow/run_control.py',
           'process_control.py','platform_power.py']
    p={'schema':'mechanism-controller-v1','series_id':args.series,'kind':args.kind,
       'frozen_at_utc':datetime.now(timezone.utc).isoformat(),'repository':str(TOOL),
       'profiles':pin('/home/kmika/.onnx_splitpoint_tool/hardware_setups.yaml'),
       'admission':pin(ADMISSION),
       'controller':{'path':'analysis/run_mechanism.py','sha256':sha(ROOT/'analysis/run_mechanism.py')},
       'adapter':{'path':adapter,'sha256':sha(ROOT/adapter)},
       'local_code':[pin(TOOL/'onnx_splitpoint_tool'/f) for f in local],
       'device':{'setup_id':'orin_nx_hailo10_01','python':'/home/nx/venvs/hailo10/bin/python',
         'remote_root':remote,'expected_identity':{'hostname':'orin','machine':'aarch64','device_tree_serial':'1424223006055'},
         'state_policy':{'temperature_band_c':[40,65],'stability_delta_c':2,
          'cpu_min_max_khz':1984000,'gpu_min_max_hz':1173000000,'power_mode':'MAXN_SUPER',
          'affinity':list(range(8)),'stability_gap_s':2,'max_wait_s':120,'min_rest_s':5}},
       'deploy_files':deploy,'cases':cases,'phases':phases,
       'recipe':{'warmup_s':30,'window_s':60,'timeout_s':300},
       'endpoint':'prepared shared input to completed classification top1/top5 after required owned outputs and TRT synchronization',
       'input_policy':'Use the exact historical prepared UINT8 tensor for timing. Separate canaries use its deterministic complement and32 predefined varied requests. Native canary explicitly adds per-submit input filling, so it cannot validate arbitrary-input support of the historical fixed-input wrapper.',
       'factors':{'F1':'original product parallelism versus globally one outstanding task released after classification completion',
         'F2':'complete Generic versus Native backend and handoff chain bundle, including SDK wrappers, layout, conversion and copies. Not an isolated copy factor.',
         'G_product':'original2workers/queue2','N_product':'original8H10inflight/queue3',
         'G_single':'sameGeneric workers with whole-task semaphore1',
         'N_single':'sameNative workers with inflight1 and whole-task semaphore1'},
       'drift_rules':{'before':'Require registered physical identity, exclusive product lock, no competing work, exact artifacts/sources, fixed CPU/GPU frequencies/power mode/affinity, CPU thermal40..65C with <=2C change over2s, no active throttle alert.',
         'thermal_scope':'Prespecified comparability band, not a hardware safety threshold. End temperatures descriptive. Warmup30s fully drains before measurement.',
         'after':'Require unchanged pins/profile/clocks/power/affinity, no active throttle alerts or competing work, every accepted task completed. No selection of middle or faster windows.',
         'failed':'Retain every attempt. Stop on failure. Repeat only after documented corrected technical cause. Changed code/profile/artifacts requires separate series. No selective cell extension.',
         'incomplete_blocks':'Exclude incomplete blocks from paired estimates, report their full attempts and reasons. Never count frames as process replications.'},
       'primary_analysis':{'unit':'independent worker process, paired within full randomized block',
         'rate':'all completed accepted tasks divided by full measurement makespan including queue fill and drain; not60second core rate',
         'cut_ratio':'b123/b052 for RegNet, b095/b002 for ResNet, pervariant and sameblock',
         'summary':'geometric mean ratio, sample SD of logratios and two-sided Student-t95percent interval across blocks',
         'interaction':'log(N_product_cut_ratio/G_product_cut_ratio)-log(N_single_cut_ratio/G_single_cut_ratio)',
         'mechanism_scope':'Report continuous intervention effects and observed stage capacities/waits. Whole-chain contrast cannot identify an individual copy/conversion cause. Current-code intervention does not automatically reconstruct historical causes.',
         'replication':'Apply Native product versus Native globally-single intervention to ResNet without tuning. If primary scheduling mechanism unsupported, label second diagnosis, not confirmatory mechanism replication.',
         'no_outcome_tuning':True},
       'extension_trigger_rule_id':'primary_ratio_or_interaction_ci_includes_null',
       'extension_rule':'After exactly5 complete primary blocks, extend exactlyonce by5fullblocks if t95percent interval of G_product or N_product logcutratio or interaction contains0. No further extension. Maximum100 scheduled confirmatory processes in this protocol, under task160cap.',
       'reuse_original_cells':'G_product and N_product retain actual product initialization/stagefunctions/copies/endpoint andparallelism. They count as originalrunner comparisons within matrix, not additionalreplicates. Adapter duration/warmup/report deviations disclosed.',
       'energy_measured':False,'pilot_results_in_confirmatory_estimates':False,
       'historical_source_manifest':pin(ROOT/'results/mechanism_source_r14_raw.json'),
       'source_generation_manifest':pin(ROOT/'results/mechanism_source_deploy_manifest.json')}
    if args.kind=='confirmation':
        prerequisites=[]
        for filename,expected in [('PROTOCOL_pilot_canary_v1.json',16),('PROTOCOL_pilot_timing_v1.json',2)]:
            pilot=ROOT/filename
            progress=ROOT/'results/mechanism'/sha(pilot)/'PROGRESS.json'
            recorded=json.loads(progress.read_text())
            attempts=recorded['attempts']
            if len(attempts)!=expected or not all(a.get('status')=='completed' and a.get('included') is True for a in attempts):
                raise ValueError('Pilot prerequisites incomplete: '+filename)
            prerequisites.append({'protocol':pin(pilot),'progress':pin(progress),'completed_processes':expected})
        review=ROOT/'results/mechanism_canary_independent_review.json'
        receipt=json.loads(review.read_text())
        if receipt.get('status')!='pass' or receipt.get('errors'):
            raise ValueError('Independent canary review has not passed')
        p['pilot_prerequisites']={'series':prerequisites,'independent_canary_review':pin(review),
            'pilot_performance_used_to_choose_parameters':False,
            'note':'All pilot stages use the same unchanged adapter/controller as confirmation; rates are excluded from confirmatory estimates.'}
    spec=importlib.util.spec_from_file_location('controller',ROOT/'analysis/run_mechanism.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);m.validate_protocol(p,ROOT)
    output.write_text(json.dumps(p,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({'path':str(output),'sha256':sha(output),'phases':{k:v['expected_runs'] for k,v in phases.items()},'deploy_files':len(deploy)}))

if __name__=='__main__': main()
