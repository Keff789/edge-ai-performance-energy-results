#!/usr/bin/env python3
"""Independent offline audit of confirmed Phase B process evidence.

Reads one consistent progress-file byte snapshot, raw reports and saved device
observations. No product/controller/adapter import, SSH, runtime initialization,
device observation, execution, or edits to frozen measurement sources.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
from pathlib import Path, PurePosixPath
import random
import statistics

HELPER = Path(__file__).with_name("review_mechanism_canaries.py")
_spec = importlib.util.spec_from_file_location("independent_saved_state_review", HELPER)
_helper = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_helper)
sha, canonical, require = _helper.sha, _helper.canonical, _helper.require
check_snapshot = _helper.check_snapshot
VARIANTS = _helper.VARIANTS
RULE = "primary_ratio_or_interaction_ci_includes_null"
TASK_PREFIXES = {}


def task_path(root, value):
    """Relocate only exact original task prefixes attested by the protocol."""
    root, path = Path(root).resolve(), Path(value)
    if not path.is_absolute():
        path = root / path
    elif not path.is_relative_to(root):
        prefixes = TASK_PREFIXES.get(str(root), [])
        matching = [prefix for prefix in prefixes if path.is_relative_to(prefix)]
        require(len(matching) == 1, "path outside current task and frozen original task prefix: " + str(value))
        path = root / path.relative_to(matching[0])
    path = path.resolve()
    require(path.is_relative_to(root), "recorded path escapes task")
    return path


def configure_relocation(root, protocol):
    original_name = PurePosixPath(protocol["device"]["remote_root"]).parent.name
    prefixes = set()
    for key in ("historical_source_manifest", "source_generation_manifest"):
        value = protocol.get(key, {}).get("path")
        if not value:
            continue
        path = Path(value)
        positions = [i for i, part in enumerate(path.parts) if part == original_name]
        require(path.is_absolute() and len(positions) == 1, "frozen original task prefix is ambiguous")
        prefixes.add(Path(*path.parts[:positions[0] + 1]))
    require(len(prefixes) <= 1, "frozen source manifests disagree about original task root")
    TASK_PREFIXES[str(Path(root).resolve())] = list(prefixes)
    # The independently imported helper reads saved observations only. Rebind
    # its resolver in memory so renamed extraction paths are handled uniformly.
    _helper.task_path = task_path


def matching_intervals(first, second):
    return (isinstance(first, dict) and set(first) == set(second)
        and all(isinstance(first[key], list) and len(first[key]) == len(second[key]) == 2
            and all(type(a) in (int, float) and math.isfinite(a) and math.isclose(a, b, abs_tol=1e-12, rel_tol=1e-12)
                    for a, b in zip(first[key], second[key])) for key in second))


def saved_json(path):
    data = Path(path).read_bytes()
    return json.loads(data), hashlib.sha256(data).hexdigest()


def action(protocol_sha, case, config, phase, cell):
    identity = {"protocol_sha256": protocol_sha, "artifact_identity": config["expected_runtime_artifacts"],
        "case_id": case["case_id"], "cut": case["cut"], "variant": cell["variant"],
        "block": cell["block"], "phase": phase, "mode": "duration"}
    return {**identity, "run_id": canonical(identity)}


def duration_contract(raw, chain, schedule, config):
    count, seconds, fps = (raw[key] for key in ("completed_work_units", "measurement_time_seconds", "completed_task_fps"))
    require(type(count) is int and count > 0 and type(seconds) in (int, float) and math.isfinite(seconds)
            and seconds >= 60 and math.isfinite(fps) and fps > 0
            and math.isclose(fps, count / seconds, rel_tol=1e-9), "count/time/completed-task rate does not agree")
    require(raw["warmup_duration_s"] == 30 and type(raw["warmup_completed_count"]) is int and raw["warmup_completed_count"] > 0
            and raw["admission_window_seconds"] == 60 and raw["accepted_work_drained"] is True,
            "fixed30-second drained warmup or60-second accepted-work drain contract absent")
    elapsed = (raw["finished_time_ns"] - raw["started_time_ns"]) / 1e9
    require(elapsed + 0.001 >= 30 + seconds, "process elapsed time cannot contain declared warmup and measurement")
    metrics = raw["metrics"]
    if chain == "generic":
        require(metrics["status"] == "ok" and metrics["requested_duration_s"] == 60
                and metrics["admitted_task_count"] == metrics["completed_task_count"] == metrics["processor_count_delta"] == count
                and metrics["completed_work_units"] == count and metrics["accepted_work_drained"] is True
                and metrics["fill_and_drain_included"] is True and metrics["postprocess_timed"] is True
                and metrics["output_materialization_timed"] is True, "Generic admission/completion/materialization contract differs")
        start, deadline, stop, end = (metrics[key] for key in (
            "measurement_start_ns", "admission_deadline_ns", "admission_stopped_ns", "measurement_end_ns"))
        require(deadline - start == 60_000_000_000 and deadline <= stop <= end
                and metrics["admission_stopped_at_deadline"] is True
                and math.isclose((end - start) / 1e9, seconds, rel_tol=1e-12, abs_tol=1e-9)
                and math.isclose(metrics["measured_makespan_seconds"], seconds, rel_tol=1e-12),
                "Generic exact60-second deadline, accepted-work drain or measured timer differs")
        require(metrics["worker_count"] == 2 and metrics["queue_depth"] == int(config.get("queue_depth", 2)),
                "Generic product worker/queue recipe changed")
        timing_proof = {"admission_span_ns": deadline - start, "stop_minus_deadline_ns": stop - deadline,
                        "drain_after_stop_ns": end - stop, "measurement_span_ns": end - start}
    else:
        require(metrics["duration_s"] == 60 and metrics["produced_frames"] == metrics["consumed_frames"]
                == metrics["completed_work_units"] == metrics["postprocess_completed_frames"] == count
                and metrics["task_complete"] is True and metrics["postprocess_completion_verified"] is True
                and metrics["postprocess_included"] is True
                and metrics["completed_task_stage"] == "classification_top1_top5"
                and metrics["measurement_boundary"] == "workers_ready_to_last_completed_task_frame"
                and metrics["warmup_contract"] == "fully_drained_before_worker_start"
                and math.isclose(metrics["makespan_ms"] / 1000, seconds, rel_tol=1e-12),
                "Native accepted/completed/postprocess counts or timer/endpoint differs")
        require(metrics["inflight"] == (8 if schedule == "product" else 1) and metrics["queue_depth"] == 3,
                "Native product/single scheduling recipe changed")
        latency = metrics["request_latency"]
        require(latency["status"] == "unavailable" and latency["reason"] == "duration_workload_not_instrumented"
                and not latency["pairs"], "confirming Native run contains per-request latency instrumentation")
        timing_proof = {"native_makespan_ms": metrics["makespan_ms"], "declared_admission_seconds": metrics["duration_s"],
                        "produced_equals_consumed_equals_postprocessed": True,
                        "native_admission_timestamps_saved": False}
    return {"completed_work_units": count, "measurement_time_seconds": seconds, "completed_task_fps": fps,
            "warmup_completed_count": raw["warmup_completed_count"], "warmup_duration_s": 30,
            "admission_window_seconds": 60, "process_elapsed_seconds": elapsed,
            "rate_denominator": "admission start through full accepted-work completion including drain", **timing_proof}


def stability_record(root, attempt, before_path, protocol):
    before, _ = saved_json(task_path(root, before_path))
    before_time = datetime.fromisoformat(before["observed_at_utc"]).timestamp()
    target = attempt["before_state_check"]["previous_temperature_c"]
    candidates = []
    for path in task_path(root, before_path).parent.glob(attempt["run_id"] + "_*.json"):
        if "_stability_" not in path.name and "_before_" not in path.name:
            continue
        value, digest = saved_json(path)
        stamp = datetime.fromisoformat(value["observed_at_utc"]).timestamp()
        temp = float(value["read_only_start_state"]["/sys/class/thermal/thermal_zone0/temp"]) / 1000
        if stamp < before_time and math.isclose(temp, target, abs_tol=1e-9):
            candidates.append((stamp, temp, path, digest))
    require(candidates, "prior temperature-stability observation is not preserved")
    stamp, temp, path, digest = max(candidates)
    gap = before_time - stamp
    policy = protocol["device"]["state_policy"]
    current = float(before["read_only_start_state"]["/sys/class/thermal/thermal_zone0/temp"]) / 1000
    require(gap >= policy["stability_gap_s"] and abs(current - temp) <= policy["stability_delta_c"],
            "saved start temperature samples violate frozen gap/delta")
    require(math.isclose(current, attempt["before_state_check"]["temperature_c"], abs_tol=1e-9),
            "controller's start temperature differs from actual saved reading")
    return {"path": str(path.relative_to(root)), "sha256": digest, "temperature_c": temp,
            "sample_gap_seconds": gap, "delta_c": current - temp}


def check_report(root, protocol, protocol_sha, case, config, attempt):
    raw_path = task_path(root, attempt["report_path"])
    raw, digest = saved_json(raw_path)
    require(digest == attempt["report_sha256"], "immutable raw report hash changed")
    chain, schedule = VARIANTS[attempt["variant"]]
    identity = {"protocol_sha256": protocol_sha, "identity": config["identity"],
        "artifact_identity": config["expected_runtime_artifacts"], "chain": chain, "schedule": schedule,
        "block": attempt["block"], "mode": "duration"}
    require(all(raw.get(key) == value for key, value in identity.items()) and raw["run_id"] == canonical(identity),
            "raw adapter identity/protocol/artifact differs")
    require(raw["schema"] == "mechanism-product-workers-v1" and raw["status"] == "complete"
            and raw["adapter_sha256"] == protocol["adapter"]["sha256"]
            and raw["product_runner"] == case["runners"][chain]["path"]
            and raw["product_runner_sha256"] == case["runners"][chain]["sha256"]
            and raw["config_sha256"] == case["config_sha256"]
            and raw["diagnostic_adapter"] is True and raw["energy_measured"] is False
            and raw["worker_cpu_affinity"] == protocol["device"]["state_policy"]["affinity"],
            "completed raw report source/config/affinity/measurement scope differs")
    sources = {item["path"]: item["sha256"] for item in case["required_sources"]}
    require(raw["loaded_source_hashes"] and all(sources.get(path) == value for path, value in raw["loaded_source_hashes"].items()),
            "unfrozen or changed actually imported product source")
    row = {"raw_report": str(raw_path.relative_to(root)), "raw_report_sha256": digest,
           "pid": raw["pid"], "remote_started_time_ns": raw["started_time_ns"],
           "remote_finished_time_ns": raw["finished_time_ns"], "loaded_source_files": len(raw["loaded_source_hashes"]),
           "actual_loaded_source_hashes": raw["loaded_source_hashes"],
           "runtime_artifact_identity": raw["artifact_identity"],
           **duration_contract(raw, chain, schedule, config)}
    if "runtime_artifacts" in raw:
        require(raw["runtime_artifacts"] == config["expected_runtime_artifacts"], "actual Generic backend artifact descriptors differ")
    return row


def extension_decision(protocol_sha, primary_rows):
    if len(primary_rows) != 40 or not all(row["audit_status"] == "pass" and row["included"] for row in primary_rows):
        return {"status": "not_evaluable", "extend": None, "reason": "five complete admitted primary blocks required"}
    rates = {(row["block"], row["variant"], row["cut"]): row["completed_task_fps"] for row in primary_rows}
    values = {variant: [math.log(rates[(block, variant, "b123")] / rates[(block, variant, "b052")])
                        for block in range(1, 6)] for variant in VARIANTS}
    values["interaction"] = [values["N_product"][i] - values["G_product"][i]
                              - values["N_single"][i] + values["G_single"][i] for i in range(5)]
    intervals = {}
    for name in ("G_product", "N_product", "interaction"):
        mean = statistics.mean(values[name])
        half = 2.7764451051977987 * statistics.stdev(values[name]) / math.sqrt(5)
        intervals[name] = [mean - half, mean + half]
    return {"status": "evaluated", "protocol_sha256": protocol_sha, "rule_id": RULE,
            "extend": any(lo <= 0 <= hi for lo, hi in intervals.values()), "log_ratio_intervals95": intervals,
            "primary_report_sha256": {row["run_id"]: row["raw_report_sha256"] for row in primary_rows}}


def audit(root, protocol_file="PROTOCOL.json", *, progress_file=None, primary_snapshot=None,
          trigger_file=None, scope="final"):
    protocol_path = task_path(root, protocol_file)
    protocol, protocol_sha = saved_json(protocol_path)
    configure_relocation(root, protocol)
    protocol["_protocol_file"] = str(protocol_path.relative_to(root))
    require(protocol["schema"] == "mechanism-controller-v1", "unsupported frozen protocol schema")
    if progress_file is None:
        progress_path = root / "results/mechanism" / protocol_sha / "PROGRESS.json"
    else:
        progress_path = task_path(root, progress_file)
    progress, progress_sha = saved_json(progress_path)
    require(progress["schema"] == "mechanism-progress-v1" and progress["protocol_sha256"] == protocol_sha,
            "progress snapshot belongs to another frozen protocol")
    require(len(progress["attempts"]) <= 160, "confirmed process-attempt bound exceeded")
    errors, known, case_configs = [], {}, {}
    for case in protocol["cases"]:
        path = task_path(root, case["config_path"])
        require(sha(path) == case["config_sha256"], "frozen case configuration changed")
        config, _ = saved_json(path)
        require(config["identity"]["model_id"] == case["model_id"] and config["identity"]["case_id"] == case["cut"],
                "case configuration identity differs")
        case_configs[case["case_id"]] = (case, config)
    for phase, spec in protocol["phases"].items():
        require(phase in {"primary", "extension", "replication"} and spec["mode"] == "duration", "nonconfirming phase in series")
        rng, expected = random.Random(spec["seed"]), []
        for block in spec["blocks"]:
            cells = [(key, variant) for key in spec["case_ids"] for variant in spec["variants"]]
            rng.shuffle(cells)
            expected.extend({"case_id": key, "variant": variant, "block": block} for key, variant in cells)
        require(spec["schedule"] == expected and spec["expected_runs"] == len(expected), "frozen seeded complete-block schedule differs")
        for index, cell in enumerate(expected):
            case, config = case_configs[cell["case_id"]]
            identity = action(protocol_sha, case, config, phase, cell)
            require(identity["run_id"] not in known, "duplicate scheduled controller identity")
            known[identity["run_id"]] = (identity, case, config, index)
    attempted, rows, phase_order = defaultdict(list), [], defaultdict(list)
    previous_finished, previous_raw_end = None, None
    pids = set()
    for index, attempt in enumerate(progress["attempts"]):
        row = {"attempt_index": index, "attempt_id": attempt.get("attempt_id"), "run_id": attempt.get("run_id"),
            "phase": attempt.get("phase"), "case_id": attempt.get("case_id"), "cut": attempt.get("cut"),
            "variant": attempt.get("variant"), "block": attempt.get("block"), "recorded_status": attempt.get("status"),
            "included": attempt.get("included") is True, "original_attempt_sha256": canonical(attempt),
            "audit_status": "pending", "errors": [], "state_exclusion_reasons": attempt.get("state_check", {}).get("reasons", [])}
        if attempt.get("status") == "failed" or (attempt.get("status") == "completed" and attempt.get("included") is not True):
            row["original_attempt"] = attempt
        row["saved_evidence_files"] = {}
        for field in ("before_snapshot", "after_snapshot", "report_path", "log_path"):
            if attempt.get(field):
                evidence_path = task_path(root, attempt[field])
                row["saved_evidence_files"][field] = {"path": str(evidence_path.relative_to(root)),
                    "exists": evidence_path.is_file(), "sha256": sha(evidence_path) if evidence_path.is_file() else None}
        attempted[attempt.get("run_id")].append(row)
        try:
            require(attempt.get("run_id") in known, "attempt is not registered in frozen protocol")
            identity, case, config, schedule_index = known[attempt["run_id"]]
            require(all(attempt.get(key) == value for key, value in identity.items()), "controller attempt identity changed")
            require(attempt["attempt_id"] == attempt["run_id"] + f"_attempt{len(attempted[attempt['run_id']]):02d}", "attempt numbering changed or history lost")
            if len(attempted[attempt["run_id"]]) == 1:
                phase_order[attempt["phase"]].append(schedule_index)
            else:
                prior = attempted[attempt["run_id"]][-2]
                cause = attempt.get("retry_cause", {})
                require(prior["recorded_status"] == "failed" and cause.get("run_id") == attempt["run_id"]
                        and cause.get("protocol_sha256") == protocol_sha and cause.get("cause_corrected") is True
                        and cause.get("reason") and cause.get("technical_error") in {"launcher", "transport", "implementation"},
                        "repeat lacks preserved failed predecessor and corrected technical cause")
            row["before"] = check_snapshot(root, attempt["before_snapshot"], protocol, case, end=False)
            row["stability"] = stability_record(root, attempt, attempt["before_snapshot"], protocol)
            if attempt.get("log_path"):
                log = task_path(root, attempt["log_path"])
                row.update(log_path=str(log.relative_to(root)), log_sha256=sha(log))
            started = datetime.fromisoformat(attempt["started_at_utc"]).timestamp()
            if previous_finished is not None:
                rest = started - previous_finished
                require(rest >= protocol["device"]["state_policy"]["min_rest_s"], "fixed minimum inter-process rest violated")
                row["rest_since_prior_process_seconds"] = rest
            if attempt.get("finished_wall_time") is not None:
                previous_finished = attempt["finished_wall_time"]
            if attempt["status"] in {"started", "hardware_finished", "uncertain"}:
                row["audit_status"] = "pending"
                row["reason"] = "started process or uncertain completion is retained and excluded"
            elif attempt["status"] == "failed":
                row["audit_status"] = "failed_attempt_preserved"
                row["failure_reason"] = attempt.get("reason")
                row["original_attempt"] = attempt
            else:
                require(attempt["status"] == "completed" and attempt.get("returncode") == 0, "completed process nonzero or unknown status")
                row.update(check_report(root, protocol, protocol_sha, case, config, attempt))
                require(row["pid"] not in pids, "worker PID reused within confirmed series")
                pids.add(row["pid"])
                if previous_raw_end is not None:
                    require(row["remote_started_time_ns"] >= previous_raw_end, "saved worker process lifetimes overlap")
                previous_raw_end = row["remote_finished_time_ns"]
                try:
                    row["after"] = check_snapshot(root, attempt["after_snapshot"], protocol, case, end=True)
                    require(row["before"]["controller_lock_pid"] == row["after"]["controller_lock_pid"], "product physical lock owner changed within run")
                except (OSError, ValueError, KeyError, TypeError) as state_error:
                    if attempt.get("included") is True:
                        raise
                    row["independent_end_exclusion"] = str(state_error)
                require(attempt["before_state_check"]["comparable"] is True and not attempt["before_state_check"]["reasons"],
                        "controller started process with noncomparable state")
                if attempt.get("included") is True:
                    require(attempt["state_check"]["comparable"] is True and not attempt["state_check"]["reasons"],
                            "included process has recorded state exclusions")
                    row["audit_status"] = "pass"
                else:
                    row["audit_status"] = "excluded_attempt_preserved"
                    row["original_attempt"] = attempt
        except (OSError, KeyError, TypeError, ValueError, IndexError) as error:
            row["audit_status"] = "audit_failure"
            row["errors"].append(str(error))
            errors.append({"attempt_id": attempt.get("attempt_id"), "reason": str(error)})
        rows.append(row)
    for phase, indexes in phase_order.items():
        if indexes != list(range(len(indexes))):
            errors.append({"phase": phase, "reason": "first process attempts do not follow frozen complete-block prefix"})
    latest = {key: values[-1] for key, values in attempted.items()}
    phase_results = {}
    for phase, spec in protocol["phases"].items():
        planned = [key for key, value in known.items() if value[0]["phase"] == phase]
        admitted = [latest[key] for key in planned if key in latest and latest[key]["audit_status"] == "pass" and latest[key]["included"]]
        complete_blocks = [block for block in spec["blocks"] if all(key in latest and latest[key]["audit_status"] == "pass"
            and latest[key]["included"] for key in planned if known[key][0]["block"] == block)]
        phase_results[phase] = {"planned_process_cells": len(planned), "attempted_processes": sum(row["phase"] == phase for row in rows),
            "admitted_complete_process_cells": len(admitted), "not_started_cells": sum(key not in latest for key in planned),
            "complete_block_ids": complete_blocks, "planned_block_ids": spec["blocks"],
            "phase_complete": len(admitted) == len(planned), "status_counts": dict(Counter(row["audit_status"] for row in rows if row["phase"] == phase))}
    primary_rows = [row for row in latest.values() if row["phase"] == "primary"]
    decision = extension_decision(protocol_sha, primary_rows)
    trigger_evidence = None
    if trigger_file is not None:
        path = task_path(root, trigger_file)
        trigger, trigger_sha = saved_json(path)
        trigger_evidence = {"path": str(path.relative_to(root)), "sha256": trigger_sha}
        if any(trigger.get(key) != decision.get(key) for key in ("protocol_sha256", "rule_id", "extend", "primary_report_sha256")):
            errors.append({"reason": "supplied extension receipt differs from independently recomputed primary evidence"})
        if not matching_intervals(trigger.get("log_ratio_intervals95"), decision.get("log_ratio_intervals95", {})):
            errors.append({"reason": "supplied extension receipt intervals differ from independently recomputed primary evidence"})
    extension_attempts = [row for row in rows if row["phase"] == "extension"]
    if extension_attempts:
        events = [value for value in progress["events"] if value.get("status") == "extension_trigger_verified"]
        authorized = decision.get("extend") is True and events
        if authorized:
            intervals = events[-1].get("log_ratio_intervals95", {})
            authorized = matching_intervals(intervals, decision["log_ratio_intervals95"])
            if trigger_file is not None:
                authorized = authorized and events[-1].get("trigger_receipt_sha256") == canonical(trigger)
        if not authorized:
            errors.append({"reason": "extension processes lack matching predefined trigger and controller authorization event"})
    preservation = {"status": "not_supplied"}
    if primary_snapshot is not None:
        path = task_path(root, primary_snapshot)
        prior, prior_sha = saved_json(path)
        current = {attempt["attempt_id"]: attempt for attempt in progress["attempts"]}
        prior_primary = [attempt for attempt in prior["attempts"] if attempt["phase"] == "primary"]
        preserved = (path.name != "PROGRESS.json" and prior.get("protocol_sha256") == protocol_sha and len({attempt["run_id"] for attempt in prior_primary
            if attempt.get("status") == "completed" and attempt.get("included") is True}) == 40
            and all(current.get(attempt["attempt_id"]) == attempt for attempt in prior_primary))
        preservation = {"status": "pass" if preserved else "fail", "path": str(path.relative_to(root)),
            "sha256": prior_sha, "primary_attempts_preserved": len(prior_primary)}
        if not preserved:
            errors.append({"reason": "immutable primary snapshot is incomplete or its attempt history changed in final snapshot"})
    required = ["primary"] if scope == "primary" else ["primary", "replication"]
    if scope == "final" and decision.get("extend") is True:
        required.append("extension")
    required_count = sum(protocol["phases"][phase]["expected_runs"] for phase in required)
    pending = [phase for phase in required if not phase_results[phase]["phase_complete"]]
    reasons = []
    immutable_input = progress_file is not None and progress_path.name != "PROGRESS.json"
    if not immutable_input:
        reasons.append("explicit immutable progress snapshot has not been supplied")
    if scope == "final" and primary_snapshot is None:
        reasons.append("immutable primary40 snapshot has not been supplied")
    if scope == "final" and decision.get("status") != "evaluated":
        reasons.append("predefined extension decision cannot yet be evaluated")
    if pending:
        reasons.append("required phases incomplete: " + ", ".join(pending))
    if sha(progress_path) != progress_sha:
        errors.append({"reason": "selected progress file changed while its saved evidence was being audited"})
    result = {"schema": "mechanism-independent-execution-review-v1", "scope": scope,
        "status": "fail" if errors else "incomplete" if reasons else "pass",
        "completion_reasons": reasons, "reviewed_at_utc": datetime.now(timezone.utc).isoformat(),
        "protocol": str(protocol_path.relative_to(root)), "protocol_sha256": protocol_sha,
        "progress_snapshot": str(progress_path.relative_to(root)), "progress_snapshot_sha256": progress_sha,
        "immutable_progress_snapshot_explicit": immutable_input,
        "review_source_sha256": sha(__file__), "saved_state_helper_sha256": sha(HELPER),
        "hardware_executed_by_review": False, "frozen_measurement_sources_modified": False,
        "required_phases": required, "required_complete_process_cells": required_count,
        "all_attempts_preserved_in_audit": len(rows) == len(progress["attempts"]), "total_attempts": len(rows),
        "attempt_status_counts": dict(Counter(row["audit_status"] for row in rows)), "distinct_completed_worker_pids": len(pids),
        "phases": phase_results, "independent_extension_decision": decision, "external_trigger_receipt": trigger_evidence,
        "primary_snapshot_preservation": preservation, "rows": rows, "audit_errors": errors,
        "scope_limits": ["Offline validation of saved evidence; no fresh device observation was made.",
            "Start and end clock/power/thermal observations do not continuously sample the measurement interval.",
            "Native records a60-second duration and full-drain counters/makespan; separate Native admission timestamps are not saved.",
            "Warmup is bound to frozen source and declared30seconds with positive completion count; separate warmup timer samples are not saved.",
            "Canary output/request checks are separate evidence; no dataset accuracy or energy measurement is inferred here.",
            "Each completed cell is one independent worker process. Image counts are not independent replications."]}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--protocol", default="PROTOCOL.json")
    parser.add_argument("--progress-snapshot", type=Path)
    parser.add_argument("--primary-snapshot", type=Path)
    parser.add_argument("--extension-trigger", type=Path)
    parser.add_argument("--scope", choices=["primary", "final"], default="final")
    parser.add_argument("--output", default="results/mechanism_execution_independent_review.json")
    args = parser.parse_args()
    root = args.root.resolve()
    result = audit(root, args.protocol, progress_file=args.progress_snapshot,
        primary_snapshot=args.primary_snapshot, trigger_file=args.extension_trigger, scope=args.scope)
    path = task_path(root, args.output)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    notes = root / "notes/mechanism_execution_independent_review.md"
    notes.write_text("# Independent confirmed-process execution review\n\n"
        + f"Status: {result['status']}. Scope: {args.scope}. Protocol SHA256: `{result['protocol_sha256']}`.\n\n"
        + f"Saved attempts: {result['total_attempts']}; distinct completed worker PIDs: {result['distinct_completed_worker_pids']}; required process cells: {result['required_complete_process_cells']}.\n\n"
        + "\n".join(f"- {key}: {value['admitted_complete_process_cells']}/{value['planned_process_cells']} admitted cells; complete blocks {value['complete_block_ids']}." for key, value in result["phases"].items())
        + "\n\n" + "\n".join(result["completion_reasons"] + result["scope_limits"]) + "\n")
    print(json.dumps({"status": result["status"], "scope": args.scope, "attempts": result["total_attempts"],
        "audit_errors": len(result["audit_errors"]), "phases": result["phases"], "output": str(path)}))
    return 1 if result["status"] == "fail" else 0


if __name__ == "__main__":
    raise SystemExit(main())
