"""Offline controller regressions. All remote/physical operations are fakes."""
import copy
import importlib.util
import json
import hashlib
from pathlib import Path
import shutil
import shlex
import stat
import subprocess
import sys
import zipfile

import pytest

SOURCE = Path(__file__).with_name("run_mechanism.py")
spec = importlib.util.spec_from_file_location("mechanism_controller_under_test", SOURCE)
m = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = m
spec.loader.exec_module(m)


@pytest.fixture
def frozen(tmp_path, monkeypatch):
    root = tmp_path / "owned_task"
    root.mkdir()
    for name in ("controller.py", "adapter.py", "admission.py", "profiles.yaml"):
        (root / name).write_text("# frozen offline fixture\n")
    monkeypatch.setattr(m, "__file__", str(root / "controller.py"))
    pin = lambda name: {"path": name, "sha256": m.digest(root / name)}
    remote = "/home/nx/Reports/owned_task/series1"
    protocol = {"schema": m.SCHEMA, "series_id": "series1", "repository": "/installed/product",
        "profiles": pin("profiles.yaml"), "admission": pin("admission.py"),
        "controller": pin("controller.py"), "adapter": pin("adapter.py"),
        "device": {"setup_id": "orin_nx_hailo10_01", "python": "/home/nx/venvs/hailo10/bin/python",
            "remote_root": remote, "expected_identity": {"hostname": "orin"},
            "state_policy": {"temperature_band_c": [40, 65], "stability_delta_c": 2,
                "stability_gap_s": 2, "max_wait_s": 10, "min_rest_s": 0,
                "power_mode": "MAXN_SUPER", "affinity": list(range(8)),
                "cpu_min_max_khz": 1984000, "gpu_min_max_hz": 1173000000}},
        "recipe": {"warmup_s": 30, "window_s": 60, "timeout_s": 300},
        "drift_rules": {"exclude": "changed clocks or competitor; preserve all results"},
        "primary_analysis": {"estimand": "paired log cut ratios, t95 df4"},
        "deploy_files": [{"local_path": "adapter.py", "remote_relative": "adapter.py",
                          "sha256": m.digest(root / "adapter.py")}],
        "cases": [], "phases": {}, "extension_trigger_rule_id": m.EXTENSION_RULE}
    for model, cut in (("regnet_x_1_6gf", "b052"), ("regnet_x_1_6gf", "b123"),
                       ("resnet50", "b002"), ("resnet50", "b095")):
        case_id = model + "_" + cut
        config_path, args_path = case_id + ".json", case_id + "_args.json"
        hef = {"path": "/existing/" + case_id + ".hef", "sha256": "a" * 64}
        engine = {"path": "/existing/" + case_id + ".engine", "sha256": "b" * 64}
        input_pin = {"path": "/existing/" + case_id + ".npy", "sha256": "c" * 64}
        source_pin = {"path": remote + "/source.py", "sha256": "e" * 64}
        config = {"task": "classification", "identity": {"model_id": model, "case_id": cut,
            "setup_id": "orin_nx_hailo10_01"}, "expected_runtime_artifacts": {"part1_runtime": hef, "engine": engine},
            "input_binding": {"prepared_input": input_pin}}
        (root / config_path).write_text(json.dumps(config))
        (root / args_path).write_text(json.dumps(["--expected-hef-sha256", hef["sha256"],
                                                "--expected-engine-sha256", engine["sha256"]]))
        for name in (config_path, args_path):
            protocol["deploy_files"].append({"local_path": name, "remote_relative": name,
                                              "sha256": m.digest(root / name)})
        protocol["cases"].append({"case_id": case_id, "cut": cut, "model_id": model,
            "config_path": config_path, "config_sha256": m.digest(root / config_path),
            "native_args_path": args_path, "native_args_sha256": m.digest(root / args_path),
            "required_artifacts": [hef, engine, input_pin], "required_sources": [source_pin],
            "runners": {"generic": source_pin, "native": source_pin}})
    for phase, case_ids, variants, blocks, mode in (
        ("pilot", [c["case_id"] for c in protocol["cases"][:2]], list(m.VARIANTS), [0], "canary"),
        ("primary", [c["case_id"] for c in protocol["cases"][:2]], list(m.VARIANTS), list(range(1, 6)), "duration"),
        ("replication", [c["case_id"] for c in protocol["cases"][2:]], ["G_product", "N_product"], list(range(1, 6)), "duration"),
        ("extension", [c["case_id"] for c in protocol["cases"][:2]], list(m.VARIANTS), list(range(6, 11)), "duration")):
        schedule = m.deterministic_schedule(case_ids, variants, blocks, 20261017)
        protocol["phases"][phase] = {"case_ids": case_ids, "variants": variants, "blocks": blocks,
            "mode": mode, "seed": 20261017, "schedule": schedule, "expected_runs": len(schedule)}
    (root / "PROTOCOL.json").write_text(json.dumps(protocol))
    return root, protocol


def controller(frozen):
    return m.Controller(frozen[0], "PROTOCOL.json")


def report_for(c, action, fps=100):
    case = c.cases[action["case_id"]]
    config = json.loads((c.root / case["config_path"]).read_text())
    chain, schedule = m.VARIANTS[action["variant"]]
    identity = {"protocol_sha256": c.protocol_sha256, "identity": config["identity"],
        "artifact_identity": config["expected_runtime_artifacts"], "chain": chain,
        "schedule": schedule, "block": action["block"], "mode": action["mode"]}
    return {**identity, "run_id": m.canonical_hash(identity), "schema": "mechanism-product-workers-v1",
        "status": "complete", "adapter_sha256": c.protocol["adapter"]["sha256"],
        "config_sha256": case["config_sha256"], "product_runner_sha256": case["runners"][chain]["sha256"],
        "diagnostic_adapter": True, "energy_measured": False,
        "worker_cpu_affinity": list(range(8)),
        "loaded_source_hashes": {pin["path"]: pin["sha256"] for pin in case["required_sources"]},
        "completed_work_units": int(fps * 60), "measurement_time_seconds": 60,
        "completed_task_fps": fps, "admission_window_seconds": 60,
        "warmup_duration_s": 30, "accepted_work_drained": True,
        "canary_pass": True, "sequence": [0, 1] * 16}


def start_state(eligible=True):
    value = {"admission": {"eligible": eligible, "exclusive_start_permission": eligible},
        "read_only_start_state": {"/sys/class/thermal/thermal_zone0/temp": "50000",
            "/sys/devices/system/cpu/cpu0/cpufreq/scaling_min_freq": "1984000",
            "/sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq": "1984000",
            "/sys/class/devfreq/17000000.gpu/min_freq": "1173000000",
            "/sys/class/devfreq/17000000.gpu/max_freq": "1173000000",
            "probe_process_cpu_affinity": list(range(8)),
            "power_mode_read_only_query": {"returncode": 0, "output": "NV Power Mode: MAXN_SUPER\n0"}}}
    for core in range(8):
        for field in ("scaling_min_freq", "scaling_max_freq", "scaling_cur_freq"):
            value["read_only_start_state"][f"/sys/devices/system/cpu/cpu{core}/cpufreq/{field}"] = "1984000"
    for index, label in enumerate(("cpu", "gpu", "cv0", "cv1", "cv2", "soc0", "soc1", "soc2")):
        base = f"/sys/class/thermal/cooling_device{index}"
        value["read_only_start_state"][base + "/type"] = label + "-throttle-alert"
        value["read_only_start_state"][base + "/cur_state"] = "0"
    return value


class FakeLock:
    def __init__(self):
        self.held, self.quarantine, self.released = False, False, False

    def acquire(self):
        self.held = True

    def release(self):
        self.held, self.released = False, True

    def commit_quarantine_fence(self, payload):
        assert self.held
        self.quarantine = True


class FakeRuntime:
    def __init__(self, *, eligible=True, unclean=False):
        self.lock = FakeLock()
        self.owner = {"pid": 123}
        self.eligible, self.dirty = eligible, unclean
        self.transport = self
        self.launches = []

    def snapshot(self, pins):
        assert self.lock.held, "admission must occur under product physical lock"
        return start_state(self.eligible)

    def reconcile(self):
        assert self.lock.held
        return not self.dirty

    def unclean(self):
        return self.dirty

    def run(self, command, **kwargs):
        assert self.lock.held
        self.launches.append(command)
        return 0, "fake process completed"


def test_offline_protocol_and_seeded_whole_blocks(frozen):
    root, protocol = frozen
    assert len(m.validate_protocol(protocol, root)) == 4
    for name, count in (("primary", 40), ("replication", 20), ("extension", 40)):
        schedule = protocol["phases"][name]["schedule"]
        assert len(schedule) == count
        assert len({(r["case_id"], r["variant"], r["block"]) for r in schedule}) == count
    broken = copy.deepcopy(protocol)
    broken["phases"]["primary"]["schedule"].reverse()
    with pytest.raises(ValueError, match="schedule"):
        m.validate_protocol(broken, root)


def test_default_cli_is_offline_and_does_not_construct_runtime(frozen, monkeypatch, capsys):
    monkeypatch.setattr(m, "ProductRuntime", lambda *args: pytest.fail("offline CLI initialized product runtime"))
    assert m.main(["--root", str(frozen[0])]) == 0
    assert json.loads(capsys.readouterr().out)["hardware_execution"] is False
    assert not (frozen[0] / "results").exists()


def test_config_tamper_fails_before_runtime(frozen):
    root, protocol = frozen
    (root / protocol["cases"][0]["config_path"]).write_text("{}")
    with pytest.raises(ValueError, match="frozen local file"):
        controller(frozen)


def test_remote_destination_must_be_task_owned(frozen):
    root, protocol = frozen
    protocol["device"]["remote_root"] = "/home/nx/splitpoint_runs"
    with pytest.raises(ValueError, match="report directory"):
        m.validate_protocol(protocol, root)


def test_fresh_process_command_and_unique_ids(frozen):
    c = controller(frozen)
    cells = c.protocol["phases"]["primary"]["schedule"]
    actions = [c.action("primary", cell) for cell in cells]
    assert len({action["run_id"] for action in actions}) == 40
    argv = c.argv(actions[0], c.remote("runs/fresh"))
    assert argv[0] == "/home/nx/venvs/hailo10/bin/python"
    assert "--protocol-sha256" in argv and "--config" in argv
    assert not any("build" in value for value in argv)


@pytest.mark.parametrize("change", ["drain", "source", "protocol", "rate", "short_window", "artifact", "affinity"])
def test_remote_report_rejects_semantic_or_identity_mismatch(frozen, change):
    c = controller(frozen)
    action = c.action("primary", c.protocol["phases"]["primary"]["schedule"][0])
    report = report_for(c, action)
    c.validate_report(action, report)
    if change == "drain": report["accepted_work_drained"] = False
    if change == "source": report["loaded_source_hashes"]["/unfrozen/source.py"] = "a" * 64
    if change == "protocol": report["protocol_sha256"] = "0" * 64
    if change == "rate": report["completed_task_fps"] = 999
    if change == "short_window": report["measurement_time_seconds"] = 59
    if change == "artifact": report["artifact_identity"]["engine"]["sha256"] = "f" * 64
    if change == "affinity": report.pop("worker_cpu_affinity")
    with pytest.raises(ValueError):
        c.validate_report(action, report)


def test_completed_resume_requires_unchanged_matching_report(frozen):
    c = controller(frozen)
    action = c.action("primary", c.protocol["phases"]["primary"]["schedule"][0])
    path = c.root / "saved_report.json"
    m.atomic_json(path, report_for(c, action))
    attempt = {**action, "status": "completed", "included": True,
               "report_path": str(path), "report_sha256": m.digest(path)}
    c.progress["attempts"].append(attempt)
    assert c.perform(action)
    path.write_text("{}")
    with pytest.raises(ValueError, match="report changed"):
        c.perform(action)


def test_started_missing_report_is_preserved_and_never_relaunched(frozen, monkeypatch):
    c = controller(frozen)
    action = c.action("primary", c.protocol["phases"]["primary"]["schedule"][0])
    c.progress["attempts"].append({**action, "status": "started", "attempt_id": "existing"})
    monkeypatch.setattr(c, "collect", lambda *args: None)
    assert not c.perform(action)
    assert c.progress["attempts"][0]["status"] == "uncertain"
    assert len(json.loads(c.progress_path.read_text())["attempts"]) == 1


def test_actual_process_attempt_has_before_after_and_atomic_progress(frozen, monkeypatch):
    c = controller(frozen)
    runtime = FakeRuntime()
    c.runtime, c.sleep = runtime, lambda seconds: None
    runtime.lock.acquire()
    action = c.action("primary", c.protocol["phases"]["primary"]["schedule"][0])
    def collected(action, attempt):
        report = report_for(c, action)
        path = c.root / "result.json"
        m.atomic_json(path, report)
        return report, str(path), m.digest(path)
    monkeypatch.setattr(c, "collect", collected)
    assert c.perform(action)
    saved = json.loads(c.progress_path.read_text())["attempts"][0]
    assert saved["status"] == "completed" and saved["included"]
    assert Path(saved["before_snapshot"]).is_file() and Path(saved["after_snapshot"]).is_file()
    assert len(runtime.launches) == 1 and "exec " in runtime.launches[0]
    assert c.perform(action) and len(runtime.launches) == 1


def test_busy_admission_never_launches(frozen):
    c = controller(frozen)
    c.runtime = FakeRuntime(eligible=False)
    c.runtime.lock.acquire()
    action = c.action("primary", c.protocol["phases"]["primary"]["schedule"][0])
    assert not c.perform(action)
    assert not c.runtime.launches and not c.progress["attempts"]


def test_uncertain_owned_lease_quarantines_and_releases_without_killing(frozen):
    c = controller(frozen)
    c.runtime = FakeRuntime(unclean=True)
    assert not c.execute("pilot")
    assert c.runtime.lock.quarantine and c.runtime.lock.released
    assert not c.runtime.launches


def test_existing_remote_source_mismatch_is_preserved(frozen):
    c = controller(frozen)
    c.runtime = FakeRuntime()
    c.runtime.lock.acquire()
    c.runtime.run_read_only = lambda *args, **kwargs: (1, "existing source mismatch")
    with pytest.raises(ValueError, match="preserved"):
        c.stage(next(iter(c.cases.values())))
    assert not c.runtime.launches


def test_canary_reference_tensor_cannot_escape_own_process_output(frozen):
    c = controller(frozen)
    attempt = {"remote_out": c.remote("runs/own"), "attempt_id": "owned"}
    manifest = [{"input_path": "/outside/input.npy", "input_sha256": "a" * 64, "outputs": {}}] * 2
    with pytest.raises(ValueError, match="exact process output"):
        c.collect_canary_arrays(attempt, {"reference_manifest": manifest})


def test_temperature_heating_descriptive_but_clocks_and_power_checked(frozen):
    policy = frozen[1]["device"]["state_policy"]
    state = start_state()
    hot = copy.deepcopy(state)
    hot["read_only_start_state"]["/sys/class/thermal/thermal_zone0/temp"] = "75000"
    assert not m.state_comparison(state, hot, policy)["comparable"]
    assert m.state_comparison(state, hot, policy, end=True)["comparable"]
    hot["read_only_start_state"]["/sys/class/devfreq/17000000.gpu/max_freq"] = "600000000"
    assert not m.state_comparison(state, hot, policy, end=True)["comparable"]


def test_throttle_alert_excluded_at_start_and_end_but_fan_allowed(frozen):
    policy = frozen[1]["device"]["state_policy"]
    state = start_state()
    state["read_only_start_state"]["/sys/class/thermal/cooling_device20/type"] = "pwm-fan"
    state["read_only_start_state"]["/sys/class/thermal/cooling_device20/cur_state"] = "3"
    assert m.state_comparison(state, state, policy)["comparable"]
    state["read_only_start_state"]["/sys/class/thermal/cooling_device0/cur_state"] = "1"
    assert not m.state_comparison(state, state, policy)["comparable"]
    assert not m.state_comparison(state, state, policy, end=True)["comparable"]


def test_extension_requires_all40_exact_reports_and_true_predeclared_trigger(frozen):
    c = controller(frozen)
    hashes = {}
    for cell in c.protocol["phases"]["primary"]["schedule"]:
        action = c.action("primary", cell)
        path = c.root / (action["run_id"] + ".json")
        m.atomic_json(path, report_for(c, action))
        sha = m.digest(path)
        c.progress["attempts"].append({**action, "status": "completed", "included": True,
            "report_path": str(path), "report_sha256": sha})
        hashes[action["run_id"]] = sha
    receipt = {"protocol_sha256": c.protocol_sha256, "rule_id": m.EXTENSION_RULE,
               "extend": True, "primary_report_sha256": hashes}
    assert c.check_extension(receipt)["interaction"] == [0, 0]
    receipt["primary_report_sha256"] = {}
    with pytest.raises(ValueError, match="all40"):
        c.check_extension(receipt)


def test_atomic_write_preserves_previous_complete_file_on_serialization_error(tmp_path):
    path = tmp_path / "progress.json"
    m.atomic_json(path, {"complete": True})
    with pytest.raises(ValueError):
        m.atomic_json(path, {"bad": float("nan")})
    assert json.loads(path.read_text()) == {"complete": True}


def deployment_fixture(frozen, tmp_path):
    c = controller(frozen)
    files = [*c.protocol["deploy_files"], {"local_path": str(c.protocol_path),
              "remote_relative": "PROTOCOL.json", "sha256": c.protocol_sha256}]
    archive, manifest = c.deployment_archive(files)
    target = tmp_path / "simulated_remote"
    target.mkdir()
    upload = target / "unique.upload.partial"
    shutil.copyfile(archive, upload)
    params = {"remote_root": str(target), "manifest": manifest,
              "archive_path": str(upload), "archive_sha256": m.digest(archive)}
    return c, files, archive, target, params


def test_zip_archive_is_deterministic_and_contains_only_declared_pinned_bytes(frozen, tmp_path):
    c, files, archive, target, params = deployment_fixture(frozen, tmp_path)
    again, manifest = c.deployment_archive(list(reversed(files)))
    assert again == archive and manifest == params["manifest"]
    with zipfile.ZipFile(archive) as bundle:
        assert bundle.namelist() == sorted(item["remote_relative"] for item in manifest)
        for item in manifest:
            assert hashlib.sha256(bundle.read(item["remote_relative"])).hexdigest() == item["sha256"]
            assert bundle.getinfo(item["remote_relative"]).date_time == (1980, 1, 1, 0, 0, 0)


def test_batch_install_and_resume_verify_all_files_without_overwriting(frozen, tmp_path):
    c, files, archive, target, params = deployment_fixture(frozen, tmp_path)
    assert m.batch_deploy(mode="inspect", **params)["status"] == "missing"
    installed = m.batch_deploy(mode="install", **params)
    assert installed["installed_files"] == len(params["manifest"])
    assert not Path(params["archive_path"]).exists()
    params["archive_path"] = installed["archive_path"]
    inodes = {item["remote_relative"]: (target / item["remote_relative"]).stat().st_ino for item in params["manifest"]}
    assert m.batch_deploy(mode="inspect", **params)["status"] == "ready"
    assert m.batch_deploy(mode="install", **params)["installed_files"] == 0
    assert inodes == {item["remote_relative"]: (target / item["remote_relative"]).stat().st_ino for item in params["manifest"]}


def test_batch_existing_mismatch_rejects_before_writing_any_missing_file(frozen, tmp_path):
    c, files, archive, target, params = deployment_fixture(frozen, tmp_path)
    first = params["manifest"][0]["remote_relative"]
    mismatch = target / first
    mismatch.parent.mkdir(parents=True, exist_ok=True)
    mismatch.write_text("preserve previous data")
    for mode in ("inspect", "install"):
        with pytest.raises(ValueError, match="mismatch preserved"):
            m.batch_deploy(mode=mode, **params)
    assert mismatch.read_text() == "preserve previous data"
    assert not (target / params["manifest"][1]["remote_relative"]).exists()


@pytest.mark.parametrize("attack", ["traversal", "symlink", "unlisted", "wrong_bytes"])
def test_batch_rejects_unsafe_zip_before_any_member_write(frozen, tmp_path, attack):
    c, files, archive, target, params = deployment_fixture(frozen, tmp_path)
    upload = Path(params["archive_path"])
    payload = b"correct source bytes"
    declared = "safe/source.py"
    params["manifest"] = [{"remote_relative": declared, "sha256": hashlib.sha256(payload).hexdigest(), "size_bytes": len(payload)}]
    with zipfile.ZipFile(upload, "w") as bundle:
        name = "../outside.py" if attack == "traversal" else declared
        info = zipfile.ZipInfo(name)
        info.create_system = 3
        info.external_attr = ((stat.S_IFLNK if attack == "symlink" else stat.S_IFREG) | 0o644) << 16
        bundle.writestr(info, b"incorrect bytes!!!!!" if attack == "wrong_bytes" else payload)
        if attack == "unlisted":
            bundle.writestr("unlisted.py", b"extra")
    params["archive_sha256"] = m.digest(upload)
    with pytest.raises(ValueError):
        m.batch_deploy(mode="install", **params)
    assert not (target / "safe").exists()
    assert not (target.parent / "outside.py").exists()


def test_batch_rejects_destination_symlink_and_preserves_target(frozen, tmp_path):
    c, files, archive, target, params = deployment_fixture(frozen, tmp_path)
    outside = tmp_path / "outside"
    outside.write_text("keep")
    (target / params["manifest"][0]["remote_relative"]).symlink_to(outside)
    with pytest.raises(ValueError, match="symlink preserved"):
        m.batch_deploy(mode="install", **params)
    assert outside.read_text() == "keep"


def test_generated_batch_command_runs_with_stdlib_only(frozen, tmp_path):
    c, files, archive, target, params = deployment_fixture(frozen, tmp_path)
    command = c.batch_command({**params, "mode": "install"})
    # Local scratch files only: this executes the exact generated Python argv,
    # without an SSH client, product runtime, accelerator import or device probe.
    result = subprocess.run(shlex.split(command), capture_output=True, text=True, timeout=10)
    assert result.returncode == 0, result.stderr
    assert json.loads(result.stdout)["verified_files"] == len(params["manifest"])


def test_batch_stage_uses_one_source_probe_one_upload_and_one_install(frozen):
    c = controller(frozen)
    runtime = FakeRuntime()
    c.runtime = runtime
    runtime.lock.acquire()
    probes, uploads, writes = [], [], []
    def inspect_command(command, **kwargs):
        probes.append(command)
        params = json.loads(shlex.split(command)[-1])
        return 0, json.dumps({"status": "missing", "missing": [p["remote_relative"] for p in params["manifest"]],
                              "archive_available": False})
    def upload(local, remote, **kwargs):
        uploads.append((local, remote))
        return 0, ""
    def write_command(command, **kwargs):
        writes.append(command)
        if command.startswith("mkdir -p "):
            return 0, ""
        params = json.loads(shlex.split(command)[-1])
        return 0, json.dumps({"status": "installed", "verified_files": len(params["manifest"])})
    runtime.run_read_only, runtime.scp_upload, runtime.run = inspect_command, upload, write_command
    cases = list(c.cases.values())
    assert c.stage(cases[0]) and c.stage(cases[1])
    assert len(probes) == 1 and len(uploads) == 1 and len(writes) == 2
    assert "_deployment-" in uploads[0][1] and uploads[0][1].endswith(".partial")
