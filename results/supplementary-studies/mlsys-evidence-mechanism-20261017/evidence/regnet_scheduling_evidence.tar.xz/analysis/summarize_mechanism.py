#!/usr/bin/env python3
"""Offline paired-block Phase B analysis. Never imports a runtime or uses devices.

Run with --protocol FROZEN.json --output-prefix results/mechanism_analysis.
The default progress path follows the actual product-backed controller. Missing
or excluded cells remain explicit. Only complete admitted randomized blocks enter
paired estimates. Pilot, primary, extension, replication and R14 remain separate.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import random
import statistics
from typing import Any


VARIANTS = {"G_product": ("generic", "product"), "N_product": ("native", "product"),
            "G_single": ("generic", "single"), "N_single": ("native", "single")}
PAIRS = {"regnet_x_1_6gf": ("b052", "b123"), "resnet50": ("b002", "b095")}
RULE = "primary_ratio_or_interaction_ci_includes_null"
SHA = re.compile(r"[0-9a-f]{64}\Z")
# Two-sided Student-t 95% quantiles. The frozen study permits at most ten blocks.
T95 = {1: 12.706204736432095, 2: 4.302652729696142, 3: 3.182446305284263,
       4: 2.7764451051977987, 5: 2.570581835636314, 6: 2.4469118511449692,
       7: 2.3646242515927844, 8: 2.306004135204166, 9: 2.2621571628540993}


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def load_json(path):
    return json.loads(Path(path).read_text())


def task_path(root, value, *, original_task_name=None):
    """Resolve controller paths, including an explicitly relocated review pack."""
    path = Path(value)
    if not path.is_absolute():
        result = (root / path).resolve()
    elif path.is_relative_to(root):
        result = path.resolve()
    else:
        # The frozen remote_root retains the original task directory name even
        # when a ZIP is extracted into a renamed directory. Relocate only these
        # exact known report prefixes; do not search for matching filenames.
        names = {root.name, original_task_name} - {None}
        prefixes = [Path(home)/"Reports"/name for name in names for home in ("/home/kmika", "/home/nx")]
        matches = [prefix for prefix in prefixes if path.is_relative_to(prefix)]
        if len(matches) != 1:
            raise ValueError("source_path_outside_task:" + str(value))
        result = (root/path.relative_to(matches[0])).resolve()
    if not result.is_relative_to(root):
        raise ValueError("source_path_outside_task:" + str(value))
    return result


def write_csv(path, rows, fallback):
    fields = list(dict.fromkeys(k for row in rows for k in row)) or fallback
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, sort_keys=True) if isinstance(v, (list, dict)) else v
                             for k, v in row.items()})


def log_summary(values):
    """Summarize block log-ratios; no within-process frame pseudoreplication."""
    count = len(values)
    if not count:
        return dict(n_blocks=0, mean_log=None, sd_log=None, se_log=None, df=None,
                    t95=None, log_ci95_low=None, log_ci95_high=None,
                    geometric_mean=None, ci95_low=None, ci95_high=None)
    mean = statistics.mean(values)
    result = dict(n_blocks=count, mean_log=mean, sd_log=None, se_log=None, df=None,
                  t95=None, log_ci95_low=None, log_ci95_high=None,
                  geometric_mean=math.exp(mean), ci95_low=None, ci95_high=None)
    if count > 1:
        df = count - 1
        if df not in T95:
            raise ValueError("block_count_exceeds_fixed_t95_table")
        sd = statistics.stdev(values)
        se = sd / math.sqrt(count)
        half = T95[df] * se
        result.update(sd_log=sd, se_log=se, df=df, t95=T95[df], log_ci95_low=mean-half,
                      log_ci95_high=mean+half, ci95_low=math.exp(mean-half), ci95_high=math.exp(mean+half))
    return result


def deterministic_schedule(case_ids, variants, blocks, seed):
    rng = random.Random(seed)
    result = []
    for block in blocks:
        cells = [(case, variant) for case in case_ids for variant in variants]
        rng.shuffle(cells)
        result.extend({"case_id": case, "variant": variant, "block": block} for case, variant in cells)
    return result


def validate_schedule(phase, spec, cases):
    if (phase not in {"pilot", "primary", "extension", "replication"}
            or type(spec.get("seed")) is not int or spec.get("mode") not in {"duration", "canary"}
            or not spec.get("case_ids") or not spec.get("variants") or not spec.get("blocks")
            or len(set(spec["case_ids"])) != len(spec["case_ids"])
            or len(set(spec["variants"])) != len(spec["variants"])
            or len(set(spec["blocks"])) != len(spec["blocks"])
            or any(c not in cases for c in spec["case_ids"])
            or any(v not in VARIANTS for v in spec["variants"])
            or any(type(block) is not int or block < 0 for block in spec["blocks"])):
        raise ValueError("invalid_frozen_schedule_specification")
    expected = deterministic_schedule(spec["case_ids"], spec["variants"], spec["blocks"], spec["seed"])
    if spec.get("schedule") != expected or spec.get("expected_runs") != len(expected):
        raise ValueError("schedule_differs_from_frozen_seeded_full_cartesian_blocks")
    if phase in {"primary", "extension"}:
        identities = {(cases[c]["model_id"], cases[c]["cut"]) for c in spec["case_ids"]}
        if (identities != {("regnet_x_1_6gf", "b052"), ("regnet_x_1_6gf", "b123")}
                or set(spec["variants"]) != set(VARIANTS) or spec["mode"] != "duration"
                or spec["blocks"] != (list(range(1, 6)) if phase == "primary" else list(range(6, 11)))):
            raise ValueError("primary_or_extension_design_drift")
    if phase == "replication":
        identities = {(cases[c]["model_id"], cases[c]["cut"]) for c in spec["case_ids"]}
        if (identities != {("resnet50", "b002"), ("resnet50", "b095")}
                or len(spec["variants"]) != 2 or spec["mode"] != "duration"
                or spec["blocks"] != list(range(1, 6))):
            raise ValueError("replication_design_drift")


def retry_lineage_errors(current_attempts, action):
    errors = []
    for i, (_, attempt) in enumerate(current_attempts):
        if attempt.get("attempt_id") != action["run_id"] + f"_attempt{i+1:02d}":
            errors.append("retry_lineage_attempt_id_not_sequential")
        if any(attempt.get(key) != expected for key, expected in action.items()):
            errors.append("retry_lineage_action_identity_changed")
        if i:
            prior = current_attempts[i-1][1]
            if prior.get("status") != "failed":
                errors.append("retry_lineage_prior_attempt_not_failed")
            cause = attempt.get("retry_cause") or {}
            if (cause.get("run_id") != action["run_id"] or cause.get("protocol_sha256") != action["protocol_sha256"]
                    or cause.get("cause_corrected") is not True or not cause.get("reason")
                    or cause.get("technical_error") not in {"launcher", "transport", "implementation"}):
                errors.append("retry_lineage_corrected_matching_technical_cause_missing")
    return list(dict.fromkeys(errors))


def action_for(protocol, protocol_sha, case, config, phase, cell):
    identity = {"protocol_sha256": protocol_sha, "artifact_identity": config["expected_runtime_artifacts"],
                "case_id": case["case_id"], "cut": case["cut"], "variant": cell["variant"],
                "block": cell["block"], "phase": phase, "mode": protocol["phases"][phase]["mode"]}
    return {**identity, "run_id": canonical_hash(identity)}


def validate_report(protocol, protocol_sha, case, config, action, report):
    chain, schedule = VARIANTS[action["variant"]]
    identity = {"protocol_sha256": protocol_sha, "identity": config["identity"],
                "artifact_identity": config["expected_runtime_artifacts"], "chain": chain,
                "schedule": schedule, "block": action["block"], "mode": action["mode"]}
    expected = {**identity, "run_id": canonical_hash(identity), "schema": "mechanism-product-workers-v1",
                "status": "complete", "adapter_sha256": protocol["adapter"]["sha256"],
                "config_sha256": case["config_sha256"], "diagnostic_adapter": True, "energy_measured": False,
                "product_runner_sha256": case["runners"][chain]["sha256"]}
    errors = ["report_identity_mismatch:" + key for key, value in expected.items() if report.get(key) != value]
    sources = {item["path"]: item["sha256"] for item in case["required_sources"]}
    loaded = report.get("loaded_source_hashes")
    if not isinstance(loaded, dict) or not loaded or any(not isinstance(s, str) or not SHA.fullmatch(s)
        or p not in sources or sources[p] != s for p, s in loaded.items()):
        errors.append("report_loaded_source_not_frozen")
    if report.get("worker_cpu_affinity") != protocol["device"]["state_policy"]["affinity"]:
        errors.append("report_worker_affinity_mismatch")
    if action["mode"] == "canary":
        if report.get("canary_pass") is not True or len(report.get("sequence", [])) != 32:
            errors.append("canary_not_completed_32_tasks")
    else:
        count, seconds, fps = (report.get(k) for k in ("completed_work_units", "measurement_time_seconds", "completed_task_fps"))
        if (type(count) is not int or count <= 0 or type(seconds) not in (int, float)
                or not math.isfinite(seconds) or seconds < 60 or type(fps) not in (int, float)
                or not math.isfinite(fps) or fps <= 0
                or not math.isclose(fps, count / seconds, rel_tol=1e-9)
                or report.get("admission_window_seconds") != 60 or report.get("warmup_duration_s") != 30
                or report.get("accepted_work_drained") is not True):
            errors.append("duration_count_time_or_drain_invalid")
    return errors


def read_data(protocol_path, progress_path=None, *, root=None):
    protocol_path = Path(protocol_path).resolve()
    root = Path(root).resolve() if root else protocol_path.parent
    protocol, protocol_sha = load_json(protocol_path), digest(protocol_path)
    if protocol.get("schema") != "mechanism-controller-v1":
        raise ValueError("unsupported_protocol_schema")
    remote_root = Path(protocol.get("device", {}).get("remote_root", "/unknown/unknown"))
    original_task_name = remote_root.parent.name if remote_root.is_relative_to(Path('/home/nx/Reports')) else root.name
    cases, configs, config_errors = {}, {}, {}
    for case in protocol["cases"]:
        key = case["case_id"]
        if key in cases or case["model_id"] not in PAIRS:
            raise ValueError("duplicate_or_unknown_case")
        cases[key] = case
        try:
            path = task_path(root, case["config_path"], original_task_name=original_task_name)
            if digest(path) != case["config_sha256"]:
                raise ValueError("config_file_hash_mismatch")
            config = load_json(path)
            if (config["identity"]["model_id"] != case["model_id"]
                    or config["identity"]["case_id"] != case["cut"]):
                raise ValueError("config_model_cut_mismatch")
            configs[key] = config
        except (OSError, ValueError, KeyError) as failure:
            config_errors[key] = str(failure)
    path = Path(progress_path).resolve() if progress_path else root / "results/mechanism" / protocol_sha / "PROGRESS.json"
    if path.exists():
        progress = load_json(path)
        if progress.get("schema") != "mechanism-progress-v1" or progress.get("protocol_sha256") != protocol_sha:
            raise ValueError("progress_does_not_match_exact_protocol")
        progress_sha = digest(path)
    else:
        progress = {"attempts": [], "events": []}
        progress_sha = None
    attempts = progress.get("attempts", [])
    if not isinstance(attempts, list):
        raise ValueError("progress_attempts_not_list")
    by_run = {}
    for i, attempt in enumerate(attempts):
        by_run.setdefault(attempt.get("run_id"), []).append((i, attempt))
    rows, raw_reports, known_run_ids, attempt_rows = [], {}, set(), []
    for phase, spec in protocol["phases"].items():
        validate_schedule(phase, spec, cases)
        seen_cells = set()
        for order, cell in enumerate(spec["schedule"]):
            key = cell["case_id"]
            case = cases[key]
            cell_key = (key, cell["variant"], cell["block"])
            if cell_key in seen_cells:
                raise ValueError("duplicate_scheduled_cell")
            seen_cells.add(cell_key)
            row = {"phase": phase, "mode": spec["mode"], "model": case["model_id"], "case_id": key,
                   "cut": case["cut"], "variant": cell["variant"], "block": cell["block"],
                   "schedule_order": order+1, "controller_run_id": None, "attempt_count": 0,
                   "last_status": "not_started", "source_valid": False, "included": False,
                   "completed_task_fps": None, "report_path": None, "report_sha256": None,
                   "exclusion_reasons": []}
            if key in config_errors:
                row["exclusion_reasons"] = ["config_invalid:" + config_errors[key]]
                rows.append(row)
                continue
            action = action_for(protocol, protocol_sha, case, configs[key], phase, cell)
            run_id = action["run_id"]
            if run_id in known_run_ids:
                raise ValueError("duplicate_controller_run_identity")
            known_run_ids.add(run_id)
            current_attempts = by_run.get(run_id, [])
            row.update(controller_run_id=run_id, attempt_count=len(current_attempts))
            if not current_attempts:
                row["exclusion_reasons"] = ["not_started"]
            else:
                _, last = current_attempts[-1]
                row.update(last_status=last.get("status"), last_attempt_id=last.get("attempt_id"))
                errors = retry_lineage_errors(current_attempts, action)
                for name, expected in action.items():
                    if last.get(name) != expected:
                        errors.append("controller_attempt_identity_mismatch:" + name)
                if last.get("status") != "completed":
                    errors.append("last_attempt_not_completed:" + str(last.get("status")))
                if last.get("included") is not True:
                    errors.append("controller_not_admitted")
                if last.get("state_check", {}).get("comparable") is not True:
                    errors.append("controller_end_state_not_comparable")
                report = None
                if last.get("status") == "completed":
                    try:
                        report_path = task_path(root, last["report_path"], original_task_name=original_task_name)
                        report_sha = last["report_sha256"]
                        if not SHA.fullmatch(report_sha) or digest(report_path) != report_sha:
                            raise ValueError("raw_report_hash_mismatch")
                        report = load_json(report_path)
                        report_errors = validate_report(protocol, protocol_sha, case, configs[key], action, report)
                        errors.extend(report_errors)
                        row.update(source_valid=not report_errors, report_path=str(report_path), report_sha256=report_sha)
                        row.update(worker_pid=report.get("pid"), started_time_ns=report.get("started_time_ns"))
                        if spec["mode"] == "duration":
                            row.update(completed_task_fps=report.get("completed_task_fps"),
                                       completed_work_units=report.get("completed_work_units"),
                                       measurement_time_seconds=report.get("measurement_time_seconds"))
                        else:
                            row.update(canary_pass=report.get("canary_pass"),
                                       historical_functional_reference_match=report.get("historical_functional_reference_match"))
                    except (OSError, ValueError, KeyError) as failure:
                        errors.append("raw_report_invalid:" + str(failure))
                row["exclusion_reasons"] = errors
                row["included"] = not errors
                if report is not None:
                    raw_reports[run_id] = report
            rows.append(row)
    # Preserve failures and superseded attempts. These never become replicates.
    last_indices = {pairs[-1][0] for pairs in by_run.values()}
    for i, attempt in enumerate(attempts):
        attempt_rows.append({"progress_index": i, "attempt_id": attempt.get("attempt_id"),
            "controller_run_id": attempt.get("run_id"), "phase": attempt.get("phase"),
            "case_id": attempt.get("case_id"), "cut": attempt.get("cut"), "variant": attempt.get("variant"),
            "block": attempt.get("block"), "mode": attempt.get("mode"), "status": attempt.get("status"),
            "included_recorded": attempt.get("included"), "is_last_attempt": i in last_indices,
            "registered_run_id": attempt.get("run_id") in known_run_ids,
            "report_path": attempt.get("report_path"), "report_sha256": attempt.get("report_sha256"),
            "reason": attempt.get("reason"), "state_reasons": attempt.get("state_check", {}).get("reasons", []),
            "retry_cause": attempt.get("retry_cause")})
    return dict(root=root, protocol=protocol, protocol_sha256=protocol_sha, progress_path=path,
                progress_sha256=progress_sha, cells=rows, attempts=attempt_rows, reports=raw_reports,
                config_errors=config_errors, unknown_attempts=sum(not r["registered_run_id"] for r in attempt_rows),
                progress_events=progress.get("events", []), original_task_name=original_task_name)


def analyze_blocks(data):
    protocol = data["protocol"]
    block_rows, summaries, phase_status = [], [], []
    for phase, spec in protocol["phases"].items():
        cells = [r for r in data["cells"] if r["phase"] == phase]
        full_blocks = []
        for block in spec["blocks"]:
            selected = [r for r in cells if r["block"] == block]
            expected_count = len(spec["case_ids"]) * len(spec["variants"])
            full = len(selected) == expected_count and all(r["included"] for r in selected)
            if full:
                full_blocks.append(block)
            reasons = [r["case_id"]+":"+r["variant"]+":"+"|".join(r["exclusion_reasons"])
                       for r in selected if not r["included"]]
            if len(selected) != expected_count:
                reasons.append("scheduled_block_not_complete_factor_cells")
            if spec["mode"] != "duration":
                block_rows.append({"phase": phase, "mode": spec["mode"], "block": block,
                    "contrast": "canary_only", "whole_block_included": full,
                    "expected_cells": expected_count, "admitted_cells": sum(r["included"] for r in selected),
                    "ratio": None, "log_ratio": None, "block_exclusion_reasons": reasons})
                continue
            for model in sorted({r["model"] for r in selected}):
                first, second = PAIRS[model]
                ratios = {}
                for variant in spec["variants"]:
                    cut_rows = {r["cut"]: r for r in selected if r["model"] == model and r["variant"] == variant}
                    value = (math.log(cut_rows[second]["completed_task_fps"] / cut_rows[first]["completed_task_fps"])
                             if full and first in cut_rows and second in cut_rows else None)
                    if value is not None:
                        ratios[variant] = value
                    block_rows.append({"phase": phase, "mode": "duration", "model": model,
                        "block": block, "contrast": variant, "denominator_cut": first, "numerator_cut": second,
                        "whole_block_included": full, "expected_cells": expected_count,
                        "admitted_cells": sum(r["included"] for r in selected),
                        "ratio": math.exp(value) if value is not None else None, "log_ratio": value,
                        "block_exclusion_reasons": reasons})
                contrasts = {}
                if {"G_product", "G_single"} <= set(spec["variants"]):
                    contrasts["generic_schedule_effect"] = (ratios["G_product"] - ratios["G_single"]
                        if {"G_product", "G_single"} <= ratios.keys() else None)
                if {"N_product", "N_single"} <= set(spec["variants"]):
                    contrasts["native_schedule_effect"] = (ratios["N_product"] - ratios["N_single"]
                        if {"N_product", "N_single"} <= ratios.keys() else None)
                if set(VARIANTS) <= set(spec["variants"]):
                    contrasts["interaction"] = (ratios["N_product"] - ratios["G_product"]
                        - ratios["N_single"] + ratios["G_single"] if set(VARIANTS) <= ratios.keys() else None)
                for name, value in contrasts.items():
                    block_rows.append({"phase": phase, "mode": "duration", "model": model,
                        "block": block, "contrast": name, "denominator_cut": first, "numerator_cut": second,
                        "whole_block_included": full, "expected_cells": expected_count,
                        "admitted_cells": sum(r["included"] for r in selected),
                        "ratio": math.exp(value) if value is not None else None, "log_ratio": value,
                        "block_exclusion_reasons": reasons})
        phase_status.append({"phase": phase, "mode": spec["mode"], "expected_runs": len(spec["schedule"]),
            "recorded_attempts": sum(r["phase"] == phase for r in data["attempts"]),
            "admitted_last_attempt_cells": sum(r["included"] for r in cells),
            "not_started_cells": sum(r["last_status"] == "not_started" for r in cells),
            "excluded_or_incomplete_cells": sum(not r["included"] for r in cells),
            "planned_blocks": len(spec["blocks"]), "complete_admitted_blocks": len(full_blocks),
            "included_block_ids": full_blocks, "phase_complete": len(full_blocks) == len(spec["blocks"]),
            "pooled_with_other_phase": False})
        groups = sorted({(r.get("model"), r["contrast"]) for r in block_rows if r["phase"] == phase and r["mode"] == "duration"})
        for model, contrast in groups:
            values = [r["log_ratio"] for r in block_rows if r["phase"] == phase and r.get("model") == model
                      and r["contrast"] == contrast and r["log_ratio"] is not None]
            estimates = log_summary(values)
            summaries.append({"cohort": phase, "model": model, "contrast": contrast,
                "planned_blocks": len(spec["blocks"]), **estimates,
                "inference_status": ("complete_frozen_series" if len(values) == len(spec["blocks"])
                                     else "partial_series_descriptive" if values else "not_estimable"),
                "null_multiplier": 1, "null_log": 0,
                "ci_includes_null": (estimates["log_ci95_low"] <= 0 <= estimates["log_ci95_high"]
                                     if estimates["log_ci95_low"] is not None else None),
                "block_unit": "independent_processes_paired_in_full_randomized_block"})
    return block_rows, summaries, phase_status


def extension_receipt(data, summaries):
    protocol = data["protocol"]
    base = {"protocol_sha256": data["protocol_sha256"], "rule_id": RULE, "extend": None,
            "primary_report_sha256": {}, "status": "not_evaluable", "log_ratio_intervals95": {}}
    if "primary" not in protocol["phases"]:
        return {**base, "reason": "no_primary_phase_in_this_frozen_protocol"}
    spec = protocol["phases"]["primary"]
    primary = [r for r in data["cells"] if r["phase"] == "primary"]
    if (protocol.get("extension_trigger_rule_id") != RULE or spec["blocks"] != [1, 2, 3, 4, 5]
            or len(primary) != 40 or set(spec["variants"]) != set(VARIANTS)):
        return {**base, "reason": "protocol_does_not_define_the_controller_40_run_trigger"}
    if not all(r["included"] for r in primary):
        return {**base, "reason": "five_complete_admitted_primary_blocks_required",
                "missing_or_excluded_primary_cells": sum(not r["included"] for r in primary)}
    selected = {r["contrast"]: r for r in summaries if r["cohort"] == "primary" and r["model"] == "regnet_x_1_6gf"}
    intervals = {}
    for name in ("G_product", "N_product", "interaction"):
        row = selected[name]
        if row["n_blocks"] != 5:
            return {**base, "reason": "five_valid_paired_log_values_required"}
        intervals[name] = [row["log_ci95_low"], row["log_ci95_high"]]
    triggered = any(lo <= 0 <= hi for lo, hi in intervals.values())
    return {**base, "extend": triggered, "status": "evaluated", "log_ratio_intervals95": intervals,
            "reason": "prespecified_log_interval_contains_zero" if triggered else "all_three_intervals_exclude_zero",
            "primary_report_sha256": {r["controller_run_id"]: r["report_sha256"] for r in primary},
            "extension_phase_registered": "extension" in protocol["phases"],
            "method": "mean_log_plus_minus_t95_df4_times_sample_sd_log_over_sqrt5",
            "t95_df4": T95[4]}


def combined_extension(data, summaries, block_rows, receipt):
    """Add the final ten-block estimate only after the authorized fixed extension."""
    protocol = data["protocol"]
    result = {"included": False, "reason": "extension_not_triggered_or_not_registered"}
    if receipt.get("extend") is not True or "extension" not in protocol["phases"]:
        return [], result
    primary, extension = protocol["phases"]["primary"], protocol["phases"]["extension"]
    if (primary["blocks"] != [1, 2, 3, 4, 5] or extension["blocks"] != [6, 7, 8, 9, 10]
            or set(primary["case_ids"]) != set(extension["case_ids"])
            or set(primary["variants"]) != set(extension["variants"])
            or extension["mode"] != "duration"):
        return [], {"included": False, "reason": "extension_does_not_preserve_fixed_cases_variants_and_blocks"}
    events = [event for event in data["progress_events"] if event.get("status") == "extension_trigger_verified"]
    authorized = []
    for event in events:
        intervals = event.get("log_ratio_intervals95", {})
        matches = set(intervals) == set(receipt["log_ratio_intervals95"])
        if matches:
            matches = all(len(intervals[key]) == 2 and all(math.isclose(a, b, abs_tol=1e-12, rel_tol=1e-12)
                for a, b in zip(intervals[key], target)) for key, target in receipt["log_ratio_intervals95"].items())
        if matches and SHA.fullmatch(event.get("trigger_receipt_sha256", "")):
            authorized.append(event)
    if not authorized:
        return [], {"included": False, "reason": "matching_controller_extension_authorization_event_missing"}
    cells = [r for r in data["cells"] if r["phase"] in {"primary", "extension"}]
    if len(cells) != 80 or not all(r["included"] for r in cells):
        return [], {"included": False, "reason": "all_ten_complete_admitted_blocks_required",
                    "admitted_cells": sum(r["included"] for r in cells)}
    combined = []
    for model, contrast in sorted({(r["model"], r["contrast"]) for r in summaries if r["cohort"] == "primary"}):
        selected = [r for r in block_rows if r["phase"] in {"primary", "extension"}
                    and r.get("model") == model and r["contrast"] == contrast and r["log_ratio"] is not None]
        if len(selected) != 10 or {r["block"] for r in selected} != set(range(1, 11)):
            raise ValueError("combined_extension_block_identity_mismatch")
        estimate = log_summary([r["log_ratio"] for r in selected])
        combined.append({"cohort": "primary_extension_combined", "model": model, "contrast": contrast,
            "planned_blocks": 10, **estimate, "inference_status": "complete_authorized_extended_series",
            "null_multiplier": 1, "null_log": 0,
            "ci_includes_null": estimate["log_ci95_low"] <= 0 <= estimate["log_ci95_high"],
            "block_unit": "same_frozen_protocol_blocks_1_to_10_no_pilot_pooling"})
    return combined, {"included": True, "n_blocks": 10,
        "protocol_sha256": data["protocol_sha256"], "reason": "complete_authorized_fixed_extension_same_protocol",
        "controller_trigger_receipt_sha256": authorized[-1]["trigger_receipt_sha256"],
        "primary_report_sha256": receipt["primary_report_sha256"],
        "extension_report_sha256": {r["controller_run_id"]: r["report_sha256"] for r in cells if r["phase"] == "extension"}}


def historical_rows(path):
    if path is None or not Path(path).is_file():
        return []
    evidence, sha = load_json(path), digest(path)
    by_model = {}
    for pair in evidence["pairs"]:
        by_model.setdefault(pair["model"], {})[pair["case"]] = pair
    rows = []
    for model, cuts in by_model.items():
        first, second = PAIRS[model]
        if first not in cuts or second not in cuts:
            continue
        for variant, metric in (("G_product", "generic_fps_median"), ("N_product", "native_fps_median")):
            rows.append({"cohort": "historical_R14", "model": model, "contrast": variant,
                "denominator_cut": first, "numerator_cut": second,
                "ratio_of_historical_medians": cuts[second][metric] / cuts[first][metric],
                "paired_blocks": 0, "ci95_low": None, "ci95_high": None,
                "source": str(path), "source_sha256": sha,
                "interpretation": "descriptive_ratio_of_medians_no_randomized_paired_block_interval"})
    return rows


def stage_rows(data, block_rows):
    """Keep product diagnostics descriptive; overlapping stage times are not added."""
    admitted = {(r["phase"], r["block"]) for r in block_rows if r["whole_block_included"] and r["mode"] == "duration"}
    keys = ("p1_ms", "p1_effective_cycle_ms", "consumer_effective_cycle_ms", "output_extract_ms",
            "trt_input_copy_ms", "p2_run_ms", "completion_tail_ms", "fifo_put_block_ms", "queue_wait_ms", "handoff_ms")
    groups = {}
    for cell in data["cells"]:
        if cell["phase"] == "pilot" or (cell["phase"], cell["block"]) not in admitted:
            continue
        metrics = data["reports"][cell["controller_run_id"]].get("metrics", {})
        group = (cell["phase"], cell["model"], cell["case_id"], cell["cut"], cell["variant"])
        for key in keys:
            value = metrics.get(key)
            if type(value) in (float, int) and math.isfinite(value):
                groups.setdefault((*group, key), []).append(value)
    return [{"phase": phase, "model": model, "case_id": case, "cut": cut, "variant": variant,
             "metric": metric, "n_processes": len(values), "median_process_mean_ms": statistics.median(values),
             "min_process_mean_ms": min(values), "max_process_mean_ms": max(values),
             "interpretation": "descriptive_product_counter_not_isolated_capacity_or_additive_pipeline_cost"}
            for (phase, model, case, cut, variant, metric), values in sorted(groups.items())]


def make_figure(prefix, summaries, historical, phase_status):
    # Plotting is the only optional dependency. No application/runtime imports.
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    has_combined = any(r["cohort"] == "primary_extension_combined" for r in summaries)
    plot_data = [{"cohort": r["cohort"], "model": r["model"], "variant": r["contrast"],
                  "ratio": r["geometric_mean"], "ci95_low": r["ci95_low"], "ci95_high": r["ci95_high"],
                  "n_blocks": r["n_blocks"], "planned_blocks": r["planned_blocks"],
                  "status": r["inference_status"]}
                 for r in summaries if r["contrast"] in VARIANTS and r["cohort"] != "pilot"
                 and not (has_combined and r["cohort"] in {"primary", "extension"})]
    plot_data.extend({"cohort": r["cohort"], "model": r["model"], "variant": r["contrast"],
        "ratio": r["ratio_of_historical_medians"], "ci95_low": None, "ci95_high": None,
        "n_blocks": 0, "planned_blocks": None, "status": r["interpretation"]} for r in historical)
    write_csv(Path(str(prefix)+"_plot_data.csv"), plot_data, ["cohort", "model", "variant", "ratio"])
    fig, axes = plt.subplots(1, 2, figsize=(8.5, 3.15), sharey=False)
    order = ["G_product", "G_single", "N_product", "N_single"]
    styles = {"primary": ("#1769aa", "o", -.15), "extension": ("#aa5a17", "s", .00),
              "primary_extension_combined": ("#1769aa", "o", -.08),
              "replication": ("#238050", "o", -.08), "historical_R14": ("#727272", "D", .16)}
    labels = {"primary": "RegNet primary", "extension": "RegNet extension",
              "primary_extension_combined": "RegNet authorized 10 blocks",
              "replication": "ResNet second case", "historical_R14": "R14 medians (descriptive)"}
    shown = set()
    for ax, model in zip(axes, ("regnet_x_1_6gf", "resnet50")):
        first, second = PAIRS[model]
        ax.axhline(1, color="#555555", linewidth=.8, linestyle="--")
        observed = False
        for row in plot_data:
            if row["model"] != model or row["ratio"] is None:
                continue
            observed = True
            color, marker, offset = styles[row["cohort"]]
            x, y = order.index(row["variant"]) + offset, row["ratio"]
            label = labels[row["cohort"]] if row["cohort"] not in shown else None
            shown.add(row["cohort"])
            low, high = row["ci95_low"], row["ci95_high"]
            if low is None or high is None:
                ax.plot(x, y, marker=marker, color=color, markerfacecolor="none" if row["cohort"] == "historical_R14" else color,
                        linestyle="none", label=label, markersize=5)
            else:
                ax.errorbar(x, y, yerr=[[max(0, y-low)], [max(0, high-y)]], fmt=marker,
                            color=color, capsize=2, markersize=5, label=label)
        if not observed:
            ax.text(.5, .5, "Controlled blocks pending", transform=ax.transAxes, ha="center", va="center")
        ax.set_xticks(range(4), ["Generic\nproduct", "Generic\nsingle", "Native\nproduct", "Native\nsingle"], fontsize=8)
        ax.set_title(("RegNet-X 1.6GF" if model.startswith("regnet") else "ResNet-50") + f"  {second}/{first}", fontsize=10)
        ax.set_ylabel("Completed-task cut ratio", fontsize=9)
        ax.set_yscale("log")
        ax.grid(axis="y", alpha=.2)
    handles, names = [], []
    for ax in axes:
        h, n = ax.get_legend_handles_labels()
        handles.extend(h); names.extend(n)
    if handles:
        fig.legend(handles, names, loc="lower center", ncol=2, fontsize=7, bbox_to_anchor=(.5, -.02))
    confirmed = [p for p in phase_status if p["phase"] != "pilot" and p["mode"] == "duration"
                 and p.get("required_for_series_completion", True)]
    status = "; ".join(f"{p['phase']} {p['complete_admitted_blocks']}/{p['planned_blocks']} complete blocks" for p in confirmed)
    fig.suptitle(status or "No confirmatory duration data in this protocol", fontsize=8, y=1.01)
    fig.tight_layout(rect=(0, .15 if handles else .03, 1, .98))
    for suffix in (".svg", ".pdf"):
        fig.savefig(str(prefix)+suffix, bbox_inches="tight", metadata={"Creator": "summarize_mechanism.py"})
    plt.close(fig)
    return plot_data


def summarize(protocol_path, output_prefix, *, progress_path=None, root=None, historical_path=None,
              extension_path=None, figure=True):
    data = read_data(protocol_path, progress_path, root=root)
    block_rows, summaries, phases = analyze_blocks(data)
    receipt = extension_receipt(data, summaries)
    combined, combination_status = combined_extension(data, summaries, block_rows, receipt)
    summaries.extend(combined)
    historical_path = (Path(historical_path) if historical_path else data["root"] / "results/mechanism_source_r14_raw.json")
    history = historical_rows(historical_path)
    stages = stage_rows(data, block_rows)
    prefix = Path(output_prefix).resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    for phase in phases:
        phase["required_for_series_completion"] = (phase["phase"] not in {"pilot", "extension"}
            or (phase["phase"] == "extension" and receipt["status"] == "evaluated" and receipt["extend"] is True))
        if phase["phase"] == "extension":
            phase["activation"] = ("triggered" if receipt["extend"] is True else "not_triggered"
                                   if receipt["extend"] is False else "not_yet_evaluable")
    output_tables = {"_attempts.csv": data["attempts"], "_cells.csv": data["cells"],
                     "_blocks.csv": block_rows, "_summary.csv": summaries, "_historical.csv": history,
                     "_stages.csv": stages}
    for suffix, rows in output_tables.items():
        write_csv(Path(str(prefix)+suffix), rows, ["status"])
    if figure:
        make_figure(prefix, summaries, history, phases)
    if extension_path:
        extension_path = Path(extension_path)
        extension_path.parent.mkdir(parents=True, exist_ok=True)
        extension_path.write_text(json.dumps(receipt, indent=2, allow_nan=False)+"\n")
    confirmation = [p for p in phases if p["required_for_series_completion"]]
    status = ("no_confirmatory_data" if not confirmation or not any(p["complete_admitted_blocks"] for p in confirmation)
              else "complete" if all(p["phase_complete"] for p in confirmation) else "partial")
    if (receipt.get("extend") is True and any(p["phase"] == "extension" and p["phase_complete"] for p in phases)
            and not combination_status["included"]):
        status = "partial"
    report = {"schema": "mechanism_offline_analysis/v1", "status": status,
        "protocol_path": str(Path(protocol_path).resolve()), "protocol_sha256": data["protocol_sha256"],
        "progress_path": str(data["progress_path"]), "progress_sha256": data["progress_sha256"],
        "hardware_executed_by_analysis": False, "code_sha256": digest(__file__),
        "phases": phases, "summaries": summaries, "historical": history, "stage_diagnostics": stages,
        "extension_trigger": receipt, "combined_extension": combination_status,
        "configuration_errors": data["config_errors"], "unknown_attempts": data["unknown_attempts"],
        "method": {"unit": "independent_process_per_cell_paired_only_within_complete_randomized_block",
            "inclusion": "last_controller_attempt_completed_included_true_valid_source_count_time_and_whole_block",
            "summary": "exp(mean(log(cut_rate_ratio))); sample_SD_log; Student_t95_CI_across_blocks",
            "interaction": "logNproductRatio-logGproductRatio-logNsingleRatio+logGsingleRatio",
            "pooling": "primary5_extension5_separate; combined10_only_complete_authorized_same_protocol; no_pilot_replication_historical_pooling",
            "incomplete": "missing_or_excluded_cells_are_null_not_zero; incomplete_blocks_excluded_in_full",
            "scope": "whole_runtime_chain_bundle; interventions_do_not_isolate_individual_copies_or_reconstruct_historical_causes"},
        "output_prefix": str(prefix)}
    Path(str(prefix)+".json").write_text(json.dumps(report, indent=2, allow_nan=False)+"\n")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--output-prefix", type=Path, required=True)
    parser.add_argument("--progress", type=Path)
    parser.add_argument("--root", type=Path)
    parser.add_argument("--historical", type=Path)
    parser.add_argument("--extension-receipt", type=Path,
                        help="Write the independently recomputed controller-compatible trigger receipt")
    parser.add_argument("--no-figure", action="store_true")
    args = parser.parse_args()
    report = summarize(args.protocol, args.output_prefix, progress_path=args.progress, root=args.root,
                       historical_path=args.historical, extension_path=args.extension_receipt, figure=not args.no_figure)
    print(json.dumps({"status": report["status"], "protocol_sha256": report["protocol_sha256"],
                      "phases": report["phases"], "extension_trigger_status": report["extension_trigger"]["status"]}))


if __name__ == "__main__":
    main()
