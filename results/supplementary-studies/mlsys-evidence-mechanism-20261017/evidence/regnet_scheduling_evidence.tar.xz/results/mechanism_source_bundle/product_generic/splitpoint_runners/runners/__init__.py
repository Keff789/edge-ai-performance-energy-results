"""Canonical Native helper namespace in generated suites."""
import sys as _sys
from .. import harness as _harness
from ..harness import yolo as _yolo
_sys.modules[__name__ + '.harness'] = _harness
_sys.modules[__name__ + '.harness.yolo'] = _yolo
