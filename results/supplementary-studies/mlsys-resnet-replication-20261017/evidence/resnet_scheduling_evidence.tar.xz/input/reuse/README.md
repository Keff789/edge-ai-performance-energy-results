# Reused ResNet functional evidence

The eight existing ResNet canaries cover `b002/b095 × Generic/Native × product/single`.
Each checked 32 mixed requests against two distinguishable serial reference outputs.
The first input is the exact historically bound prepared UINT8 tensor; the second
is its deterministic `255-input` complement. Both outputs are byte-identical across
the two runtime chains and schedules. The first matches its SHA-bound historical
functional reference exactly. This is functional/assignment evidence, not another
dataset quality evaluation or a claim about arbitrary input streams.

`manifest.json` lists all exact copied bytes, SHA-256 values and original source
paths. Runtime and case/config files are supplied by the coordinator under their
unchanged relative paths in `results/mechanism_source_bundle/`,
`results/mechanism_source_cases/` and `analysis/mechanism_adapter.py`. No large HEF,
TensorRT engine, model, dataset or old timing-report collection is copied.

The old `PROTOCOL.md` does not exist. The exact old `PROTOCOL.json`, `README.md`
and `RESUME.md` describe its contract and are copied here without creating or
editing any old file. Old RegNet40 and Native-ResNet20 results remain separate
descriptive context. The copied old independent review includes their process
identities so the new series can exclude process reuse. Old timing rows never
become cells of the fresh 40-process factorial.

The new deployment root changes from the old pilot/confirmation root to
`/home/nx/Reports/mlsys_r14_resnet_full_replication_20261017_sm2/resnet_full_replication_v1`.
Source-relative paths and source bytes are unchanged. Config/native-argument
bytes, HEF/engine paths and hashes, prepared inputs, precision, references and
completion endpoint are unchanged. New protocol/run IDs and process identities
belong to the new series.

The global single-task gate is released only after `ClassificationCompletion`
has processed materialized synchronized outputs and Top1/Top5. Native also uses
one async slot. The existing reports contain no direct global outstanding-task
highwater counter: the guarantee rests on the exact unchanged semaphore and
call-order implementation, slot settings, completion-count closure and canaries.
Generic canaries rotate the actual cached prepared-input mapping; Native canaries
fill each real reusable input slot before submission. These declared diagnostic
input changes do not alter the timed repeated-input path.

Offline reproduction uses the Python standard library plus NumPy 1.26.4 (the
recorded system environment), with no runtime/controller/SDK import:

```sh
/usr/bin/python3 -B analysis/audit_reuse.py --output receipts/reuse/reproduced.json
/usr/bin/python3 -B -m unittest analysis/test_audit_reuse.py -v
```

After the new protocol is frozen, compare its reuse contract without changing
the protocol-pinned `receipts/reuse/index.json`:

```sh
/usr/bin/python3 -B analysis/audit_reuse.py --protocol PROTOCOL.json \
  --output receipts/reuse/protocol_check.json
```

The coordinator still checks the current device, profiles, artifact hashes and
loaded-source closure before/after fresh processes. No new pilot is required by
this audit while those exact bindings remain valid.
