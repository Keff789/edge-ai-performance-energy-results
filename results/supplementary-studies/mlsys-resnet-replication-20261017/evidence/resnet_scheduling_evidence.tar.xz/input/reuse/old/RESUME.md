# Abschlussstand und sichere Wiederaufnahme

Alle erforderlichen Geräteuntersuchungen sind abgeschlossen. 40 RegNet-Prozesse und 20 ResNet-Prozesse wurden ohne fehlgeschlagene oder ausgeschlossene Messungen zugelassen. Die bedingte Erweiterung ist nicht erforderlich. Beide unabhängigen Abschlussprüfungen bestehen. Hinzu kommen 16 separate H10-Zuordnungspiloten, zwei Dauerpiloten und ein DeepX-Zuordnungsworker. Keine neue Hardware ist zur numerischen Reproduktion nötig.

## Offline-Reproduktion

Im entpackten Paket gelten die Befehle in `README.md`. Die unveränderlichen Quellen sind:

- Primärserie: `results/mechanism_snapshots/primary_5c32953af167653272c3259426005712bc01f804cdd17dd2331ef6d6b3dd52fd.json`.
- Vollständige Serie: `results/mechanism_snapshots/final_8dafb76fcb92c94314a52e43fb06282d87200dc2900416af823b61786e079fa8.json`.
- Unveränderte Verlängerungsentscheidung: `results/mechanism_extension_trigger.json`, `extend: false`.
- Hauptprotokoll: SHA256 `bff5aff0a26d8148256a688bccd2dd7e254092d42fcafb36b59f486edb96d9fd`.

Die Hauptauswertung hat Status `complete`. Die 40 registrierten, aber nicht ausgelösten Erweiterungszellen sind nicht erforderlich. Ihre Abwesenheit wird nicht als Nullmessung interpretiert. Das finale Journal enthält die 40 Primärversuche unverändert und zusätzlich die 20 ResNet-Versuche.

## Idempotente Controlleraufrufe auf SM2

Die folgenden Aufrufe sind ausschließlich für eine Prüfung beziehungsweise Wiederaufnahme auf dem ursprünglichen SM2-Arbeitsplatz vorgesehen. Vollständig abgeschlossene Prozesse werden anhand der Protokoll- und Artefakthashes wiederverwendet. Vor jedem Aufruf tatsächliche Controller und Gerätesperren prüfen. Keinen zweiten Controller starten und keine fremden Jobs beenden. Produkt-Gerätesperre und lokale Prozessleases bleiben maßgeblich.

```sh
cd /home/kmika/Reports/mlsys_r14_evidence_mechanism_20261017_sm2
python3 analysis/refresh_status.py
/home/kmika/ONNX-Splitpoint-Tool/.venv/bin/python analysis/run_mechanism.py --protocol PROTOCOL.json --run --phase primary --resume
/home/kmika/ONNX-Splitpoint-Tool/.venv/bin/python analysis/run_mechanism.py --protocol PROTOCOL.json --run --phase replication --resume
```

Diese beiden Hardwarephasen sind bereits vollständig. **Keine Erweiterung starten:** Der vorab festgelegte Auslöser ist nicht erfüllt. Die ursprüngliche Entscheidung und die aus dem Endstand erzeugte Entscheidung sind bytegleich. Eine Veränderung der statistischen Regel nach Sichtung der Daten ist unzulässig.

Die getrennten, ebenfalls abgeschlossenen Pilotserien können bei einer unterbrochenen Ergebnisabholung mit ihrem eigenen Protokoll wiederverwendet werden:

```sh
/home/kmika/ONNX-Splitpoint-Tool/.venv/bin/python analysis/run_mechanism.py --protocol PROTOCOL_pilot_canary_v1.json --run --phase pilot --resume
/home/kmika/ONNX-Splitpoint-Tool/.venv/bin/python analysis/run_mechanism.py --protocol PROTOCOL_pilot_timing_v1.json --run --phase pilot --resume
```

Bei einem echten fehlgeschlagenen Prozess bleibt der Versuchseintrag erhalten. Ein erneuter Versuch verlangt eine dokumentierte behobene technische Ursache über `--retry-cause`. Geänderte Messquellen, Profile oder Artefakte erfordern eine getrennte Serie. Bereits abgeschlossene Ergebnisse dürfen nicht durch selektive Wiederholung ersetzt werden.

Die lokalen Lease-Journale und SSH-Steuerdaten bleiben auf SM2 und sind nicht Teil des Review-ZIPs. Der Controller verlangt die dort gepinnten Produktquellen und Profile. Die Offline-Auswertung verwendet ausschließlich die kompakten Paketbelege. Die ursprüngliche Pilotquittung ist im Hauptprotokoll gebunden. Deshalb schreibt ihre Nachrechnung unter den in `README.md` genannten neuen Dateinamen.

## Erhaltene Anlaufereignisse

Der erste DeepX-Versuch endete am Profillader vor dem Hardwarestart. Der zweite reguläre Profilaufruf bestand den 32-Bild-Test mit den exakten R14-Artefakten. Ein Startfehlalarm des H10-Canarypiloten stammte von einem eigenen noch laufenden Suchprozess. Dessen Herkunft wurde vom verantwortlichen Agenten geprüft und ausschließlich dieser eigene Suchprozess beendet. Auch hier hatte vorher noch keine Messung begonnen. Beide Ereignisse sind erhalten und werden nicht als zusätzliche Hardwareprozesse gezählt.
