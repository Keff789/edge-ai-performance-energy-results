# Vollständige ResNet-Replikation auf SM2

Dieser getrennte Auftrag untersucht ResNet-50/H10, b002 und b095, in vier Varianten: Generic und Native mit ihren produktiven Schedules sowie mit global höchstens einer ausstehenden Aufgabe. Fünf gemeinsam randomisierte Blöcke enthalten jeweils acht frische Prozesse. Die ältere Serie mit 20 Native-Prozessen und die RegNet-Serie bleiben separate Untersuchungen.

Alle 40 frischen Prozesse sind abgeschlossen und unabhängig geprüft; es gab keine Fehler, Ausschlüsse oder Wiederholungen. Der Abschlussstand steht in `STATUS.md`. Das Maschinenprotokoll ist `PROTOCOL.json`, seine Beschreibung `PROTOCOL.md`. Der Abschlussbericht und die Empfehlung zur Paper-Einbindung stehen in `REPORT.md`, `CLAIM_STATUS_DELTA.md` und `PAPER_DELTA.md`.

## Numerische Reproduktion ohne Gerätezugang

Im entpackten Reviewpaket zuerst die gelieferten Dateien prüfen:

```sh
sha256sum --check SHA256SUMS
```

Die Reproduktion benötigt Python 3.12 und NumPy 1.26.4. Auf SM2 wird dafür `/usr/bin/python3` mit dem systemweiten NumPy verwendet. Controller, SSH, GPU-Laufzeit und Produktinstallation werden für die folgenden Befehle nicht benötigt. In einer Arbeitskopie aus dem Paketverzeichnis ausführen. Neue Ausgaben landen unter `results/reproduced/`, damit die gelieferten, an Dateihashes gebundenen Ergebnisse erhalten bleiben.

<!-- offline-reproduction:start -->
```sh
/usr/bin/python3 analysis/audit_reuse.py --root . --protocol PROTOCOL.json --output results/reproduced/reuse_protocol_check.json
/usr/bin/python3 analysis/analyze_replication.py --root . --protocol PROTOCOL.json --progress-snapshot results/final_progress.json --historical-manifest input/reuse/manifest.json --output-prefix results/reproduced/replication_analysis
/usr/bin/python3 analysis/review_results.py --root . --protocol PROTOCOL.json --progress results/final_progress.json --analysis-prefix results/reproduced/replication_analysis --output results/reproduced/independent_results.json
/usr/bin/python3 analysis/review_execution.py --root . --protocol PROTOCOL.json --progress results/final_progress.json --output results/reproduced/execution_review.json --notes-output notes/reproduced/execution_review.md
```
<!-- offline-reproduction:end -->

Die Auswertung verwendet ausschließlich die neuen 40 zugelassenen Zellen. Sie berechnet b095/b002 innerhalb jedes Blocks, geometrische Mittel und nominale t-Intervalle über fünf Blöcke. Der primäre Interaktionskontrast ist ein Verhältnis von Cutverhältnissen. Alte Messungen und funktionale Piloten gehen nicht in diese Schätzungen ein.

## Hardware und Wiederaufnahme auf SM2

Die Hardwarebefehle stehen in `RESUME.md`. Ausschließlich der dort dokumentierte Controller koordiniert die gemeinsame physische Gerätesperre und startet frische Worker nacheinander. Die festgeschriebene Serie ist vollständig; eine weitere Geräteausführung ist nicht erforderlich. Der reine lokale Statusaufruf startet keine Hardware:

```sh
/usr/bin/python3 analysis/refresh_status.py
```

Die großen HEFs, TensorRT-Engines und externen Originalartefakte werden durch reale Pfade und SHA256 identifiziert und nicht dupliziert. Das kompakte Paket enthält die eingefrorenen Laufzeitquellen, Konfigurationen, neuen Rohberichte und Zustandsbelege sowie exakt gebundene wiederverwendete Funktionsnachweise. Private SSH- und Prozesssteuerdateien bleiben außerhalb des Pakets.

## Seriengrenzen

Die beiden Cuts wurden wegen einer bekannten Rangumkehr ausgewählt. Diese Studie erlaubt keine Aussage über die Häufigkeit des Mechanismus auf unbekannten Modellen oder Geräten. Sie isoliert keine Kopier- oder Konvertierungskosten und misst weder neue Energieeffizienz noch Gesamtsuchkosten. Die alte Verlängerungsentscheidung bleibt unverändert. Das Manuskript wird nicht bearbeitet.
