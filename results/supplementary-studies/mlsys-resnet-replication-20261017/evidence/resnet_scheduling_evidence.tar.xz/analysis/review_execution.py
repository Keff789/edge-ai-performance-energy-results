#!/usr/bin/env python3
"""Independent read-only protocol and saved execution review. No device access.

Producer modules are parsed, never imported. The prior packet is a compact,
byte-preserved reference, not an extra set of new measurement processes.
"""
from __future__ import annotations

import argparse
import ast
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import random
import statistics
import sys

VARIANTS = {"G_product": ("generic", "product"), "N_product": ("native", "product"),
            "G_single": ("generic", "single"), "N_single": ("native", "single")}
CASES = {"resnet_b002": "b002", "resnet_b095": "b095"}
OLD_PROTOCOL_SHA = "bff5aff0a26d8148256a688bccd2dd7e254092d42fcafb36b59f486edb96d9fd"
REVIEWED_CONTROLLER_SHA = "75e5ff8b2d5dc7a44c1713a60fad6bc3573137f15ab6863cc44aa265bb4ca42a"
STUDY_NAME = "mlsys_r14_resnet_full_replication_20261017_sm2"


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def local(root, value):
    path = (root / value).resolve()
    require(path.is_relative_to(root), "local path escapes new study: " + str(value))
    return path


def task_path(root, value):
    """Map only the precise original new-study prefix into this extraction."""
    root, path = Path(root).resolve(), Path(value)
    if path.is_absolute() and not path.is_relative_to(root):
        prefix = Path("/home/kmika/Reports") / STUDY_NAME
        require(path.is_relative_to(prefix), "recorded file is outside this new study")
        path = root / path.relative_to(prefix)
    return local(root, path)


def saved_json(path):
    content = Path(path).read_bytes()
    return json.loads(content), hashlib.sha256(content).hexdigest()


def replace_prefix(value, old, new):
    if isinstance(value, str):
        if value == old:
            return new
        return new + value[len(old):] if value.startswith(old + "/") else value
    if isinstance(value, list):
        return [replace_prefix(item, old, new) for item in value]
    if isinstance(value, dict):
        return {replace_prefix(key, old, new): replace_prefix(item, old, new) for key, item in value.items()}
    return value


def check_plan(protocol):
    require(protocol.get("schema") == "mechanism-controller-v1", "unsupported protocol schema")
    require(protocol.get("kind") == "resnet-full-replication", "new separated full ResNet study kind required")
    require(set(protocol["phases"]) == {"primary"}, "only one new primary phase is permitted")
    require(set(item["case_id"] for item in protocol["cases"]) == set(CASES)
            and len(protocol["cases"]) == 2
            and all(item["model_id"] == "resnet50" and CASES[item["case_id"]] == item["cut"]
                    for item in protocol["cases"]), "exact two ResNet cuts required")
    phase = protocol["phases"]["primary"]
    require(set(phase["case_ids"]) == set(CASES) and len(phase["case_ids"]) == 2
            and set(phase["variants"]) == set(VARIANTS) and len(phase["variants"]) == 4
            and phase["blocks"] == [1, 2, 3, 4, 5]
            and phase["mode"] == "duration" and type(phase["seed"]) is int,
            "five common blocks of two cuts and all four variants required")
    rng, expected = random.Random(phase["seed"]), []
    for block in phase["blocks"]:
        cells = [(case, variant) for case in phase["case_ids"] for variant in phase["variants"]]
        rng.shuffle(cells)
        expected += [{"case_id": case, "variant": variant, "block": block} for case, variant in cells]
    require(phase["schedule"] == expected and phase["expected_runs"] == 40,
            "seeded jointly randomized eight-cell block schedule differs")
    require(protocol["recipe"] == {"warmup_s": 30, "window_s": 60, "timeout_s": 300},
            "unchanged exact 30-second warmup/60-second admission recipe required")
    require(protocol.get("energy_measured") is False, "study must not introduce energy measurement")
    require(protocol.get("reuse_original_cells") is False
            and protocol.get("pilot_results_in_confirmatory_estimates") is False
            and protocol.get("extension_enabled") is False,
            "old cells, pilot rates and outcome-dependent extensions must be excluded")
    require(protocol.get("attempt_budget") == {"required_admitted_cells": 40, "technical_replacements": 4, "max_process_attempts": 44},
            "only four declared technical replacements beyond the forty registered cells are allowed")
    require(not protocol.get("extension_trigger_rule_id") and "extension" not in protocol["phases"],
            "no outcome-dependent extension is permitted")
    return expected


def definitions(path):
    tree = ast.parse(Path(path).read_text())
    result = {}
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
            result[node.name] = node
            if isinstance(node, ast.ClassDef):
                for member in node.body:
                    if isinstance(member, ast.FunctionDef):
                        result[node.name + "." + member.name] = member
    return result


def fingerprint(node):
    return hashlib.sha256(ast.dump(node, include_attributes=False).encode()).hexdigest()


def protocol_review(root, protocol_path):
    prior = root / "input/reuse/old"
    old_path, old = prior / "PROTOCOL.json", load(prior / "PROTOCOL.json")
    protocol = load(protocol_path)
    require(sha(old_path) == OLD_PROTOCOL_SHA, "prior completed protocol reference changed")
    schedule = check_plan(protocol)
    require(REVIEWED_CONTROLLER_SHA and protocol["controller"]["sha256"] == REVIEWED_CONTROLLER_SHA,
            "controller delta lacks independent direct code review of these exact bytes")
    digest = sha(protocol_path)
    old_remote, new_remote = old["device"]["remote_root"], protocol["device"]["remote_root"]
    require(new_remote == "/home/nx/Reports/" + STUDY_NAME + "/" + protocol["series_id"]
            and new_remote != old_remote and protocol["series_id"] != old["series_id"],
            "new independent remote namespace/series identity required")
    for key in ["repository", "profiles", "admission", "recipe", "endpoint", "factors", "input_policy"]:
        require(protocol[key] == old[key], "prior execution contract changed: " + key)
    for key in ["setup_id", "python", "expected_identity", "state_policy"]:
        require(protocol["device"][key] == old["device"][key], "prior device/profile/state changed: " + key)
    for key in ["profiles", "admission", "controller", "adapter"]:
        pin = protocol[key]
        path = Path(pin["path"]) if Path(pin["path"]).is_absolute() else local(root, pin["path"])
        require(sha(path) == pin["sha256"], "current frozen pin mismatch: " + key)
    for key in ["analysis_source", "reuse_evidence"]:
        if protocol.get(key, {}).get("sha256"):
            require(sha(local(root, protocol[key]["path"])) == protocol[key]["sha256"], "study analysis/reuse evidence changed: " + key)
    expected_local_code = old["local_code"] + [{key: protocol["analysis_source"][key] for key in ["path", "sha256"]}]
    require(protocol["local_code"] == expected_local_code, "prior local runtime closure changed beyond new analysis pin")
    for pin in protocol["local_code"]:
        path = Path(pin["path"]) if Path(pin["path"]).is_absolute() else local(root, pin["path"])
        require(sha(path) == pin["sha256"], "current local runtime source changed")
    require(sha(prior / "mechanism_adapter.py") == old["adapter"]["sha256"] == protocol["adapter"]["sha256"],
            "adapter must remain byte-identical to the completed study")
    require(sha(prior / "run_mechanism.py") == old["controller"]["sha256"], "prior controller copy changed")
    old_defs = definitions(prior / "run_mechanism.py")
    new_defs = definitions(local(root, protocol["controller"]["path"]))
    # The changed validator and extension removal are reviewed separately. All
    # runtime/lease/staging/completion/resume/retry methods remain unchanged.
    stable = [name for name in old_defs if name == "ProductRuntime" or
              (name.startswith("Controller.") and name not in {"Controller.check_extension", "Controller.execute", "Controller.perform"})]
    stable += ["state_comparison", "admitted", "batch_deploy", "check_local_pin", "atomic_json"]
    fingerprints = {}
    for name in stable:
        require(name in new_defs and fingerprint(old_defs[name]) == fingerprint(new_defs[name]),
                "critical prior controller operation changed and needs review: " + name)
        fingerprints[name] = fingerprint(new_defs[name])
    old_cases = {item["case_id"]: item for item in old["cases"]}
    case_proofs = []
    for case in protocol["cases"]:
        previous = old_cases[case["case_id"]]
        for key in ["cut", "model_id", "required_artifacts", "artifact_identity", "config_sha256", "native_args_sha256"]:
            require(case[key] == previous[key], "prior exact artifact/input/precision binding changed: " + case["case_id"] + ":" + key)
        for key in ["required_sources", "runners"]:
            require(case[key] == replace_prefix(previous[key], old_remote, new_remote),
                    "runtime source closure changed beyond exact remote prefix: " + case["case_id"] + ":" + key)
        for path_key, hash_key in [("config_path", "config_sha256"), ("native_args_path", "native_args_sha256")]:
            require(sha(local(root, case[path_key])) == case[hash_key], "new exact configuration/argv changed")
        config = load(local(root, case["config_path"]))
        require(config["task"] == "classification" and not config.get("energy_capture"), "classification-only endpoint required")
        case_proofs.append({"case_id": case["case_id"], "artifact_roles": len(case["required_artifacts"]),
            "source_files": len(case["required_sources"]), "config_sha256": case["config_sha256"],
            "native_args_sha256": case["native_args_sha256"],
            "runtime_artifacts": config["expected_runtime_artifacts"], "prepared_input": config["input_binding"]["prepared_input"]})
    deploys = protocol["deploy_files"]
    require(len({item["remote_relative"] for item in deploys}) == len(deploys), "duplicate deployed path")
    for pin in deploys:
        require(sha(local(root, pin["local_path"])) == pin["sha256"], "deployed frozen source/config changed")
    pilot = load(prior / "PROTOCOL_pilot_canary_v1.json")
    pilot_progress = load(prior / "pilot_canary_PROGRESS.json")
    prior_review_path = prior / "mechanism_canary_independent_review.json"
    prior_review = load(prior_review_path)
    require(sha(prior_review_path) == old["pilot_prerequisites"]["independent_canary_review"]["sha256"]
            and prior_review["status"] == "pass" and not prior_review["errors"], "prior independently reviewed canaries not sealed/passing")
    require(sha(prior / "PROTOCOL_pilot_canary_v1.json") == prior_review["protocol_sha256"]
            and sha(prior / "pilot_canary_PROGRESS.json") == prior_review["progress_sha256"], "prior canary protocol/ledger source hashes changed")
    prior_rows = {(row["case_id"], row["variant"]): row for row in prior_review["rows"]}
    coverage = []
    for case in protocol["cases"]:
        for variant, (chain, scheduling) in VARIANTS.items():
            raw_path = root / "input/reuse/canaries" / (case["case_id"] + "_" + variant + ".json")
            raw = load(raw_path)
            require(sha(raw_path) == prior_rows[case["case_id"], variant]["report_sha256"], "prior canary raw report is not the sealed producer")
            require(raw["protocol_sha256"] == prior_review["protocol_sha256"]
                    and raw["adapter_sha256"] == protocol["adapter"]["sha256"]
                    and raw["artifact_identity"] == case["artifact_identity"]
                    and raw["config_sha256"] == case["config_sha256"]
                    and raw["product_runner_sha256"] == case["runners"][chain]["sha256"]
                    and raw["chain"] == chain and raw["schedule"] == scheduling
                    and raw["status"] == "complete" and raw["canary_pass"] is True
                    and raw["historical_functional_reference_match"] is True,
                    "prior canary does not cover this exact new artifact/configuration/path")
            expected_sources = {pin["path"]: pin["sha256"] for pin in case["required_sources"]}
            actual_sources = replace_prefix(raw["loaded_source_hashes"], pilot["device"]["remote_root"], new_remote)
            require(actual_sources and all(expected_sources.get(path) == value for path, value in actual_sources.items()),
                    "prior loaded runtime source bytes differ from the new closure")
            coverage.append({"case_id": case["case_id"], "variant": variant, "raw_sha256": sha(raw_path),
                             "checked_requests": 32, "source_files": len(actual_sources)})
    progress = root / "results/mechanism" / digest / "PROGRESS.json"
    existing_attempts = len(load(progress)["attempts"]) if progress.exists() else 0
    return {"status": "PASS", "protocol_sha256": digest, "prior_protocol_sha256": sha(old_path),
        "planned_fresh_processes": 40, "complete_common_blocks": 5, "cells_per_block": 8,
        "frozen_schedule": schedule, "existing_new_attempts_at_review": existing_attempts,
        "prior_and_new_processes_pooled": False, "extension_permitted": False,
        "preserved_critical_controller_ast_sha256": fingerprints,
        "case_bindings": case_proofs, "reused_exact_canary_paths": coverage,
        "adapter_sha256": protocol["adapter"]["sha256"], "controller_sha256": protocol["controller"]["sha256"],
        "deployed_frozen_files": len(deploys),
        "single_task_evidence": "Unchanged semaphore admission before first stage/submission and release after materialized classification completion. Existing counters check inflight/queue and full task counts, not a direct global peak counter.",
        "review_boundaries": ["No hardware or producer imports.", "Controller validator and extension-removal delta also require direct code review.",
            "This is a protocol review, not proof of 40 completed new processes."]}


# Saved-evidence checks reused from the prior independent audit, not producer code.
def check_snapshot(root, path, protocol, case, *, end):
    path = task_path(root, path)
    snapshot = load(path)
    admission = snapshot["admission"]
    require(admission.get("eligible") is True and admission.get("exclusive_start_permission") is True
            and not admission.get("blockers"), "snapshot admission not exclusive and complete")
    require(snapshot.get("read_only") is True, "observer not marked metadata-only")
    for key, expected in protocol["device"]["expected_identity"].items():
        require(snapshot["identity"].get(key) == expected, "recorded device identity changed")
    reservation = snapshot["reservation"]
    owner = reservation["owner"]
    require(owner.get("state") == "running" and owner.get("run_id") == protocol["series_id"]
            and owner.get("session_id") == "mechanism-" + sha(root / protocol["_protocol_file"])
            and reservation["kernel_lock_pids"] == [owner["pid"]]
            and not reservation["quarantine_exists"] and not reservation["visibility_errors"],
            "physical product lock ownership not proven in saved snapshot")
    for label in ("owners", "controller"):
        observation = snapshot[label]
        require(observation.get("ok") is True and observation.get("read_only") is True
                and not observation.get("processes") and not observation.get("live_product_leases")
                and not observation.get("visibility_errors"), "saved snapshot contains competing work or incomplete visibility")
    pins = {item["path"]: item["sha256"] for item in case["required_artifacts"] + case["required_sources"]}
    pins.update({protocol["device"]["remote_root"] + "/" + item["remote_relative"]: item["sha256"]
                 for item in protocol["deploy_files"]})
    pins[protocol["device"]["remote_root"] + "/PROTOCOL.json"] = sha(root / protocol["_protocol_file"])
    observed = {item["path"]: item for item in snapshot["artifacts"]}
    for path_name, expected in pins.items():
        record = observed.get(path_name, {})
        require(record.get("exists") and record.get("regular_file") and record.get("readable")
                and record.get("actual_sha256") == expected, "snapshot artifact/source pin missing or changed: " + path_name)
    environment = snapshot["current_python_environment"]
    require(environment.get("runtime_initialized") is False and environment.get("returncode") == 0
            and environment.get("executable") == protocol["device"]["python"], "observer interpreter/runtime metadata mismatch")
    state, policy = snapshot["read_only_start_state"], protocol["device"]["state_policy"]
    temperature = float(state["/sys/class/thermal/thermal_zone0/temp"]) / 1000
    require(math.isfinite(temperature), "unknown temperature")
    if not end:
        require(policy["temperature_band_c"][0] <= temperature <= policy["temperature_band_c"][1], "start temperature outside prespecified band")
    for core in policy["affinity"]:
        for field in ("scaling_min_freq", "scaling_max_freq", "scaling_cur_freq"):
            require(str(state[f"/sys/devices/system/cpu/cpu{core}/cpufreq/{field}"]) == str(policy["cpu_min_max_khz"]), "CPU clocks changed")
    for field in ("min_freq", "max_freq", "cur_freq"):
        require(str(state["/sys/class/devfreq/17000000.gpu/" + field]) == str(policy["gpu_min_max_hz"]), "GPU clocks changed")
    throttle = [key for key, value in state.items() if key.endswith("/type") and isinstance(value, str) and value.endswith("throttle-alert")]
    require(len(throttle) >= 8, "expected throttle alert visibility missing")
    require(all(state[key.removesuffix("/type") + "/cur_state"] == "0" for key in throttle), "active thermal throttle alert")
    require(state["probe_process_cpu_affinity"] == policy["affinity"], "observer inherited affinity changed")
    power = state["power_mode_read_only_query"]
    require(power["returncode"] == 0 and policy["power_mode"] in power["output"], "power mode changed")
    return {"path": str(path.relative_to(root)), "sha256": sha(path), "temperature_c": temperature,
            "verified_artifact_source_files": len(pins), "controller_lock_pid": owner["pid"], "throttle_alerts_zero": len(throttle)}

def action(protocol_sha, case, config, phase, cell):
    identity = {"protocol_sha256": protocol_sha, "artifact_identity": config["expected_runtime_artifacts"],
        "case_id": case["case_id"], "cut": case["cut"], "variant": cell["variant"],
        "block": cell["block"], "phase": phase, "mode": "duration"}
    return {**identity, "run_id": canonical(identity)}

def duration_contract(raw, chain, schedule, config):
    count, seconds, fps = (raw[key] for key in ("completed_work_units", "measurement_time_seconds", "completed_task_fps"))
    require(type(count) is int and count > 0 and type(seconds) in (int, float) and math.isfinite(seconds)
            and seconds >= 60 and math.isfinite(fps) and fps > 0
            and math.isclose(fps, count / seconds, rel_tol=1e-9), "count/time/completed-task rate does not agree")
    require(raw["warmup_duration_s"] == 30 and type(raw["warmup_completed_count"]) is int and raw["warmup_completed_count"] > 0
            and raw["admission_window_seconds"] == 60 and raw["accepted_work_drained"] is True,
            "fixed30-second drained warmup or60-second accepted-work drain contract absent")
    elapsed = (raw["finished_time_ns"] - raw["started_time_ns"]) / 1e9
    require(elapsed + 0.001 >= 30 + seconds, "process elapsed time cannot contain declared warmup and measurement")
    metrics = raw["metrics"]
    if chain == "generic":
        require(metrics["status"] == "ok" and metrics["requested_duration_s"] == 60
                and metrics["admitted_task_count"] == metrics["completed_task_count"] == metrics["processor_count_delta"] == count
                and metrics["completed_work_units"] == count and metrics["accepted_work_drained"] is True
                and metrics["fill_and_drain_included"] is True and metrics["postprocess_timed"] is True
                and metrics["output_materialization_timed"] is True, "Generic admission/completion/materialization contract differs")
        start, deadline, stop, end = (metrics[key] for key in (
            "measurement_start_ns", "admission_deadline_ns", "admission_stopped_ns", "measurement_end_ns"))
        require(deadline - start == 60_000_000_000 and deadline <= stop <= end
                and metrics["admission_stopped_at_deadline"] is True
                and math.isclose((end - start) / 1e9, seconds, rel_tol=1e-12, abs_tol=1e-9)
                and math.isclose(metrics["measured_makespan_seconds"], seconds, rel_tol=1e-12),
                "Generic exact60-second deadline, accepted-work drain or measured timer differs")
        require(metrics["worker_count"] == 2 and metrics["queue_depth"] == int(config.get("queue_depth", 2)),
                "Generic product worker/queue recipe changed")
        timing_proof = {"admission_span_ns": deadline - start, "stop_minus_deadline_ns": stop - deadline,
                        "drain_after_stop_ns": end - stop, "measurement_span_ns": end - start}
    else:
        require(metrics["duration_s"] == 60 and metrics["produced_frames"] == metrics["consumed_frames"]
                == metrics["completed_work_units"] == metrics["postprocess_completed_frames"] == count
                and metrics["task_complete"] is True and metrics["postprocess_completion_verified"] is True
                and metrics["postprocess_included"] is True
                and metrics["completed_task_stage"] == "classification_top1_top5"
                and metrics["measurement_boundary"] == "workers_ready_to_last_completed_task_frame"
                and metrics["warmup_contract"] == "fully_drained_before_worker_start"
                and math.isclose(metrics["makespan_ms"] / 1000, seconds, rel_tol=1e-12),
                "Native accepted/completed/postprocess counts or timer/endpoint differs")
        require(metrics["inflight"] == (8 if schedule == "product" else 1) and metrics["queue_depth"] == 3,
                "Native product/single scheduling recipe changed")
        latency = metrics["request_latency"]
        require(latency["status"] == "unavailable" and latency["reason"] == "duration_workload_not_instrumented"
                and not latency["pairs"], "confirming Native run contains per-request latency instrumentation")
        timing_proof = {"native_makespan_ms": metrics["makespan_ms"], "declared_admission_seconds": metrics["duration_s"],
                        "produced_equals_consumed_equals_postprocessed": True,
                        "native_admission_timestamps_saved": False}
    return {"completed_work_units": count, "measurement_time_seconds": seconds, "completed_task_fps": fps,
            "warmup_completed_count": raw["warmup_completed_count"], "warmup_duration_s": 30,
            "admission_window_seconds": 60, "process_elapsed_seconds": elapsed,
            "rate_denominator": "admission start through full accepted-work completion including drain", **timing_proof}

def stability_record(root, attempt, before_path, protocol):
    before, _ = saved_json(task_path(root, before_path))
    before_time = datetime.fromisoformat(before["observed_at_utc"]).timestamp()
    target = attempt["before_state_check"]["previous_temperature_c"]
    candidates = []
    for path in task_path(root, before_path).parent.glob(attempt["run_id"] + "_*.json"):
        if "_stability_" not in path.name and "_before_" not in path.name:
            continue
        value, digest = saved_json(path)
        stamp = datetime.fromisoformat(value["observed_at_utc"]).timestamp()
        temp = float(value["read_only_start_state"]["/sys/class/thermal/thermal_zone0/temp"]) / 1000
        if stamp < before_time and math.isclose(temp, target, abs_tol=1e-9):
            candidates.append((stamp, temp, path, digest))
    require(candidates, "prior temperature-stability observation is not preserved")
    stamp, temp, path, digest = max(candidates)
    gap = before_time - stamp
    policy = protocol["device"]["state_policy"]
    current = float(before["read_only_start_state"]["/sys/class/thermal/thermal_zone0/temp"]) / 1000
    require(gap >= policy["stability_gap_s"] and abs(current - temp) <= policy["stability_delta_c"],
            "saved start temperature samples violate frozen gap/delta")
    require(math.isclose(current, attempt["before_state_check"]["temperature_c"], abs_tol=1e-9),
            "controller's start temperature differs from actual saved reading")
    return {"path": str(path.relative_to(root)), "sha256": digest, "temperature_c": temp,
            "sample_gap_seconds": gap, "delta_c": current - temp}

def check_report(root, protocol, protocol_sha, case, config, attempt):
    raw_path = task_path(root, attempt["report_path"])
    raw, digest = saved_json(raw_path)
    require(digest == attempt["report_sha256"], "immutable raw report hash changed")
    chain, schedule = VARIANTS[attempt["variant"]]
    identity = {"protocol_sha256": protocol_sha, "identity": config["identity"],
        "artifact_identity": config["expected_runtime_artifacts"], "chain": chain, "schedule": schedule,
        "block": attempt["block"], "mode": "duration"}
    require(all(raw.get(key) == value for key, value in identity.items()) and raw["run_id"] == canonical(identity),
            "raw adapter identity/protocol/artifact differs")
    require(raw["schema"] == "mechanism-product-workers-v1" and raw["status"] == "complete"
            and raw["adapter_sha256"] == protocol["adapter"]["sha256"]
            and raw["product_runner"] == case["runners"][chain]["path"]
            and raw["product_runner_sha256"] == case["runners"][chain]["sha256"]
            and raw["config_sha256"] == case["config_sha256"]
            and raw["diagnostic_adapter"] is True and raw["energy_measured"] is False
            and raw["worker_cpu_affinity"] == protocol["device"]["state_policy"]["affinity"],
            "completed raw report source/config/affinity/measurement scope differs")
    sources = {item["path"]: item["sha256"] for item in case["required_sources"]}
    require(raw["loaded_source_hashes"] and all(sources.get(path) == value for path, value in raw["loaded_source_hashes"].items()),
            "unfrozen or changed actually imported product source")
    row = {"raw_report": str(raw_path.relative_to(root)), "raw_report_sha256": digest,
           "pid": raw["pid"], "remote_started_time_ns": raw["started_time_ns"],
           "remote_finished_time_ns": raw["finished_time_ns"], "loaded_source_files": len(raw["loaded_source_hashes"]),
           "actual_loaded_source_hashes": raw["loaded_source_hashes"],
           "runtime_artifact_identity": raw["artifact_identity"],
           **duration_contract(raw, chain, schedule, config)}
    if "runtime_artifacts" in raw:
        require(raw["runtime_artifacts"] == config["expected_runtime_artifacts"], "actual Generic backend artifact descriptors differ")
    return row


def execution_review(root, protocol_path, progress_path):
    """Audit one immutable new-series ledger snapshot without live paths."""
    protocol, protocol_sha = saved_json(protocol_path)
    schedule = check_plan(protocol)
    require(protocol.get("protocol_state") == "FROZEN", "only a frozen protocol can authorize execution")
    require(protocol["controller"]["sha256"] == REVIEWED_CONTROLLER_SHA, "unreviewed controller bytes")
    protocol["_protocol_file"] = protocol_path.relative_to(root).as_posix()
    for name in ["controller", "adapter", "analysis_source", "reuse_evidence"]:
        pin = protocol[name]
        require(sha(local(root, pin["path"])) == pin["sha256"], "frozen local study payload changed: " + name)
    for pin in protocol["deploy_files"]:
        require(sha(local(root, pin["local_path"])) == pin["sha256"], "frozen deployed source/config bytes changed")
    progress, progress_sha = saved_json(progress_path)
    require(progress_path.name != "PROGRESS.json", "an explicitly named immutable progress snapshot is required")
    require(progress["schema"] == "mechanism-progress-v1" and progress["protocol_sha256"] == protocol_sha,
            "new ledger does not bind the exact frozen new protocol")
    attempts = progress["attempts"]
    require(len(attempts) <= protocol["attempt_budget"]["max_process_attempts"], "technical replacement budget exceeded")
    cases = {item["case_id"]: item for item in protocol["cases"]}
    configs = {}
    for key, case in cases.items():
        require(sha(local(root, case["config_path"])) == case["config_sha256"], "case configuration changed")
        configs[key] = load(local(root, case["config_path"]))
    known = {}
    for index, cell in enumerate(schedule):
        case = cases[cell["case_id"]]
        identity = action(protocol_sha, case, configs[cell["case_id"]], "primary", cell)
        require(identity["run_id"] not in known, "duplicate registered cell identity")
        known[identity["run_id"]] = (identity, case, configs[cell["case_id"]], index)
    prior_attempts, first_order, rows, errors, pids = defaultdict(list), [], [], [], set()
    previous_finished = previous_raw_end = None
    frozen_time = datetime.fromisoformat(protocol["frozen_at_utc"]).timestamp()
    unresolved = None
    for index, attempt in enumerate(attempts):
        row = {"attempt_index": index, "attempt_id": attempt.get("attempt_id"), "run_id": attempt.get("run_id"),
               "recorded_status": attempt.get("status"), "included": attempt.get("included") is True,
               "original_attempt_sha256": canonical(attempt), "audit_status": "pending"}
        prior = prior_attempts[attempt.get("run_id")]
        try:
            require(attempt.get("run_id") in known, "attempt outside the forty newly registered cells")
            identity, case, config, position = known[attempt["run_id"]]
            row.update({key: identity[key] for key in ["case_id", "cut", "variant", "block", "phase"]})
            require(all(attempt.get(key) == value for key, value in identity.items()), "controller action identity changed")
            require(unresolved is None or unresolved == attempt["run_id"], "controller advanced past an unresolved technical attempt")
            require(attempt["attempt_id"] == attempt["run_id"] + f"_attempt{len(prior)+1:02d}", "attempt numbering/history differs")
            if not prior:
                first_order.append(position)
                require(not attempt.get("retry_cause"), "first process cannot be marked as a replacement")
            else:
                predecessor, cause = prior[-1], attempt.get("retry_cause") or {}
                require(cause.get("run_id") == attempt["run_id"] and cause.get("protocol_sha256") == protocol_sha
                        and cause.get("cause_corrected") is True and isinstance(cause.get("reason"), str)
                        and bool(cause["reason"].strip()), "replacement lacks exact corrected technical-cause evidence")
                if predecessor["status"] == "failed":
                    require(cause.get("technical_error") in {"launcher", "transport", "implementation"}, "invalid failed-process replacement category")
                else:
                    reasons = predecessor.get("state_check", {}).get("reasons")
                    require(predecessor["status"] == "completed" and predecessor.get("included") is False
                            and reasons and predecessor["state_check"].get("comparable") is False
                            and cause.get("technical_error") == "state_policy"
                            and cause.get("previous_state_reasons") == reasons,
                            "admitted or unexplained excluded process was repeated")
                row["retry_cause"] = cause
            row["before"] = check_snapshot(root, attempt["before_snapshot"], protocol, case, end=False)
            row["stability"] = stability_record(root, attempt, attempt["before_snapshot"], protocol)
            require(attempt["before_state_check"]["comparable"] is True and not attempt["before_state_check"]["reasons"], "noncomparable process start")
            started = datetime.fromisoformat(attempt["started_at_utc"]).timestamp()
            require(started >= frozen_time, "new worker predates the new frozen protocol")
            if previous_finished is not None:
                require(started - previous_finished >= protocol["device"]["state_policy"]["min_rest_s"], "inter-process rest/serial execution violated")
            if attempt.get("finished_wall_time") is not None:
                previous_finished = attempt["finished_wall_time"]
            if attempt.get("log_path"):
                row["log_sha256"] = sha(task_path(root, attempt["log_path"]))
            if attempt["status"] in {"started", "hardware_finished", "uncertain"}:
                row["audit_status"] = "pending"
            elif attempt["status"] == "failed":
                require(attempt.get("reason") and attempt.get("returncode") not in (None, 0), "failed process has no concrete nonzero exit evidence")
                row.update(audit_status="failed_attempt_preserved", original_attempt=attempt)
            else:
                require(attempt["status"] == "completed" and attempt.get("returncode") == 0, "unknown/nonzero completed process")
                row.update(check_report(root, protocol, protocol_sha, case, config, attempt))
                require(type(row["pid"]) is int and row["pid"] > 0 and row["pid"] not in pids, "worker PID invalid or reused within the new series")
                pids.add(row["pid"])
                if previous_raw_end is not None:
                    require(row["remote_started_time_ns"] >= previous_raw_end, "new worker process lifetimes overlap")
                previous_raw_end = row["remote_finished_time_ns"]
                after_error = None
                try:
                    row["after"] = check_snapshot(root, attempt["after_snapshot"], protocol, case, end=True)
                    require(row["before"]["controller_lock_pid"] == row["after"]["controller_lock_pid"], "physical lock owner changed during a process")
                except ValueError as error:
                    after_error = str(error)
                if attempt.get("included") is True:
                    require(after_error is None, "included process fails independent end-state check: " + str(after_error))
                    require(attempt["state_check"]["comparable"] is True and not attempt["state_check"]["reasons"], "included process has recorded exclusions")
                    row["audit_status"] = "pass"
                else:
                    require(attempt.get("included") is False and attempt["state_check"].get("comparable") is False
                            and attempt["state_check"].get("reasons") and after_error,
                            "excluded process lacks independently corroborated technical end-state failure")
                    row.update(audit_status="excluded_attempt_preserved", original_attempt=attempt, independent_exclusion=after_error)
            unresolved = None if row["audit_status"] == "pass" else attempt["run_id"]
        except (ValueError, KeyError, OSError, TypeError, IndexError) as error:
            row.update(audit_status="audit_failure", error=str(error))
            errors.append({"attempt_id": attempt.get("attempt_id"), "reason": str(error)})
        prior.append(attempt)
        rows.append(row)
    if first_order != list(range(len(first_order))):
        errors.append({"reason": "actual first attempts differ from the common eight-cell randomized block prefix"})
    latest = {row["run_id"]: row for row in rows}
    admitted = [latest[key] for key in known if key in latest and latest[key]["audit_status"] == "pass" and latest[key]["included"]]
    complete_blocks = [block for block in range(1, 6) if sum(row["block"] == block for row in admitted) == 8]
    reasons = []
    if len(admitted) != 40 or complete_blocks != [1, 2, 3, 4, 5]:
        reasons.append("forty admitted fresh cells in five complete common blocks are required")
    if not progress.get("events") or progress["events"][-1].get("status") != "phase_completed":
        reasons.append("controller has not recorded completed execution of the sole primary phase")
    if sha(progress_path) != progress_sha or sha(protocol_path) != protocol_sha:
        errors.append({"reason": "selected immutable source changed during audit"})
    return {"schema": "resnet-full-independent-execution-review-v1", "scope": "final",
        "status": "FAIL" if errors else "INCOMPLETE" if reasons else "PASS", "audit_errors": errors,
        "completion_reasons": reasons, "protocol_sha256": protocol_sha,
        "progress_snapshot": progress_path.relative_to(root).as_posix(), "progress_snapshot_sha256": progress_sha,
        "immutable_progress_snapshot_explicit": True, "required_complete_processes": 40,
        "admitted_complete_processes": len(admitted), "complete_common_blocks": complete_blocks,
        "process_attempts": len(attempts), "distinct_completed_worker_pids": len(pids),
        "distinct_admitted_worker_pids": len({row["pid"] for row in admitted}),
        "attempt_status_counts": dict(Counter(row["audit_status"] for row in rows)),
        "all_attempts_retained": len(rows) == len(attempts), "prior_measurements_pooled": False,
        "extension_permitted": False, "rows": rows,
        "scope_limits": ["Offline saved-evidence review, without a new device observation.",
            "Global-one guarantee uses unchanged completion-gate source plus scheduling/completion counters, not an absent global peak counter.",
            "Native admission timestamps and separate warmup timer samples are not saved; the unchanged source, duration/count/makespan and process elapsed bounds provide the timing evidence.",
            "No energy, total-search-cost, historical-cause, isolated-copy-cost or general-prevalence claim is inferred."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__ + " Protocol-only mode checks actual SM2 source/profile files; --progress uses only archived task evidence.")
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--protocol", type=Path, default=Path("PROTOCOL.json"))
    parser.add_argument("--progress", type=Path, help="Immutable final ledger snapshot for fully offline execution review.")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--notes-output", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    output = local(root, args.output or ("results/execution_review.json" if args.progress else "results/protocol_review.json"))
    try:
        result = (execution_review(root, local(root, args.protocol), task_path(root, args.progress)) if args.progress else
                  protocol_review(root, local(root, args.protocol)))
    except (ValueError, KeyError, OSError, TypeError) as error:
        result = {"status": "FAIL", "error": type(error).__name__ + ": " + str(error)}
    result.update(reviewed_at_utc=datetime.now(timezone.utc).isoformat(), review_source_sha256=sha(__file__), hardware_access=False)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    notes = (local(root, args.notes_output) if args.notes_output else
             output.with_suffix(".md") if args.output else root / ("notes/execution_review.md" if args.progress else "notes/protocol_review.md"))
    notes.parent.mkdir(parents=True, exist_ok=True)
    title = "execution" if args.progress else "protocol"
    detail = ("Admitted new processes: " + str(result.get("admitted_complete_processes", 0)) +
              "/40. Complete common blocks: " + str(result.get("complete_common_blocks", [])) + "." if args.progress else
              "The exact protocol, reused functional paths and preserved controller operations pass the saved-source checks.")
    notes.write_text("# Independent " + title + " review\n\nStatus: " + result["status"] + ". No hardware access.\n\n" +
                     result.get("error", detail) + "\n")
    print(json.dumps({"status": result["status"], "error": result.get("error"), "protocol_sha256": result.get("protocol_sha256")}, indent=2))
    return int(result["status"] != "PASS")


if __name__ == "__main__":
    sys.exit(main())
