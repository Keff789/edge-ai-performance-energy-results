#!/usr/bin/env python3
"""Build/verify a small portable ResNet functional-evidence reuse packet.

Offline only: JSON, static source bytes and saved NumPy arrays. No controller,
product, accelerator runtime, device observer or remote transport is imported.
The old report tree is read-only. Only this task's input/reuse and receipts/reuse
are written. Runtime/config copies are supplied separately by the coordinator.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
from pathlib import Path
import shutil

import numpy as np

CASES = ("resnet_b002", "resnet_b095")
VARIANTS = {"G_product": ("generic", "product"), "N_product": ("native", "product"),
            "G_single": ("generic", "single"), "N_single": ("native", "single")}
SEQUENCE = [0, 1, 1, 0, 1, 0, 0, 1] * 4
NEW_REMOTE_ROOT = "/home/nx/Reports/mlsys_r14_resnet_full_replication_20261017_sm2/resnet_full_replication_v1"
OLD_PROTOCOL_SHA = "bff5aff0a26d8148256a688bccd2dd7e254092d42fcafb36b59f486edb96d9fd"
CANARY_PROTOCOL_SHA = "6921c70fb08e9011d0534ae3244ac59b6993f949d20177878276495167beaf28"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def load(path):
    return json.loads(Path(path).read_bytes())


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+"\n")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def bytes_equal(first, second):
    return first.shape == second.shape and first.dtype == second.dtype and first.tobytes() == second.tobytes()


def inside(root, path):
    path = Path(path)
    result = path.resolve() if path.is_absolute() else (root/path).resolve()
    require(result.is_relative_to(root), "path_outside_packet:"+str(path))
    return result


def prepare(root, old_root):
    root, old_root = root.resolve(), old_root.resolve()
    require(root != old_root and not root.is_relative_to(old_root), "old_report_must_remain_immutable")
    packet = root/"input/reuse"
    entries = {}

    def copy(source, relative):
        source = Path(source).resolve()
        require(source.is_relative_to(old_root), "copy_source_outside_old_report")
        destination = inside(root, relative)
        digest = sha(source)
        if destination.exists():
            require(sha(destination) == digest, "existing_reuse_copy_changed:"+relative)
        else:
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source, destination)
        entry = entries.setdefault(relative, {"path": relative, "sha256": digest,
            "size_bytes": destination.stat().st_size, "original_paths": []})
        entry["original_paths"].append(str(source))
        return relative

    for original, name in (("PROTOCOL.json", "PROTOCOL.json"),
        ("PROTOCOL_pilot_canary_v1.json", "PROTOCOL_pilot_canary_v1.json"),
        ("README.md", "README.md"), ("REPORT.md", "REPORT.md"), ("RESUME.md", "RESUME.md"),
        ("analysis/run_mechanism.py", "run_mechanism.py"),
        ("analysis/mechanism_adapter.py", "mechanism_adapter.py"),
        ("results/mechanism_results_independent_review.json", "mechanism_results_independent_review.json"),
        ("results/mechanism_confirmation_summary.csv", "mechanism_confirmation_summary.csv"),
        ("results/mechanism_confirmation_blocks.csv", "mechanism_confirmation_blocks.csv"),
        ("results/mechanism_canary_independent_review.json", "mechanism_canary_independent_review.json")):
        copy(old_root/original, "input/reuse/old/"+name)
    old_protocol = load(old_root/"PROTOCOL.json")
    pilot_progress = old_root/"results/mechanism"/CANARY_PROTOCOL_SHA/"PROGRESS.json"
    copy(pilot_progress, "input/reuse/old/pilot_canary_PROGRESS.json")
    progress = load(pilot_progress)
    for attempt in progress["attempts"]:
        if attempt["case_id"] not in CASES:
            continue
        case, variant = attempt["case_id"], attempt["variant"]
        copy(attempt["report_path"], f"input/reuse/canaries/{case}_{variant}.json")
        for tensor in attempt["canary_tensors"]:
            copy(tensor["local_path"], "input/reuse/tensors/"+tensor["sha256"]+".npy")
    for case in old_protocol["cases"]:
        if case["case_id"] not in CASES:
            continue
        case_id = case["case_id"]
        config = load(old_root/case["config_path"])
        history = old_root/"evidence/mechanism_historical_references"/case_id
        copy(history/"source_manifest.json", f"input/reuse/historical/{case_id}/source_manifest.json")
        manifest = load(history/"source_manifest.json")
        for output in manifest["outputs"]:
            name = Path(output["file"]).name
            copy(history/name, f"input/reuse/historical/{case_id}/{name}")
        for schedule in ("product", "single"):
            copy(old_root/f"results/mechanism_canary_comparisons/{case_id}_{schedule}.json",
                 f"input/reuse/comparisons/{case_id}_{schedule}.json")
    require(not (old_root/"PROTOCOL.md").exists(), "old_protocol_md_presence_changed_recheck_documentation")
    manifest = {"schema": "resnet-reuse-packet-v1", "old_report_root": str(old_root),
        "old_protocol_md_exists": False, "old_protocol_documentation": ["input/reuse/old/PROTOCOL.json", "input/reuse/old/README.md"],
        "old_protocol_sha256": OLD_PROTOCOL_SHA, "canary_protocol_sha256": CANARY_PROTOCOL_SHA,
        "files": sorted(entries.values(), key=lambda entry: entry["path"]),
        "scope": "Eight existing ResNet functional/mixed-input canaries, exact references and provenance. No old timing rows enter new blocks."}
    write(packet/"manifest.json", manifest)
    return manifest


def source_contract(root, old):
    """Check exact frozen sources, then expose auditable call-order locations."""
    pins = []
    deploy = [item for item in old["deploy_files"] if not item["local_path"].startswith("results/mechanism_source_cases/")]
    deploy += [item for item in old["deploy_files"] if any(item["local_path"].endswith(case+suffix)
               for case in CASES for suffix in ("_generic_config.json", "_native_argv.json"))]
    for item in deploy:
        path = inside(root, item["local_path"])
        require(sha(path) == item["sha256"], "new_source_or_config_content_differs:"+item["local_path"])
        pins.append({"path": item["local_path"], "sha256": item["sha256"], "remote_relative": item["remote_relative"]})
    paths = {
        "adapter": root/old["adapter"]["path"],
        "generic_completion": root/"results/mechanism_source_bundle/product_generic/splitpoint_runners/task_completion.py",
        "generic_classification": root/"results/mechanism_source_bundle/product_generic/splitpoint_runners/harness/classification.py",
        "native_classification": root/"results/mechanism_source_bundle/product_native/onnx_splitpoint_tool/runners/harness/classification.py",
        "native_runner": root/"results/mechanism_source_bundle/product_native/scripts/native_hailo10_trt_e2e_from_benchmarkset.py"}
    texts = {key: path.read_text() for key, path in paths.items()}
    conditions = {
        "semaphore_capacity_one": "threading.BoundedSemaphore(1)" in texts["adapter"],
        "gate_after_full_processor": "result = self.processor.process(outputs)\n        self.gate.release()" in texts["adapter"],
        "generic_gate_before_stage1": "gate.acquire()\n            return stage1()" in texts["adapter"],
        "native_gate_before_submission": "self.gate.acquire()" in texts["adapter"] and "return self.session._submit_reusable_slot" in texts["adapter"],
        "native_wrap_actual_classification": "module.ClassificationCompletion = lambda: GatedProcessor(original_completion(), gate)" in texts["adapter"],
        "generic_materialize_before_processor": "outputs = concrete_outputs(stage2(transfer(payload)))\n                before = processor.completed_count\n                processor.process(outputs)" in texts["generic_completion"],
        "native_trt_output_sync": "cudaStreamSynchronize(self.stream)" in texts["native_runner"],
        "native_processor_after_trt": "trt_outputs = trt.run_prepared()\n                t2 = time.perf_counter()\n                if completion_runtime is not None:\n                    completion_runtime.process(trt_outputs)" in texts["native_runner"],
        "both_classification_top1_top5": all("top5 = classification_topk(outputs" in texts[key]
            and 'self.last_result = {"top1": top5[:, 0], "top5": top5}' in texts[key]
            and "self.completed_count += 1" in texts[key] for key in ("generic_classification", "native_classification")),
    }
    require(all(conditions.values()), "frozen_endpoint_or_global_gate_static_contract_failed:"+str(conditions))
    locations = []
    symbols = {"TaskGate", "GatedProcessor", "generic_callback", "SessionProxy", "native_callback",
               "ClassificationCompletion", "classification_topk", "measure_split_completion", "NativeTRT", "_hailo10_async_fifo_run"}
    for role, path in paths.items():
        tree = ast.parse(texts[role])
        locations.append({"role": role, "path": str(path.relative_to(root)), "sha256": sha(path),
            "symbols": [{"name": node.name, "first_line": node.lineno, "last_line": node.end_lineno}
                        for node in tree.body if isinstance(node, (ast.ClassDef, ast.FunctionDef)) and node.name in symbols]})
    return {"verified_unchanged_files": len(pins), "file_pins": pins,
            "static_endpoint_and_gate_checks": conditions, "code_locations": locations}


def verify(root, *, protocol_path=None):
    root = root.resolve()
    packet = root/"input/reuse"
    manifest_path = packet/"manifest.json"
    manifest = load(manifest_path)
    for item in manifest["files"]:
        path = inside(root, item["path"])
        require(sha(path) == item["sha256"] and path.stat().st_size == item["size_bytes"], "reuse_packet_file_changed:"+item["path"])
    old_path, pilot_path = packet/"old/PROTOCOL.json", packet/"old/PROTOCOL_pilot_canary_v1.json"
    require(sha(old_path) == OLD_PROTOCOL_SHA and sha(pilot_path) == CANARY_PROTOCOL_SHA, "old_protocol_pin_mismatch")
    old, pilot = load(old_path), load(pilot_path)
    progress_path = packet/"old/pilot_canary_PROGRESS.json"
    progress = load(progress_path)
    prior_review = load(packet/"old/mechanism_canary_independent_review.json")
    require(prior_review["status"] == "pass" and not prior_review["errors"]
        and prior_review["protocol_sha256"] == CANARY_PROTOCOL_SHA
        and prior_review["progress_sha256"] == sha(progress_path), "existing_independent_canary_review_not_bound")
    context_path = packet/"old/mechanism_results_independent_review.json"
    context = load(context_path)
    require(sha(context_path) == "f3aad14d72f3d9c9d8759f10f5d862c81b54893fc2f44f4eb70c4fab3bd484e4"
        and context["status"] == "PASS_final" and context["protocol_sha256"] == OLD_PROTOCOL_SHA
        and context["progress_snapshot_sha256"] == "8dafb76fcb92c94314a52e43fb06282d87200dc2900416af823b61786e079fa8",
        "prior_completed_series_context_not_exact")
    old_cells = [cell for cell in context["cells"] if cell["included"]]
    require(len(old_cells) == 60 and sum(cell["phase"] == "primary" for cell in old_cells) == 40
        and sum(cell["phase"] == "replication" for cell in old_cells) == 20
        and not context["pilots_pooled"] and not context["combined_ten_blocks_included"], "old_series_scope_changed")
    sources = source_contract(root, old)
    old_cases = {case["case_id"]: case for case in old["cases"] if case["case_id"] in CASES}
    pilot_cases = {case["case_id"]: case for case in pilot["cases"] if case["case_id"] in CASES}
    by_cell = {}
    for attempt in progress["attempts"]:
        if attempt["case_id"] in CASES:
            key = attempt["case_id"], attempt["variant"]
            require(key not in by_cell, "canary_retries_or_duplicate_cell_require_review")
            by_cell[key] = attempt
    require(set(by_cell) == {(case, variant) for case in CASES for variant in VARIANTS}, "missing_exact_resnet_variant_canary")
    rows, references, pids = [], {}, set()
    for (case_id, variant), attempt in sorted(by_cell.items()):
        case, pilot_case = old_cases[case_id], pilot_cases[case_id]
        config = load(root/case["config_path"])
        chain, schedule = VARIANTS[variant]
        require(case["config_sha256"] == pilot_case["config_sha256"] and
            case["native_args_sha256"] == pilot_case["native_args_sha256"], "pilot_confirmation_config_or_nativeargv_differ")
        require(attempt["status"] == "completed" and attempt["included"] is True and attempt["returncode"] == 0
            and attempt["state_check"]["comparable"] is True and attempt["before_state_check"]["comparable"] is True,
            "old_canary_not_completed_and_admitted")
        raw_path = packet/f"canaries/{case_id}_{variant}.json"
        require(sha(raw_path) == attempt["report_sha256"], "canary_raw_report_not_exact_ledger_binding")
        raw = load(raw_path)
        identity = {"protocol_sha256": CANARY_PROTOCOL_SHA, "identity": config["identity"],
            "artifact_identity": config["expected_runtime_artifacts"], "chain": chain,
            "schedule": schedule, "block": 0, "mode": "canary"}
        require(all(raw.get(key) == value for key, value in identity.items()) and raw["run_id"] == canonical(identity), "canary_identity_changed")
        require(raw["adapter_sha256"] == old["adapter"]["sha256"] == pilot["adapter"]["sha256"]
            and raw["product_runner_sha256"] == case["runners"][chain]["sha256"]
            and raw["config_sha256"] == case["config_sha256"], "canary_source_config_identity_mismatch")
        require(raw["pid"] not in pids and raw["status"] == "complete" and raw["canary_pass"] is True
            and raw["worker_cpu_affinity"] == old["device"]["state_policy"]["affinity"], "canary_process_or_affinity_contract_failed")
        pids.add(raw["pid"])
        pilot_sources = {item["path"]: item["sha256"] for item in pilot_case["required_sources"]}
        current_sources = {item["remote_relative"]: item["sha256"] for item in sources["file_pins"]}
        for path, digest in raw["loaded_source_hashes"].items():
            require(path.startswith(pilot["device"]["remote_root"]+"/") and pilot_sources.get(path) == digest,
                    "canary_imported_unfrozen_source")
            suffix = path[len(pilot["device"]["remote_root"])+1:]
            require(current_sources.get(suffix) == digest, "canary_new_source_suffix_or_content_mismatch:"+suffix)
        require(raw["sequence"] == SEQUENCE, "mixed_input_sequence_changed")
        metrics = raw["metrics_diagnostic_only"]
        if chain == "generic":
            require(raw["checked_input_ids"] == SEQUENCE and metrics["requested_task_count"] == metrics["completed_task_count"]
                == metrics["processor_count_delta"] == 32 and metrics["fill_and_drain_included"] is True
                and metrics["worker_count"] == 2 and metrics["queue_depth"] == 2, "generic_canary_endpoint_or_schedule_failed")
        else:
            checked = raw["checked_requests"]
            require(sorted(item["request_id"] for item in checked) == list(range(32))
                and all(item["input_id"] == SEQUENCE[item["request_id"]] for item in checked), "native_request_assignment_failed")
            require(metrics["produced_frames"] == metrics["consumed_frames"] == metrics["postprocess_completed_frames"] == 32
                and metrics["postprocess_completion_verified"] is True and metrics["completed_task_stage"] == "classification_top1_top5"
                and metrics["inflight"] == (8 if schedule == "product" else 1) and metrics["queue_depth"] == 3,
                "native_canary_endpoint_or_schedule_failed")
            latency = metrics["request_latency"]
            require(latency["count"] == latency["expected_count"] == 32 and latency["task_complete"] is True
                and all(value == 0 for value in latency["errors"].values()), "native_per_request_completion_failed")
        arrays, outputs = {}, {}
        require(len(raw["reference_manifest"]) == 2, "missing_both_serial_references")
        for item in raw["reference_manifest"]:
            label = item["input_id"]
            input_path = packet/"tensors"/(item["input_sha256"]+".npy")
            require(sha(input_path) == item["input_sha256"], "canary_input_hash_mismatch")
            arrays[label] = np.load(input_path, allow_pickle=False)
            outputs[label] = {}
            for name, tensor in item["outputs"].items():
                path = packet/"tensors"/(tensor["sha256"]+".npy")
                require(sha(path) == tensor["sha256"], "canary_reference_hash_mismatch")
                arr = np.load(path, allow_pickle=False)
                require(list(arr.shape) == tensor["shape"] and str(arr.dtype) == tensor["dtype"] and np.isfinite(arr).all(), "reference_shape_dtype_or_finiteness_failed")
                outputs[label][name] = arr
        require(set(arrays) == {0, 1} and arrays[0].dtype == arrays[1].dtype == np.uint8
            and np.array_equal(arrays[1], np.uint8(255)-arrays[0]), "canary_inputs_not_distinct_prepared_complements")
        require(raw["reference_manifest"][0]["input_sha256"] == config["input_binding"]["prepared_input"]["sha256"], "timed_prepared_input_binding_changed")
        require(any(not np.allclose(outputs[0][name], outputs[1][name], rtol=1e-5, atol=1e-5) for name in outputs[0]), "canary_outputs_not_distinguishable")
        history_dir = packet/"historical"/case_id
        require(sha(history_dir/"source_manifest.json") == config["functional_reference"]["source_manifest_sha256"], "historical_reference_manifest_changed")
        historical = load(history_dir/"source_manifest.json")
        require(historical["case"] == case["cut"] and historical["task"] == "classification" and
            historical["endpoint_contract_complete"] is True, "historical_reference_endpoint_not_complete")
        for descriptor in historical["outputs"]:
            name = descriptor["name"]
            spec = config["functional_reference"]["outputs"][name]
            path = history_dir/Path(descriptor["file"]).name
            require(sha(path) == spec["sha256"] == descriptor["sha256"], "historical_raw_reference_changed")
            array = np.fromfile(path, dtype=np.dtype(spec["dtype"])).reshape(spec["shape"])
            require(bytes_equal(array, outputs[0][name]), "historical_original_input_reference_not_byte_equal")
        require(raw["historical_functional_reference_match"] is True and raw["historical_reference_metrics"]["top1_match"] is True
            and raw["historical_reference_metrics"]["max_abs_all_outputs"] == 0, "functional_original_input_anchor_failed")
        references[(case_id, variant)] = outputs
        rows.append({"case_id": case_id, "cut": case["cut"], "variant": variant, "pid": raw["pid"],
            "old_controller_run_id": attempt["run_id"], "old_report_path": f"input/reuse/canaries/{case_id}_{variant}.json",
            "old_report_sha256": sha(raw_path), "checked_requests": 32, "reference_inputs": 2,
            "artifact_identity": config["expected_runtime_artifacts"], "precision": config["identity"]["precision"],
            "prepared_input_sha256": config["input_binding"]["prepared_input"]["sha256"],
            "output_endpoint_id": config["identity"]["output_endpoint_id"], "loaded_source_files": len(raw["loaded_source_hashes"]),
            "canary_deviation": raw["required_canary_deviation"], "status": "PASS"})
    comparisons = []
    for case_id in CASES:
        for schedule in ("product", "single"):
            receipt = load(packet/f"comparisons/{case_id}_{schedule}.json")
            require(receipt["generic_result_sha256"] == sha(packet/f"canaries/{case_id}_G_{schedule}.json")
                and receipt["native_result_sha256"] == sha(packet/f"canaries/{case_id}_N_{schedule}.json")
                and receipt["numerical_parity_on_both_canary_inputs"] is True, "existing_cross_chain_receipt_not_exact")
        for first, second in (("G_product", "N_product"), ("G_single", "N_single"),
                              ("G_product", "G_single"), ("N_product", "N_single")):
            for label in (0, 1):
                require(all(bytes_equal(references[(case_id, first)][label][name], references[(case_id, second)][label][name])
                    for name in references[(case_id, first)][label]), "cross_chain_or_schedule_reference_mismatch")
            comparisons.append({"case_id": case_id, "first": first, "second": second,
                                "both_input_references_byte_equal": True})
    result = {"schema": "resnet-full-replication-reuse-v1", "status": "PASS", "hardware_executed": False,
        "old_report_modified": False, "old_protocol_sha256": OLD_PROTOCOL_SHA, "canary_protocol_sha256": CANARY_PROTOCOL_SHA,
        "packet_manifest_path": "input/reuse/manifest.json", "packet_manifest_sha256": sha(manifest_path),
        "packet_files": len(manifest["files"]), "packet_bytes": sum(item["size_bytes"] for item in manifest["files"]),
        "audit_code_sha256": sha(__file__), "existing_canary_processes": 8, "mixed_requests_checked": 256,
        "distinct_worker_pids": len(pids), "cells": rows, "reference_parity": comparisons,
        "source_reuse": sources, "intended_new_remote_root": NEW_REMOTE_ROOT,
        "old_series_context": {"review_path": "input/reuse/old/mechanism_results_independent_review.json",
            "review_sha256": sha(context_path), "old_regnet_processes": 40, "old_native_resnet_processes": 20,
            "new_processes_from_old_series": 0, "new_blocks_from_old_series": 0,
            "purpose": "Separate descriptive context and old process identity exclusion only; old statistics are not recomputed."},
        "path_relocation": "Old pilot_canary_v1 and confirmation_v1 source prefixes map by identical remote_relative suffix to new remote_root; source/config/nativeargv bytes and HEF/TRT/input/reference paths stay unchanged.",
        "old_protocol_md": "Absent in completed old report. Exact old PROTOCOL.json plus README.md/RESUME.md are preserved; no old file was created.",
        "limitations": ["Canaries use two deterministic UINT8 prepared tensors and 32 mixed requests; no dataset accuracy or arbitrary-stream proof.",
            "Generic canary rotates cached prepared-input mapping; Native canary fills the real reusable slot per submit. Timed repeated-input paths are unchanged.",
            "Global one-task admission releases only after ClassificationCompletion processes synchronized materialized outputs and Top1/Top5; Native also uses one async slot. This guarantee uses unchanged source/call order plus inflight/count closure and exact canaries; no direct global outstanding-task highwater counter was recorded.",
            "The old Native20 timing processes remain a separate cohort and do not enter the new40 randomized blocks.",
            "Historical canary evidence is reused; current device, artifacts, profiles and exact process source closure still require the coordinator's fresh before/after admission checks.",
            "This packet does not repeat the all450 audit, calibration or hardware probes."]}
    if protocol_path is not None:
        path = Path(protocol_path).resolve()
        new = load(path)
        require(new["device"]["remote_root"] == NEW_REMOTE_ROOT, "new_remote_root_differs_from_reuse_contract")
        for key in ("setup_id", "python", "expected_identity", "state_policy"):
            require(new["device"][key] == old["device"][key], "new_device_contract_changed:"+key)
        for key in ("recipe", "endpoint", "input_policy", "factors", "profiles"):
            require(new[key] == old[key], "new_frozen_reuse_contract_changed:"+key)
        require(new["adapter"]["sha256"] == old["adapter"]["sha256"], "new_adapter_changed")
        require({case["case_id"] for case in new["cases"]} == set(CASES), "new_case_set_changed")
        for case in new["cases"]:
            original = old_cases[case["case_id"]]
            for key in ("artifact_identity", "config_path", "config_sha256", "native_args_path", "native_args_sha256", "required_artifacts"):
                require(case[key] == original[key], "new_case_binding_changed:"+key)
            def normalized(items, prefix):
                require(all(item["path"].startswith(prefix+"/") for item in items), "source_not_inside_frozen_remote_root")
                return {item["path"][len(prefix)+1:]: item["sha256"] for item in items}
            require(normalized(case["required_sources"], NEW_REMOTE_ROOT) == normalized(original["required_sources"], old["device"]["remote_root"]), "new_source_closure_changed")
            for chain in ("generic", "native"):
                before, after = original["runners"][chain], case["runners"][chain]
                require(after["sha256"] == before["sha256"] and after["path"] == before["path"].replace(old["device"]["remote_root"], NEW_REMOTE_ROOT, 1), "new_runner_source_changed")
        result["new_protocol_sha256"] = sha(path)
        result["new_protocol_reuse_contract_compatible"] = True
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--prepare-from", type=Path)
    parser.add_argument("--protocol", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    if args.prepare_from:
        prepare(root, args.prepare_from)
    report = verify(root, protocol_path=args.protocol)
    path = args.output or root/"receipts/reuse"/("protocol_check.json" if args.protocol else "index.json")
    write(path, report)
    print(json.dumps({"status": report["status"], "existing_canaries": report["existing_canary_processes"],
        "checked_requests": report["mixed_requests_checked"], "packet_files": report["packet_files"],
        "source_config_files_verified": report["source_reuse"]["verified_unchanged_files"],
        "output": str(path), "output_sha256": sha(path)}))


if __name__ == "__main__":
    main()
