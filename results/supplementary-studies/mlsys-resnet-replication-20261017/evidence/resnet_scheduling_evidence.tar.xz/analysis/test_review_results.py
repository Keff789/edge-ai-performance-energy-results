#!/usr/bin/env python3
"""Focused synthetic tests of the independent reviewer; never imports analyzer."""
import copy
import csv
import json
import math
from pathlib import Path
import random
import shutil
import tempfile
import unittest

import review_results as review

HERE = Path(__file__).resolve().parent
PRIOR = HERE.parent/'input/reuse/old/mechanism_results_independent_review.json'


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value))
    return review.read_json(path)[1]


class Fixture:
    def __init__(self, root):
        self.root = root
        target = root/'input/reuse/old/mechanism_results_independent_review.json'
        target.parent.mkdir(parents=True)
        shutil.copyfile(PRIOR, target)
        self.protocol = {'schema': 'mechanism-controller-v1', 'kind': 'resnet-full-replication',
            'series_id': 'resnet_full_replication_v1', 'frozen_at_utc': '2026-10-17T18:00:00+00:00',
            'reuse_original_cells': False, 'extension_enabled': False, 'pilot_results_in_confirmatory_estimates': False,
            'attempt_budget': {'required_admitted_cells': 40, 'technical_replacements': 4, 'max_process_attempts': 44},
            'recipe': {'warmup_s': 30, 'window_s': 60, 'timeout_s': 300},
            'adapter': {'sha256': 'a'*64}, 'device': {'remote_root': '/home/nx/Reports/synthetic_new/resnet_full_replication_v1',
                'state_policy': {'affinity': [0, 1]}}, 'cases': [], 'phases': {}}
        self.configs = {}
        for cut in ['b002', 'b095']:
            key = 'resnet_'+cut
            config = {'identity': {'model_id': 'resnet50', 'case_id': cut}, 'queue_depth': 2,
                      'expected_runtime_artifacts': {'engine': {'path': '/device/'+cut+'.engine', 'sha256': 'e'*64}}}
            path = 'input/'+key+'.json'
            sha = save(root/path, config)
            sources = [{'path': '/device/'+chain+'.py', 'sha256': letter*64}
                       for chain, letter in [('generic', 'c'), ('native', 'd')]]
            self.protocol['cases'].append({'case_id': key, 'model_id': 'resnet50', 'cut': cut,
                'config_path': path, 'config_sha256': sha, 'artifact_identity': config['expected_runtime_artifacts'],
                'required_sources': sources, 'runners': {chain: {'path': s['path'], 'sha256': s['sha256']}
                    for chain, s in zip(['generic', 'native'], sources)}})
            self.configs[key] = config
        spec = {'case_ids': ['resnet_b002', 'resnet_b095'], 'variants': list(review.VARIANTS),
                'blocks': [1, 2, 3, 4, 5], 'mode': 'duration', 'seed': 20261017}
        rng, spec['schedule'] = random.Random(spec['seed']), []
        for block in spec['blocks']:
            cells = [(case, variant) for case in spec['case_ids'] for variant in spec['variants']]
            rng.shuffle(cells)
            spec['schedule'].extend({'case_id': case, 'variant': variant, 'block': block} for case, variant in cells)
        spec['expected_runs'] = 40
        self.protocol['phases']['primary'] = spec
        self.protocol_sha = save(root/'PROTOCOL.json', self.protocol)
        self.progress = {'schema': 'mechanism-progress-v1', 'protocol_sha256': self.protocol_sha,
                         'series_id': self.protocol['series_id'], 'attempts': [], 'events': []}
        cases = {c['case_id']: c for c in self.protocol['cases']}
        for serial, cell in enumerate(spec['schedule'], 1):
            case, config = cases[cell['case_id']], self.configs[cell['case_id']]
            identity = {'protocol_sha256': self.protocol_sha, 'artifact_identity': config['expected_runtime_artifacts'],
                        'case_id': case['case_id'], 'cut': case['cut'], 'variant': cell['variant'],
                        'block': cell['block'], 'phase': 'primary', 'mode': 'duration'}
            action = {**identity, 'run_id': review.canonical(identity)}
            chain, scheduling = review.VARIANTS[cell['variant']]
            raw_identity = {'protocol_sha256': self.protocol_sha, 'identity': config['identity'],
                'artifact_identity': config['expected_runtime_artifacts'], 'chain': chain, 'schedule': scheduling,
                'block': cell['block'], 'mode': 'duration'}
            ratios = {'G_product': .8, 'N_product': 1.5, 'G_single': 1.1, 'N_single': .9}
            count = 6000 if case['cut'] == 'b002' else int(6000*ratios[cell['variant']])
            start = review.freeze_time_ns(self.protocol)+serial*100_000_000_000
            raw = {**raw_identity, 'schema': 'mechanism-product-workers-v1', 'run_id': review.canonical(raw_identity),
                'status': 'complete', 'adapter_sha256': 'a'*64, 'config_sha256': case['config_sha256'],
                'product_runner': case['runners'][chain]['path'], 'product_runner_sha256': case['runners'][chain]['sha256'],
                'schedule_description': 'unchanged_product_parallelism' if scheduling == 'product' else
                    'one_global_outstanding_task_until_classification_tail_complete',
                'loaded_source_hashes': {case['runners'][chain]['path']: case['runners'][chain]['sha256']},
                'diagnostic_adapter': True, 'energy_measured': False, 'worker_cpu_affinity': [0, 1],
                'accepted_work_drained': True, 'warmup_duration_s': 30, 'warmup_completed_count': 1000,
                'admission_window_seconds': 60, 'completed_work_units': count, 'measurement_time_seconds': 60.0,
                'completed_task_fps': count/60.0, 'pid': 10_000+serial, 'started_time_ns': start,
                'finished_time_ns': start+90_000_000_000}
            if chain == 'generic':
                mstart = 1_000_000_000_000+serial*100_000_000_000
                raw['metrics'] = {'status': 'ok', 'admitted_task_count': count, 'completed_task_count': count,
                    'processor_count_delta': count, 'completed_work_units': count, 'postprocess_timed': True,
                    'output_materialization_timed': True, 'accepted_work_drained': True, 'fill_and_drain_included': True,
                    'admission_stopped_at_deadline': True, 'measured_makespan_seconds': 60.0,
                    'worker_count': 2, 'queue_depth': 2, 'measurement_start_ns': mstart,
                    'admission_deadline_ns': mstart+60_000_000_000, 'admission_stopped_ns': mstart+60_000_000_000,
                    'measurement_end_ns': mstart+60_000_000_000}
            else:
                raw['metrics'] = {'produced_frames': count, 'consumed_frames': count, 'completed_work_units': count,
                    'postprocess_completed_frames': count, 'task_complete': True, 'postprocess_completion_verified': True,
                    'postprocess_included': True, 'completed_task_stage': 'classification_top1_top5',
                    'trt_copy_outputs': True, 'measurement_endpoint': 'completed_task',
                    'last_completion_source': 'current_output_top1_top5', 'warmup_contract': 'fully_drained_before_worker_start',
                    'makespan_ms': 60_000.0, 'inflight': 8 if scheduling == 'product' else 1, 'queue_depth': 3}
            path = 'raw/'+action['run_id']+'.json'
            sha = save(root/path, raw)
            self.progress['attempts'].append({**action, 'attempt_id': action['run_id']+'_attempt01',
                'status': 'completed', 'included': True, 'returncode': 0, 'report_path': path, 'report_sha256': sha,
                'before_state_check': {'comparable': True, 'reasons': []}, 'state_check': {'comparable': True, 'reasons': []}})

    def run(self):
        save(self.root/'immutable_snapshot.json', self.progress)
        return review.review(self.root/'PROTOCOL.json', self.root/'immutable_snapshot.json', root=self.root)

    def mutate(self, index, callback):
        attempt = self.progress['attempts'][index]
        path = self.root/attempt['report_path']
        raw, _ = review.read_json(path)
        callback(raw)
        attempt['report_sha256'] = save(path, raw)

    def corrected_state_retry(self):
        prior = self.progress['attempts'][0]
        retry = copy.deepcopy(prior)
        prior.update(included=False, state_check={'comparable': False, 'reasons': ['gpu_clock_changed']})
        retry['attempt_id'] = retry['run_id']+'_attempt02'
        retry['retry_cause'] = {'run_id': retry['run_id'], 'protocol_sha256': self.protocol_sha,
            'cause_corrected': True, 'technical_error': 'state_policy', 'reason': 'frozen clocks restored',
            'previous_state_reasons': ['gpu_clock_changed']}
        raw, _ = review.read_json(self.root/retry['report_path'])
        raw['pid'] += 100_000
        raw['started_time_ns'] -= 1
        raw['finished_time_ns'] += 1
        # Put first excluded process before the fresh replacement and keep
        # replacement inside the fixed rest gap before the next schedule cell.
        original, _ = review.read_json(self.root/prior['report_path'])
        original['started_time_ns'] -= 95_000_000_000
        original['finished_time_ns'] -= 95_000_000_000
        prior['report_sha256'] = save(self.root/prior['report_path'], original)
        retry['report_path'] = 'raw/retry.json'
        retry['report_sha256'] = save(self.root/retry['report_path'], raw)
        self.progress['attempts'].insert(1, retry)


class Tests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.fixture = Fixture(self.root)

    def tearDown(self):
        self.temporary.cleanup()

    def test_independent_quantile_sample_sd_and_null_boundary(self):
        self.assertAlmostEqual(review.student_quantile95(4), 2.7764451051977987, places=12)
        row = review.statistics_from_logs([1, 2, 3, 4, 5])
        self.assertEqual(row['mean_log'], 3)
        self.assertAlmostEqual(row['sd_log'], math.sqrt(2.5))
        self.assertEqual(review.ratio_decision(review.statistics_from_logs([0]*5))['interval_relation_to_one'], 'includes_one')

    def test_full_forty_seven_contrasts_and_no_old_pooling(self):
        result = self.fixture.run()
        self.assertEqual(result['status'], 'PASS_final')
        self.assertEqual(result['admitted_new_processes'], 40)
        self.assertEqual(result['distinct_new_worker_pids'], 40)
        self.assertEqual((len(result['blocks']), len(result['summaries'])), (35, 7))
        interaction = next(x for x in result['summaries'] if x['contrast'] == 'interaction')
        self.assertAlmostEqual(interaction['geometric_mean'], (1.5/.9)/(.8/1.1), places=12)
        self.assertFalse(result['previous_observations_pooled'])
        self.assertEqual(result['previous_studies']['old_native_only_resnet_processes'], 20)

    def test_no_partial_verdict(self):
        self.fixture.progress['attempts'].pop()
        result = self.fixture.run()
        self.assertEqual(result['summaries'], [])
        self.assertIsNone(result['scientific_decision']['primary_interaction'])

    def test_wrong_journal_series_is_rejected(self):
        self.fixture.progress['series_id'] = 'OLD_SERIES'
        with self.assertRaisesRegex(ValueError, 'snapshot_protocol_or_pilot_scope_mismatch'):
            self.fixture.run()

    def test_nonzero_completed_returncode_is_fatal_including_replacement(self):
        self.fixture.progress['attempts'][0]['returncode'] = 1
        self.assertNotEqual(self.fixture.run()['status'], 'PASS_final')
        self.fixture.progress['attempts'][0]['returncode'] = 0
        self.fixture.corrected_state_retry()
        self.fixture.progress['attempts'][0]['returncode'] = 1
        self.assertNotEqual(self.fixture.run()['status'], 'PASS_final')

    def test_true_interaction_does_not_imply_productive_rank_reversal(self):
        cells = [{'included': True, 'block': b, 'variant': v, 'cut': c,
            'completed_task_fps': 100 if c == 'b002' else {'G_product': 120, 'N_product': 150, 'G_single': 100, 'N_single': 90}[v]}
            for b in range(1, 6) for v in review.VARIANTS for c in ['b002', 'b095']]
        _, summaries = review.paired_statistics(cells)
        decision = review.scientific_decision(summaries)
        self.assertFalse(decision['productive_point_preferences_differ'])
        self.assertEqual(decision['primary_interaction']['nominal_interval_support'], 'same_direction_supported_nominally')

    def test_opposite_or_uncertain_interaction_are_distinct(self):
        result = self.fixture.run()
        rows = result['summaries']
        target = next(i for i, r in enumerate(rows) if r['contrast'] == 'interaction')
        for values, expected in [([-.4]*5, 'opposite_direction_supported_nominally'),
                                 ([-.4, -.2, 0, .2, .4], 'inconclusive_interval_includes_one')]:
            changed = copy.deepcopy(rows)
            changed[target] = {'contrast': 'interaction', **review.statistics_from_logs(values)}
            self.assertEqual(review.scientific_decision(changed)['primary_interaction']['nominal_interval_support'], expected)

    def test_completed_admitted_rerun_forbidden(self):
        retry = copy.deepcopy(self.fixture.progress['attempts'][0])
        retry['attempt_id'] = retry['run_id']+'_attempt02'
        retry['retry_cause'] = {'run_id': retry['run_id'], 'protocol_sha256': self.fixture.protocol_sha,
            'cause_corrected': True, 'technical_error': 'implementation', 'reason': 'not a permitted completed repeat'}
        self.fixture.progress['attempts'].insert(1, retry)
        result = self.fixture.run()
        self.assertNotEqual(result['status'], 'PASS_final')
        self.assertTrue(any('inadmissible_retry_lineage' in c['errors'] for c in result['cells']))

    def test_corrected_state_exclusion_preserved_not_replicate(self):
        self.fixture.corrected_state_retry()
        result = self.fixture.run()
        self.assertEqual(result['status'], 'PASS_final')
        self.assertEqual(result['completed_process_attempts'], 41)
        self.assertEqual(len(result['all_attempts_preserved']), 41)
        self.assertTrue(all(r['n_blocks'] == 5 for r in result['summaries']))
        self.fixture.progress['attempts'][1]['retry_cause']['previous_state_reasons'] = ['wrong']
        self.assertNotEqual(self.fixture.run()['status'], 'PASS_final')

    def test_excluded_raw_identity_error_is_fatal(self):
        self.fixture.corrected_state_retry()
        self.fixture.mutate(0, lambda raw: raw.update(config_sha256='f'*64))
        self.assertNotEqual(self.fixture.run()['status'], 'PASS_final')

    def test_excluded_predecessor_still_requires_valid_prelaunch_admission(self):
        self.fixture.corrected_state_retry()
        self.fixture.progress['attempts'][0]['before_state_check']['comparable'] = False
        self.assertNotEqual(self.fixture.run()['status'], 'PASS_final')

    def test_excluded_state_reasons_must_be_nonempty_list(self):
        self.fixture.corrected_state_retry()
        reasons = {'gpu_clock_changed': True}
        self.fixture.progress['attempts'][0]['state_check']['reasons'] = reasons
        self.fixture.progress['attempts'][1]['retry_cause']['previous_state_reasons'] = reasons
        self.assertNotEqual(self.fixture.run()['status'], 'PASS_final')

    def test_completed_pid_is_positive_including_excluded_predecessor(self):
        self.fixture.corrected_state_retry()
        self.fixture.mutate(0, lambda raw: raw.update(pid=-1))
        self.assertNotEqual(self.fixture.run()['status'], 'PASS_final')

    def test_json_and_csv_science_must_both_match_independent_values(self):
        result = self.fixture.run()
        rows, blocks = result['summaries'], result['blocks']
        own = result['scientific_decision']
        direction = {'above': 'above_one', 'below': 'below_one', 'includes_one': 'includes_one'}
        decisions = {
            'productive_point_preferences_opposite': own['productive_point_preferences_differ'],
            'productive_opposite_preferences_both_intervals_exclude_one': own['productive_opposite_preferences_supported_by_individual_nominal_intervals'],
            'cut_preferences': {v: {'point_preferred_cut': d['point_preference'],
                'interval_direction': direction[d['interval_relation_to_one']]} for v, d in own['variant_cut_preferences'].items()},
            'interaction_point_direction_relative_to_RegNet': 'same',
            'interaction_interval_direction_relative_to_RegNet': 'same_direction_above_one'}
        for effect in ['generic_schedule_effect', 'native_schedule_effect']:
            row = next(r for r in rows if r['contrast'] == effect)
            decisions[effect] = {'point_direction': 'above_one' if row['mean_log'] > 0 else 'below_one',
                'interval_direction': 'above_one' if row['log_ci95_low'] > 0 else 'below_one'}
        published = {'protocol_sha256': result['protocol_sha256'],
            'progress_snapshot_sha256': result['progress_snapshot_sha256'], 'status': 'complete',
            'summaries': copy.deepcopy(rows), 'blocks': copy.deepcopy(blocks), 'decisions': decisions}
        prefix = self.root/'published'
        for suffix, data in [('_summaries.csv', rows), ('_blocks.csv', blocks)]:
            with Path(str(prefix)+suffix).open('w', newline='') as stream:
                writer = csv.DictWriter(stream, fieldnames=list(data[0]))
                writer.writeheader()
                writer.writerows(data)
        save(Path(str(prefix)+'.json'), published)
        self.assertEqual(review.compare_published(rows, blocks, prefix, result['protocol_sha256'],
                          result['progress_snapshot_sha256'])['numeric_values_checked'], 294)
        published['summaries'][-1]['geometric_mean'] = 999999
        save(Path(str(prefix)+'.json'), published)
        with self.assertRaisesRegex(ValueError, 'analyzer_summary_mismatch:json'):
            review.compare_published(rows, blocks, prefix, result['protocol_sha256'], result['progress_snapshot_sha256'])
        published['summaries'] = rows
        published['blocks'] = []
        save(Path(str(prefix)+'.json'), published)
        with self.assertRaisesRegex(ValueError, 'analyzer_block_row_count_mismatch:json'):
            review.compare_published(rows, blocks, prefix, result['protocol_sha256'], result['progress_snapshot_sha256'])

    def test_attempt_budget_and_active_ledger_rejected(self):
        self.fixture.progress['attempts'] += copy.deepcopy(self.fixture.progress['attempts'][:5])
        with self.assertRaisesRegex(ValueError, 'attempt_budget_exceeded'):
            self.fixture.run()
        save(self.root/'PROGRESS.json', self.fixture.progress)
        with self.assertRaisesRegex(ValueError, 'immutable_phase_exit'):
            review.review(self.root/'PROTOCOL.json', self.root/'PROGRESS.json', root=self.root)

    def test_actual_schedule_and_process_overlap_rejected(self):
        self.fixture.progress['attempts'][0], self.fixture.progress['attempts'][1] = self.fixture.progress['attempts'][1], self.fixture.progress['attempts'][0]
        self.assertNotEqual(self.fixture.run()['status'], 'PASS_final')
        self.fixture.progress['attempts'][0], self.fixture.progress['attempts'][1] = self.fixture.progress['attempts'][1], self.fixture.progress['attempts'][0]
        self.fixture.mutate(1, lambda raw: raw.update(started_time_ns=raw['started_time_ns']-50_000_000_000))
        self.assertNotEqual(self.fixture.run()['status'], 'PASS_final')

    def test_wrong_count_or_warmup_completion_rejected(self):
        self.fixture.mutate(0, lambda raw: raw.update(completed_task_fps=99999))
        self.assertNotEqual(self.fixture.run()['status'], 'PASS_final')
        self.fixture.mutate(0, lambda raw: raw.update(completed_task_fps=raw['completed_work_units']/60, warmup_completed_count=0))
        self.assertNotEqual(self.fixture.run()['status'], 'PASS_final')

    def test_old_identity_or_pre_freeze_observation_rejected(self):
        old = json.loads(PRIOR.read_text())
        first = next(x for x in old['cells'] if x['included'])
        self.fixture.mutate(0, lambda raw: raw.update(pid=first['pid'], started_time_ns=first['started_time_ns'], finished_time_ns=first['finished_time_ns']))
        result = self.fixture.run()
        self.assertNotEqual(result['status'], 'PASS_final')
        self.assertTrue(any('old_worker_identity_reused' in row['errors'] for row in result['cells']))


if __name__ == '__main__':
    unittest.main()
