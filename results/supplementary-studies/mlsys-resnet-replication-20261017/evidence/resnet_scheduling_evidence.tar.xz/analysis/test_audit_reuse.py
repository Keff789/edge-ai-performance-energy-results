#!/usr/bin/env python3
"""Offline relocation/tamper checks of the compact evidence reuse packet."""
from pathlib import Path
import shutil
import sys
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import audit_reuse


class ReuseAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temp.name)/'renamed_extracted_result'
        cls.root.mkdir()
        original = HERE.parent
        shutil.copytree(original/'input/reuse', cls.root/'input/reuse')
        old = audit_reuse.load(cls.root/'input/reuse/old/PROTOCOL.json')
        for item in old['deploy_files']:
            if item['local_path'].startswith('results/mechanism_source_cases/') and not any(
                item['local_path'].endswith(case+suffix) for case in audit_reuse.CASES
                for suffix in ('_generic_config.json', '_native_argv.json')):
                continue
            destination = cls.root/item['local_path']
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(original/item['local_path'], destination)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def test_renamed_packet_validates_eight_canaries_and_all_source_copies(self):
        result = audit_reuse.verify(self.root)
        self.assertEqual(result['status'], 'PASS')
        self.assertEqual(result['existing_canary_processes'], 8)
        self.assertEqual(result['mixed_requests_checked'], 256)
        self.assertEqual(result['source_reuse']['verified_unchanged_files'], 312)
        self.assertEqual(result['old_series_context']['new_processes_from_old_series'], 0)

    def test_changed_canary_bytes_rejected(self):
        path = self.root/'input/reuse/canaries/resnet_b002_G_product.json'
        original = path.read_bytes()
        try:
            path.write_bytes(original+b'\n')
            with self.assertRaisesRegex(ValueError, 'reuse_packet_file_changed'):
                audit_reuse.verify(self.root)
        finally:
            path.write_bytes(original)

    def test_changed_global_gate_source_rejected(self):
        path = self.root/'analysis/mechanism_adapter.py'
        original = path.read_bytes()
        try:
            path.write_bytes(original.replace(b'threading.BoundedSemaphore(1)', b'threading.BoundedSemaphore(2)'))
            with self.assertRaisesRegex(ValueError, 'new_source_or_config_content_differs'):
                audit_reuse.verify(self.root)
        finally:
            path.write_bytes(original)


if __name__ == '__main__':
    unittest.main()
