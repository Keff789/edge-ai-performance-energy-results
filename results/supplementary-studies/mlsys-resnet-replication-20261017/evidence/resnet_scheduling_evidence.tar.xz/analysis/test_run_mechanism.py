"""Focused offline tests for the fresh ResNet study and technical retry guard."""
import copy
import importlib.util
import json
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("resnet_full_controller_tests", ROOT / "analysis/run_mechanism.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def protocol():
    return json.loads((ROOT / "PROTOCOL.json").read_text())


def test_exact_forty_fresh_eight_cell_blocks_and_unchanged_adapter():
    p = protocol()
    assert len(m.validate_protocol(p, ROOT)) == 2
    phase = p["phases"]["primary"]
    assert len(phase["schedule"]) == 40
    for block in range(1, 6):
        cells = [row for row in phase["schedule"] if row["block"] == block]
        assert len(cells) == 8
        assert {(row["case_id"], row["variant"]) for row in cells} == {
            (case, variant) for case in phase["case_ids"] for variant in m.VARIANTS}
    old = json.loads((ROOT / "input/reuse/old/PROTOCOL.json").read_text())
    assert m.digest(ROOT / p["adapter"]["path"]) == old["adapter"]["sha256"]
    assert p["reuse_original_cells"] is False and p["extension_enabled"] is False


@pytest.mark.parametrize("change", ["extension", "old_cell_reuse", "twenty_cells", "regnet", "cell_order", "seed"])
def test_altered_study_contract_fails_closed(change):
    p = protocol()
    if change == "extension": p["phases"]["extension"] = copy.deepcopy(p["phases"]["primary"])
    if change == "old_cell_reuse": p["reuse_original_cells"] = True
    if change == "twenty_cells": p["phases"]["primary"]["variants"] = ["N_product", "N_single"]
    if change == "regnet": p["cases"][0]["model_id"] = "regnet_x_1_6gf"
    if change == "cell_order": p["phases"]["primary"]["schedule"].reverse()
    if change == "seed": p["phases"]["primary"]["seed"] += 1
    with pytest.raises(ValueError):
        m.validate_protocol(p, ROOT)


def test_provisional_execute_stops_before_product_runtime_import(monkeypatch):
    c = m.Controller(ROOT, "PROTOCOL.json")
    if c.protocol["protocol_state"] != "PROVISIONAL":
        pytest.skip("this guard is exercised before root freezes the protocol")
    monkeypatch.setattr(m, "ProductRuntime", lambda *args: pytest.fail("draft attempted product/device work"))
    with pytest.raises(ValueError, match="provisional protocol cannot execute"):
        c.execute("primary")


class FakeRuntime:
    def __init__(self):
        self.transport = self
        self.launches = []

    def run(self, command, **kwargs):
        self.launches.append(command)
        return 0, "offline fake process only"

    def unclean(self):
        return False


@pytest.fixture
def retry_controller(tmp_path, monkeypatch):
    c = m.Controller(ROOT, "PROTOCOL.json")
    c.directory, c.progress_path = tmp_path, tmp_path / "PROGRESS.json"
    c.progress["attempts"] = []
    c.runtime = FakeRuntime()
    monkeypatch.setattr(c, "persist", lambda **event: None)
    monkeypatch.setattr(c, "reusable", lambda action, latest: latest["status"] == "completed")
    monkeypatch.setattr(c, "before_run", lambda *args: ({}, "offline-before.json", {"comparable": True, "reasons": []}))
    monkeypatch.setattr(c, "snapshots", lambda *args: ({}, "offline-after.json"))
    monkeypatch.setattr(c, "end_state", lambda *args: {"comparable": True, "reasons": []})
    monkeypatch.setattr(c, "collect", lambda *args: ({}, "offline-report.json", "a" * 64))
    def finish(action, attempt, collected, **kwargs):
        attempt.update(status="completed", included=True)
        return True
    monkeypatch.setattr(c, "finish", finish)
    action = c.action("primary", c.protocol["phases"]["primary"]["schedule"][0])
    prior = {**action, "attempt_id": action["run_id"] + "_attempt01", "status": "completed", "included": False,
             "state_check": {"comparable": False, "reasons": ["GPU_current_frequency_differs"]},
             "report_path": "preserved-excluded-report.json", "report_sha256": "b" * 64}
    c.progress["attempts"].append(prior)
    cause = {"run_id": action["run_id"], "protocol_sha256": c.protocol_sha256, "cause_corrected": True,
             "technical_error": "state_policy", "reason": "documented transient throttle ended; unchanged state now passes",
             "previous_state_reasons": ["GPU_current_frequency_differs"]}
    return c, action, prior, cause


def test_corrected_state_exclusion_starts_fresh_process_and_preserves_original(retry_controller):
    c, action, prior, cause = retry_controller
    original = copy.deepcopy(prior)
    assert c.perform(action, retry_cause=cause)
    assert len(c.runtime.launches) == 1 and len(c.progress["attempts"]) == 2
    assert c.progress["attempts"][0] == original
    replacement = c.progress["attempts"][1]
    assert replacement["attempt_id"].endswith("_attempt02") and replacement["retry_cause"] == cause


def test_excluded_cell_without_explicit_correction_never_launches(retry_controller):
    c, action, prior, cause = retry_controller
    assert not c.perform(action)
    assert not c.runtime.launches and len(c.progress["attempts"]) == 1


@pytest.mark.parametrize("change", ["reasons", "error_type", "protocol", "uncorrected", "no_description"])
def test_invalid_state_retry_cause_never_launches(retry_controller, change):
    c, action, prior, cause = retry_controller
    if change == "reasons": cause["previous_state_reasons"] = ["different_reason"]
    if change == "error_type": cause["technical_error"] = "transport"
    if change == "protocol": cause["protocol_sha256"] = "0" * 64
    if change == "uncorrected": cause["cause_corrected"] = False
    if change == "no_description": cause["reason"] = ""
    with pytest.raises(ValueError, match="excluded process retry"):
        c.perform(action, retry_cause=cause)
    assert not c.runtime.launches and len(c.progress["attempts"]) == 1


def test_admitted_cell_is_never_repeated_even_with_cause(retry_controller):
    c, action, prior, cause = retry_controller
    prior["included"] = True
    assert c.perform(action, retry_cause=cause)
    assert not c.runtime.launches and len(c.progress["attempts"]) == 1


def test_replacement_attempt_ceiling_is_enforced_before_launch(retry_controller):
    c, action, prior, cause = retry_controller
    c.progress["attempts"] = [{"run_id": f"other-{i}"} for i in range(43)] + [prior]
    with pytest.raises(ValueError, match="four documented technical"):
        c.perform(action, retry_cause=cause)
    assert not c.runtime.launches
