#!/usr/bin/env python3
"""Independent new40 ResNet raw-report review; no analyzer/runtime imports.

Statistical primitives reuse the separately reviewed stdlib-only implementation
from the completed study. Old observations are never pooled with this new cohort.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import random
import re
import sys


VARIANTS = {"G_product": ("generic", "product"), "N_product": ("native", "product"),
            "G_single": ("generic", "single"), "N_single": ("native", "single")}

SHA = re.compile(r"[a-f0-9]{64}\Z")

PRIOR_REVIEW_SHA = "f3aad14d72f3d9c9d8759f10f5d862c81b54893fc2f44f4eb70c4fab3bd484e4"
PRIOR_PROTOCOL_SHA = "bff5aff0a26d8148256a688bccd2dd7e254092d42fcafb36b59f486edb96d9fd"
PRIOR_PROGRESS_SHA = "8dafb76fcb92c94314a52e43fb06282d87200dc2900416af823b61786e079fa8"

def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()

def read_json(path, expected=None):
    raw = Path(path).read_bytes()  # The parsed bytes and their digest are identical.
    sha = hashlib.sha256(raw).hexdigest()
    if expected is not None and sha != expected:
        raise ValueError("hash_mismatch:" + str(path))
    return json.loads(raw), sha

def near(a, b):
    return math.isclose(float(a), float(b), rel_tol=1e-11, abs_tol=1e-11)

def beta_fraction(a, b, x):
    """Lentz continued fraction for the regularized incomplete beta function."""
    tiny, tolerance = 1e-300, 3e-14
    qab, qap, qam = a+b, a+1, a-1
    c, d = 1.0, 1-qab*x/qap
    d = 1/max(abs(d), tiny) * (1 if d >= 0 else -1)
    h = d
    for m in range(1, 10001):
        for aa in (m*(b-m)*x/((qam+2*m)*(a+2*m)),
                   -(a+m)*(qab+m)*x/((a+2*m)*(qap+2*m))):
            d = 1+aa*d
            if abs(d) < tiny:
                d = tiny
            c = 1+aa/c
            if abs(c) < tiny:
                c = tiny
            d = 1/d
            change = d*c
            h *= change
        if abs(change-1) < tolerance:
            return h
    raise ArithmeticError("incomplete_beta_did_not_converge")

def beta_regularized(a, b, x):
    if x <= 0:
        return 0.0
    if x >= 1:
        return 1.0
    front = math.exp(math.lgamma(a+b)-math.lgamma(a)-math.lgamma(b)
                     +a*math.log(x)+b*math.log1p(-x))
    if x < (a+1)/(a+b+2):
        return front*beta_fraction(a, b, x)/a
    return 1-front*beta_fraction(b, a, 1-x)/b

def student_cdf(value, df):
    tail = 0.5*beta_regularized(df/2, 0.5, df/(df+value*value))
    return 1-tail if value >= 0 else tail

def student_quantile95(df):
    low, high = 0.0, 1.0
    while student_cdf(high, df) < 0.975:
        high *= 2
    for _ in range(90):
        middle = (low+high)/2
        if student_cdf(middle, df) < 0.975:
            low = middle
        else:
            high = middle
    return (low+high)/2

def statistics_from_logs(values):
    n = len(values)
    if n < 2:
        raise ValueError("at_least_two_independent_blocks_required")
    mean = math.fsum(values)/n
    sd = math.sqrt(math.fsum((value-mean)**2 for value in values)/(n-1))
    se = sd/math.sqrt(n)
    t = student_quantile95(n-1)
    lo, hi = mean-t*se, mean+t*se
    return {"n_blocks": n, "mean_log": mean, "sd_log": sd, "se_log": se,
            "df": n-1, "t95": t, "log_ci95_low": lo, "log_ci95_high": hi,
            "geometric_mean": math.exp(mean), "ci95_low": math.exp(lo),
            "ci95_high": math.exp(hi), "ci_includes_null": lo <= 0 <= hi}

def resolve_task(root, value, original):
    path = Path(value)
    if not path.is_absolute():
        result = root/path
    elif path.is_relative_to(root):
        result = path
    else:
        prefixes = {Path(home)/"Reports"/name for home in ("/home/kmika", "/home/nx")
                    for name in (original, root.name)}
        found = [prefix for prefix in prefixes if path.is_relative_to(prefix)]
        if len(found) != 1:
            raise ValueError("path_not_in_known_task_root:" + str(path))
        result = root/path.relative_to(found[0])
    result = result.resolve()
    if not result.is_relative_to(root):
        raise ValueError("path_escapes_task_root")
    return result

def validate_raw(protocol, protocol_sha, case, config, action, report):
    chain, schedule = VARIANTS[action["variant"]]
    runtime_id = {"protocol_sha256": protocol_sha, "identity": config["identity"],
                  "artifact_identity": config["expected_runtime_artifacts"], "chain": chain,
                  "schedule": schedule, "block": action["block"], "mode": "duration"}
    required = {**runtime_id, "run_id": canonical(runtime_id), "schema": "mechanism-product-workers-v1",
                "status": "complete", "adapter_sha256": protocol["adapter"]["sha256"],
                "config_sha256": case["config_sha256"], "diagnostic_adapter": True,
                "energy_measured": False, "product_runner_sha256": case["runners"][chain]["sha256"],
                "product_runner": case["runners"][chain]["path"],
                "schedule_description": ('unchanged_product_parallelism' if schedule == 'product' else
                                         'one_global_outstanding_task_until_classification_tail_complete'),
                "worker_cpu_affinity": protocol["device"]["state_policy"]["affinity"],
                "accepted_work_drained": True, "warmup_duration_s": 30, "admission_window_seconds": 60}
    errors = ["raw_identity:"+key for key, value in required.items() if report.get(key) != value]
    loaded, allowed = report.get("loaded_source_hashes"), {s["path"]: s["sha256"] for s in case["required_sources"]}
    if not loaded or not isinstance(loaded, dict) or any(not isinstance(sha, str) or not SHA.fullmatch(sha)
          or allowed.get(path) != sha for path, sha in loaded.items()):
        errors.append("loaded_source_pin_mismatch")
    count, duration, rate = [report.get(k) for k in ("completed_work_units", "measurement_time_seconds", "completed_task_fps")]
    if (type(count) is not int or count <= 0 or type(duration) not in (int, float)
            or not math.isfinite(duration) or duration < 60 or type(rate) not in (int, float)
            or not math.isfinite(rate) or rate <= 0 or not near(rate, count/duration)):
        errors.append("invalid_full_makespan_rate_or_count")
    if (type(report.get("pid")) is not int or report['pid'] <= 0 or type(report.get("started_time_ns")) is not int
            or type(report.get("finished_time_ns")) is not int
            or report["finished_time_ns"] <= report["started_time_ns"]):
        errors.append("missing_independent_process_identity")
    try:
        elapsed = (report['finished_time_ns']-report['started_time_ns'])/1e9
        if elapsed+0.001 < 30+duration or type(report['warmup_completed_count']) is not int or report['warmup_completed_count'] <= 0:
            errors.append('warmup_or_full_process_time_inconsistent')
        metrics = report['metrics']
        if chain == 'generic':
            keys = ['admitted_task_count', 'completed_task_count', 'processor_count_delta', 'completed_work_units']
            if (any(metrics[k] != count for k in keys) or metrics['status'] != 'ok'
                    or metrics['postprocess_timed'] is not True or metrics['output_materialization_timed'] is not True
                    or metrics['accepted_work_drained'] is not True or metrics['fill_and_drain_included'] is not True
                    or metrics['admission_stopped_at_deadline'] is not True
                    or not near(metrics['measured_makespan_seconds'], duration)
                    or metrics['worker_count'] != 2 or metrics['queue_depth'] != 2):
                errors.append('generic_completion_or_schedule_contract_invalid')
            start, deadline, stop, end = [metrics[k] for k in ['measurement_start_ns', 'admission_deadline_ns', 'admission_stopped_ns', 'measurement_end_ns']]
            if deadline-start != 60_000_000_000 or not deadline <= stop <= end or not near((end-start)/1e9, duration):
                errors.append('generic_full_admission_and_drain_boundaries_invalid')
        else:
            keys = ['produced_frames', 'consumed_frames', 'completed_work_units', 'postprocess_completed_frames']
            if (any(metrics[k] != count for k in keys) or metrics['task_complete'] is not True
                    or metrics['postprocess_completion_verified'] is not True or metrics['postprocess_included'] is not True
                    or metrics['trt_copy_outputs'] is not True or metrics['measurement_endpoint'] != 'completed_task'
                    or metrics['last_completion_source'] != 'current_output_top1_top5'
                    or metrics['warmup_contract'] != 'fully_drained_before_worker_start'
                    or metrics['completed_task_stage'] != 'classification_top1_top5'
                    or not near(metrics['makespan_ms']/1000, duration)
                    or metrics['inflight'] != (8 if schedule == 'product' else 1) or metrics['queue_depth'] != 3):
                errors.append('native_completion_or_schedule_contract_invalid')
    except (KeyError, TypeError, ValueError, ZeroDivisionError):
        errors.append('completion_counter_or_boundary_metadata_invalid')
    return errors

def cells_from_reports(protocol, protocol_sha, progress, root, original):
    cases = {case["case_id"]: case for case in protocol["cases"]}
    if len(cases) != len(protocol["cases"]):
        raise ValueError("duplicate_case_id")
    schedule_check(protocol, cases)
    configs = {}
    for key, case in cases.items():
        config, _ = read_json(resolve_task(root, case["config_path"], original), case["config_sha256"])
        if config["identity"]["model_id"] != case["model_id"] or config["identity"]["case_id"] != case["cut"]:
            raise ValueError("config_case_mismatch:" + key)
        configs[key] = config
    by_run, rows, known, raw_processes, schedule_positions = {}, [], set(), {}, {}
    for index, attempt in enumerate(progress["attempts"]):
        by_run.setdefault(attempt.get("run_id"), []).append((index, attempt))
    for phase, spec in protocol["phases"].items():
        for schedule_position, cell in enumerate(spec["schedule"]):
            case, config = cases[cell["case_id"]], configs[cell["case_id"]]
            identity = {"protocol_sha256": protocol_sha, "artifact_identity": config["expected_runtime_artifacts"],
                        "case_id": case["case_id"], "cut": case["cut"], "variant": cell["variant"],
                        "block": cell["block"], "phase": phase, "mode": "duration"}
            action = {**identity, "run_id": canonical(identity)}
            run_id = action["run_id"]
            if run_id in known:
                raise ValueError("duplicate_scheduled_run_id")
            known.add(run_id)
            schedule_positions[run_id] = schedule_position
            attempts, errors = by_run.get(run_id, []), []
            row = {**cell, "phase": phase, "model": case["model_id"], "cut": case["cut"],
                   "run_id": run_id, "included": False, "attempt_count": len(attempts), "errors": errors,
                   "completed_attempt_processes": []}
            if not attempts:
                errors.append("not_started")
            else:
                for i, (progress_index, attempt) in enumerate(attempts):
                    if attempt.get("attempt_id") != f"{run_id}_attempt{i+1:02d}":
                        errors.append("attempt_sequence_changed")
                    if any(attempt.get(k) != v for k, v in action.items()):
                        errors.append("attempt_identity_changed")
                    if i:
                        cause = attempt.get("retry_cause") or {}
                        prior = attempts[i-1][1]
                        documented = (cause.get('cause_corrected') is True and cause.get('run_id') == run_id
                                      and cause.get('protocol_sha256') == protocol_sha
                                      and isinstance(cause.get('reason'), str) and bool(cause['reason'].strip()))
                        failed = (prior.get('status') == 'failed'
                                  and cause.get('technical_error') in {'launcher', 'transport', 'implementation'})
                        state_reasons = prior.get('state_check', {}).get('reasons', [])
                        excluded = (prior.get('status') == 'completed' and prior.get('included') is False
                                    and isinstance(state_reasons, list) and bool(state_reasons)
                                    and prior.get('state_check', {}).get('comparable') is False
                                    and cause.get('technical_error') == 'state_policy'
                                    and cause.get('previous_state_reasons') == state_reasons)
                        if not documented or not (failed or excluded):
                            errors.append("inadmissible_retry_lineage")
                    if attempt.get('status') == 'completed':
                        if attempt.get('returncode') != 0:
                            errors.append('completed_attempt_returncode_not_zero')
                        if (attempt.get('before_state_check', {}).get('comparable') is not True
                                or attempt.get('before_state_check', {}).get('reasons')):
                            errors.append('completed_attempt_before_state_not_comparable')
                        try:
                            raw, raw_sha = read_json(resolve_task(root, attempt['report_path'], original), attempt['report_sha256'])
                            issues = validate_raw(protocol, protocol_sha, case, config, action, raw)
                            row['completed_attempt_processes'].append({
                                'progress_index': progress_index, 'attempt_id': attempt['attempt_id'],
                                'recorded_included': attempt.get('included'), 'report_sha256': raw_sha,
                                'pid': raw['pid'], 'started_time_ns': raw['started_time_ns'],
                                'finished_time_ns': raw['finished_time_ns'], 'raw_errors': issues})
                            if issues:
                                errors.append('completed_attempt_raw_invalid:'+str(i+1))
                        except (OSError, KeyError, TypeError, ValueError) as failure:
                            errors.append('completed_attempt_evidence_invalid:'+str(failure))
                last = attempts[-1][1]
                row.update(last_status=last.get("status"), last_attempt_id=last.get("attempt_id"))
                if last.get("status") != "completed" or last.get("included") is not True:
                    errors.append("last_attempt_not_admitted_completed")
                if last.get("state_check", {}).get("comparable") is not True or last.get('state_check', {}).get('reasons'):
                    errors.append("end_state_not_comparable")
                if last.get("before_state_check", {}).get("comparable") is not True or last.get('before_state_check', {}).get('reasons'):
                    errors.append("before_state_not_comparable")
                if last.get("status") == "completed":
                    try:
                        sha = last["report_sha256"]
                        if not isinstance(sha, str) or not SHA.fullmatch(sha):
                            raise ValueError("malformed_report_hash")
                        report, _ = read_json(resolve_task(root, last["report_path"], original), sha)
                        errors.extend(validate_raw(protocol, protocol_sha, case, config, action, report))
                        row.update(report_sha256=sha, report_path=last["report_path"],
                                   completed_work_units=report["completed_work_units"],
                                   measurement_time_seconds=report["measurement_time_seconds"],
                                   completed_task_fps=report["completed_work_units"]/report["measurement_time_seconds"],
                                   pid=report.get("pid"), started_time_ns=report.get("started_time_ns"),
                                   finished_time_ns=report.get("finished_time_ns"), progress_index=attempts[-1][0])
                        raw_processes.setdefault((report.get("pid"), report.get("started_time_ns")), []).append(row)
                    except (OSError, ValueError, KeyError, TypeError, ZeroDivisionError) as error:
                        errors.append("raw_report_invalid:"+str(error))
            rows.append(row)
    for repeated in raw_processes.values():
        if len(repeated) > 1:
            for row in repeated:
                row["errors"].append("reused_process_identity")
    first_observed, observed_order, latest_position, delayed_retries = set(), {}, {}, set()
    for attempt in progress["attempts"]:
        key = attempt.get("run_id")
        if key in known and key not in first_observed:
            first_observed.add(key)
            observed_order.setdefault(attempt["phase"], []).append(schedule_positions[key])
            latest_position[attempt["phase"]] = schedule_positions[key]
        elif key in known and schedule_positions[key] != latest_position.get(attempt["phase"]):
            delayed_retries.add(key)
    for phase, positions in observed_order.items():
        if positions != list(range(len(positions))):
            for row in rows:
                if row["phase"] == phase:
                    row["errors"].append("observed_execution_order_differs_from_frozen_schedule_prefix")
    for row in rows:
        if row["run_id"] in delayed_retries:
            row["errors"].append("retry_after_advancing_frozen_schedule_violates_stop_on_failure")
    all_completed = [(meta, row) for row in rows for meta in row['completed_attempt_processes']]
    all_completed.sort(key=lambda item: item[0]['progress_index'])
    process_seen, prior_process = {}, None
    for meta, row in all_completed:
        if meta['pid'] in process_seen:
            row['errors'].append('worker_pid_reused_across_completed_attempts')
            process_seen[meta['pid']]['errors'].append('worker_pid_reused_across_completed_attempts')
        process_seen[meta['pid']] = row
        if prior_process and meta['started_time_ns'] < prior_process[0]['finished_time_ns']:
            row['errors'].append('completed_attempt_lifetimes_overlap_or_reverse')
            prior_process[1]['errors'].append('completed_attempt_lifetimes_overlap_or_reverse')
        prior_process = (meta, row)
    previous = None
    for row in sorted((r for r in rows if "progress_index" in r), key=lambda r: r["progress_index"]):
        if (previous is not None and type(row.get("started_time_ns")) is int
                and type(previous.get("finished_time_ns")) is int
                and row["started_time_ns"] < previous["finished_time_ns"]):
            row["errors"].append("raw_process_chronology_overlaps_or_reverses")
            previous["errors"].append("raw_process_chronology_overlaps_or_reverses")
        previous = row
    for row in rows:
        row["included"] = not row["errors"]
    unknown = [i for i, attempt in enumerate(progress["attempts"]) if attempt.get("run_id") not in known]
    return rows, unknown


def schedule_check(protocol, cases):
    """Only the new jointly randomized eight-cell ResNet blocks may enter."""
    if (protocol.get('schema') != 'mechanism-controller-v1'
            or protocol.get('kind') != 'resnet-full-replication'
            or protocol.get('series_id') != 'resnet_full_replication_v1'
            or protocol.get('reuse_original_cells') is not False
            or protocol.get('extension_enabled') is not False
            or set(protocol['phases']) != {'primary'}
            or len(cases) != 2
            or {(c['model_id'], c['cut']) for c in cases.values()} != {('resnet50', 'b002'), ('resnet50', 'b095')}):
        raise ValueError('new_resnet_only_protocol_required')
    spec = protocol['phases']['primary']
    if (spec['blocks'] != [1, 2, 3, 4, 5] or spec['mode'] != 'duration'
            or set(spec['variants']) != set(VARIANTS) or len(spec['variants']) != 4
            or len(spec['case_ids']) != 2 or set(spec['case_ids']) != set(cases)
            or type(spec['seed']) is not int
            or protocol.get('attempt_budget') != {'required_admitted_cells': 40, 'technical_replacements': 4, 'max_process_attempts': 44}
            or protocol['recipe'] != {'warmup_s': 30, 'window_s': 60, 'timeout_s': 300}):
        raise ValueError('fixed_forty_run_design_or_recipe_changed')
    rng, expected = random.Random(spec['seed']), []
    for block in range(1, 6):
        order = [(case, variant) for case in spec['case_ids'] for variant in spec['variants']]
        rng.shuffle(order)
        expected.extend({'case_id': case, 'variant': variant, 'block': block} for case, variant in order)
    if spec['schedule'] != expected or spec['expected_runs'] != 40:
        raise ValueError('seeded_full_eight_cell_blocks_changed')


def freeze_time_ns(protocol):
    value = datetime.fromisoformat(protocol['frozen_at_utc'])
    if value.tzinfo is None:
        raise ValueError('protocol_freeze_time_requires_timezone')
    elapsed = value.astimezone(timezone.utc)-datetime(1970, 1, 1, tzinfo=timezone.utc)
    return (elapsed.days*86400+elapsed.seconds)*1_000_000_000+elapsed.microseconds*1000


def previous_study(path):
    prior, digest = read_json(path, PRIOR_REVIEW_SHA)
    if (prior.get('status') != 'PASS_final' or prior.get('protocol_sha256') != PRIOR_PROTOCOL_SHA
            or prior.get('progress_snapshot_sha256') != PRIOR_PROGRESS_SHA):
        raise ValueError('prior_study_identity_mismatch')
    cells = [r for r in prior['cells'] if r['included']]
    regnet = [r for r in cells if r['phase'] == 'primary']
    resnet = [r for r in cells if r['phase'] == 'replication']
    identities = {(r['pid'], r['started_time_ns']) for r in cells}
    if (len(cells) != 60 or len(regnet) != 40 or len(resnet) != 20 or len(identities) != 60
            or {r['model'] for r in regnet} != {'regnet_x_1_6gf'}
            or {r['model'] for r in resnet} != {'resnet50'}
            or {r['variant'] for r in resnet} != {'N_product', 'N_single'}):
        raise ValueError('prior_regnet40_and_native_resnet20_not_separate')
    description = {'source_sha256': digest, 'source_protocol_sha256': PRIOR_PROTOCOL_SHA,
                   'source_progress_sha256': PRIOR_PROGRESS_SHA, 'pooled_with_new_data': False,
                   'old_regnet_processes': 40, 'old_native_only_resnet_processes': 20,
                   'latest_old_finished_time_ns': max(r['finished_time_ns'] for r in cells),
                   'existing_estimates_read_without_recalculation': prior.get('summaries', [])}
    return identities, description


def paired_statistics(cells):
    if len(cells) != 40 or not all(r['included'] for r in cells):
        return [], []
    blocks, grouped = [], {}
    for block in range(1, 6):
        selected = [r for r in cells if r['block'] == block]
        if len(selected) != 8:
            raise ValueError('complete_eight_cell_block_required')
        rates = {(r['variant'], r['cut']): r['completed_task_fps'] for r in selected}
        logs = {v: math.log(rates[v, 'b095'])-math.log(rates[v, 'b002']) for v in VARIANTS}
        logs['generic_schedule_effect'] = logs['G_product']-logs['G_single']
        logs['native_schedule_effect'] = logs['N_product']-logs['N_single']
        logs['interaction'] = logs['native_schedule_effect']-logs['generic_schedule_effect']
        for name, value in logs.items():
            blocks.append({'cohort': 'new_resnet_full', 'block': block, 'contrast': name,
                           'log_ratio': value, 'ratio': math.exp(value)})
            grouped.setdefault(name, []).append(value)
    summaries = [{'cohort': 'new_resnet_full', 'contrast': name, **statistics_from_logs(values)}
                 for name, values in grouped.items()]
    if any(r['n_blocks'] != 5 or r['df'] != 4 for r in summaries):
        raise ValueError('exactly_five_block_df4_required')
    return blocks, summaries


def ratio_decision(row):
    point = row['mean_log']
    low, high = row['log_ci95_low'], row['log_ci95_high']
    return {'point_ratio': row['geometric_mean'],
            'point_preference': 'b095' if point > 0 else 'b002' if point < 0 else 'tie',
            'interval_relation_to_one': 'above' if low > 0 else 'below' if high < 0 else 'includes_one',
            'interval_includes_one': low <= 0 <= high}


def scientific_decision(summaries):
    if not summaries:
        return {'status': 'withheld_until_complete_fresh_forty', 'primary_interaction': None}
    rows = {r['contrast']: r for r in summaries}
    variants = {v: ratio_decision(rows[v]) for v in VARIANTS}
    g, n = variants['G_product'], variants['N_product']
    productive_reversal = g['point_preference'] != 'tie' and n['point_preference'] != 'tie' and g['point_preference'] != n['point_preference']
    supported_reversal = {g['interval_relation_to_one'], n['interval_relation_to_one']} == {'above', 'below'}
    interaction = rows['interaction']
    lo, hi, point = interaction['log_ci95_low'], interaction['log_ci95_high'], interaction['mean_log']
    support = 'same_direction_supported_nominally' if lo > 0 else 'opposite_direction_supported_nominally' if hi < 0 else 'inconclusive_interval_includes_one'
    return {'status': 'complete_fresh_forty', 'variant_cut_preferences': variants,
            'productive_point_preferences_differ': productive_reversal,
            'productive_opposite_preferences_supported_by_individual_nominal_intervals': supported_reversal,
            'primary_interaction': {'ratio': interaction['geometric_mean'], 'ci95_low': interaction['ci95_low'],
                'ci95_high': interaction['ci95_high'], 'point_direction_vs_regnet': 'same' if point > 0 else 'opposite' if point < 0 else 'null',
                'nominal_interval_support': support, 'regnet_direction_fixed_in_advance': 'interaction_above_one'},
            'distinctions': ['A point ranking reversal and uncertainty of each cut ratio are separate findings.',
                            'An interaction can exist without a productive point ranking reversal.',
                            'An interval including one is uncertainty, not proof of no interaction.',
                            'Interaction is a ratio of cut-ratio scheduling effects, not a per-cut throughput speedup.']}


def compare_published(summary, blocks, prefix, protocol_sha, progress_sha, analysis_sha=None):
    if prefix is None:
        return {'status': 'not_requested'}
    prefix = Path(prefix)
    report, _ = read_json(str(prefix)+'.json')
    if report.get('protocol_sha256') != protocol_sha or report.get('progress_sha256', report.get('progress_snapshot_sha256')) != progress_sha:
        raise ValueError('analyzer_protocol_or_snapshot_pin_mismatch')
    if analysis_sha is not None and report.get('analysis_source_sha256') != analysis_sha:
        raise ValueError('analyzer_code_pin_mismatch')
    count = 0
    with Path(str(prefix)+'_summaries.csv').open(newline='') as stream:
        csv_summaries = list(csv.DictReader(stream))
    with Path(str(prefix)+'_blocks.csv').open(newline='') as stream:
        csv_blocks = list(csv.DictReader(stream))
    # Both output representations are independently bound to raw-derived rows.
    # Agreement of the CSVs alone cannot validate the published JSON science.
    for representation, actual, actual_blocks in [('csv', csv_summaries, csv_blocks),
                                                   ('json', report.get('summaries'), report.get('blocks'))]:
        if not isinstance(actual, list) or len(actual) != len(summary):
            raise ValueError('analyzer_summary_row_count_mismatch:'+representation)
        for row in summary:
            matches = [r for r in actual if r['contrast'] == row['contrast']]
            if len(matches) != 1:
                raise ValueError('analyzer_contrast_key_missing_or_duplicated:'+representation)
            for field in ['n_blocks', 'mean_log', 'sd_log', 'se_log', 'df', 't95', 'log_ci95_low', 'log_ci95_high', 'geometric_mean', 'ci95_low', 'ci95_high']:
                if not near(matches[0][field], row[field]):
                    raise ValueError('analyzer_summary_mismatch:'+representation+':'+row['contrast']+':'+field)
                count += 1
            observed_null = matches[0].get('ci_includes_null')
            if observed_null != (str(row['ci_includes_null']) if representation == 'csv' else row['ci_includes_null']):
                raise ValueError('analyzer_null_inclusion_mismatch:'+representation)
        if not isinstance(actual_blocks, list) or len(actual_blocks) != len(blocks):
            raise ValueError('analyzer_block_row_count_mismatch:'+representation)
        for row in blocks:
            match = [r for r in actual_blocks if r['contrast'] == row['contrast'] and int(r['block']) == row['block']]
            if len(match) != 1 or not near(match[0]['log_ratio'], row['log_ratio']) or not near(match[0]['ratio'], row['ratio']):
                raise ValueError('analyzer_block_mismatch:'+representation)
            count += 2
    if summary:
        if report.get('status') != 'complete':
            raise ValueError('analyzer_completion_status_mismatch')
        own, published = scientific_decision(summary), report['decisions']
        if (own['productive_point_preferences_differ'] != published['productive_point_preferences_opposite']
                or own['productive_opposite_preferences_supported_by_individual_nominal_intervals'] !=
                published['productive_opposite_preferences_both_intervals_exclude_one']):
            raise ValueError('analyzer_productive_cut_decision_mismatch')
        for variant, decision in own['variant_cut_preferences'].items():
            direction = {'above': 'above_one', 'below': 'below_one', 'includes_one': 'includes_one'}[decision['interval_relation_to_one']]
            if (published['cut_preferences'][variant]['point_preferred_cut'] != decision['point_preference']
                    or published['cut_preferences'][variant]['interval_direction'] != direction):
                raise ValueError('analyzer_cutoff_one_decision_mismatch')
        for effect in ['generic_schedule_effect', 'native_schedule_effect']:
            row = next(r for r in summary if r['contrast'] == effect)
            expected = {'point_direction': 'above_one' if row['mean_log'] > 0 else 'below_one' if row['mean_log'] < 0 else 'equal_one',
                        'interval_direction': 'above_one' if row['log_ci95_low'] > 0 else 'below_one' if row['log_ci95_high'] < 0 else 'includes_one'}
            if published.get(effect) != expected:
                raise ValueError('analyzer_schedule_effect_decision_mismatch:'+effect)
        support = {'same_direction_supported_nominally': 'same_direction_above_one',
                   'opposite_direction_supported_nominally': 'opposite_direction_below_one',
                   'inconclusive_interval_includes_one': 'inconclusive_includes_one'}
        if (published['interaction_point_direction_relative_to_RegNet'] != own['primary_interaction']['point_direction_vs_regnet']
                or published['interaction_interval_direction_relative_to_RegNet'] != support[own['primary_interaction']['nominal_interval_support']]):
            raise ValueError('analyzer_interaction_decision_mismatch')
    return {'status': 'PASS', 'numeric_values_checked': count,
            'source_sha256': {suffix: hashlib.sha256(Path(str(prefix)+suffix).read_bytes()).hexdigest()
                              for suffix in ['.json', '_summaries.csv', '_blocks.csv']}}


def review(protocol_path, progress_path, *, root=None, previous_review=None, analysis_prefix=None):
    protocol_path, progress_path = Path(protocol_path).resolve(), Path(progress_path).resolve()
    root = Path(root).resolve() if root else protocol_path.parent
    if progress_path.name == 'PROGRESS.json':
        raise ValueError('immutable_phase_exit_snapshot_required')
    protocol, protocol_sha = read_json(protocol_path)
    progress, progress_sha = read_json(progress_path)
    if (progress.get('schema') != 'mechanism-progress-v1' or progress.get('protocol_sha256') != protocol_sha
            or progress.get('series_id') != protocol.get('series_id')
            or protocol.get('pilot_results_in_confirmatory_estimates') is not False):
        raise ValueError('new_snapshot_protocol_or_pilot_scope_mismatch')
    original = Path(protocol['device']['remote_root']).parent.name
    old_path = Path(previous_review).resolve() if previous_review else root/'input/reuse/old/mechanism_results_independent_review.json'
    old_identities, old_context = previous_study(old_path)
    frozen_ns = freeze_time_ns(protocol)
    if frozen_ns <= old_context['latest_old_finished_time_ns']:
        raise ValueError('new_protocol_does_not_postdate_completed_old_study')
    if len(progress['attempts']) > 44:
        raise ValueError('technical_replacement_attempt_budget_exceeded')
    cells, unknown = cells_from_reports(protocol, protocol_sha, progress, root, original)
    if unknown:
        raise ValueError('unregistered_or_old_attempt_in_new_forty')
    if any(e.get('status') == 'extension_trigger_verified' for e in progress.get('events', [])):
        raise ValueError('extension_not_permitted_in_new_study')
    for row in cells:
        for process in row['completed_attempt_processes']:
            if (process['pid'], process['started_time_ns']) in old_identities:
                row['errors'].append('old_worker_identity_reused')
            if type(process['started_time_ns']) is not int or process['started_time_ns'] <= frozen_ns:
                row['errors'].append('worker_not_fresh_after_new_protocol_freeze')
    pid_rows = {}
    for row in cells:
        if 'pid' in row:
            pid_rows.setdefault(row['pid'], []).append(row)
    for repeated in pid_rows.values():
        if len(repeated) > 1:
            for row in repeated:
                row['errors'].append('new_worker_pid_reused')
    for row in cells:
        row['included'] = not row['errors']
    blocks, summaries = paired_statistics(cells)
    complete = len(cells) == 40 and all(r['included'] for r in cells)
    report = {'schema': 'resnet-full-independent-review-v1', 'status': 'PASS_final' if complete else 'PENDING_no_forty_run_verdict',
              'protocol_sha256': protocol_sha, 'progress_snapshot_sha256': progress_sha,
              'progress_snapshot_path': str(progress_path), 'reviewer_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'independent_statistics': True, 'analyzer_imported_or_invoked': False, 'hardware_or_network': False,
              'student_t_method': 'incomplete_beta_CDF_bisection_independent_of_analyzer_t_table',
              'scheduled_new_processes': 40, 'admitted_new_processes': sum(r['included'] for r in cells),
              'completed_process_attempts': sum(len(r['completed_attempt_processes']) for r in cells),
              'distinct_new_worker_pids': len({r['pid'] for r in cells if r['included']}),
              'all_attempts_preserved': progress['attempts'], 'cells': cells, 'blocks': blocks, 'summaries': summaries,
              'previous_studies': old_context, 'previous_observations_pooled': False,
              'scientific_decision': scientific_decision(summaries),
              'limits': ['Selected ResNet cut pair, not a blind architecture selection or prevalence estimate.',
                         'Five paired blocks and nominal t95 intervals; no simultaneous coverage guarantee.',
                         'Whole runtime chains; no isolated copy/layout/conversion cause.',
                         'No new energy efficiency or total search-cost measurement.',
                         'Prepared fixed-input throughput and prior two-input checks do not prove general variable-input serving.',
                         'Current-code study does not reconstruct historical software or device conditions.']}
    report['analyzer_comparison'] = compare_published(summaries, blocks, analysis_prefix, protocol_sha, progress_sha,
                                                     protocol.get('analysis_source', {}).get('sha256'))
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--protocol', type=Path, required=True)
    parser.add_argument('--progress', type=Path, required=True)
    parser.add_argument('--root', type=Path)
    parser.add_argument('--previous-review', type=Path)
    parser.add_argument('--analysis-prefix', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = review(args.protocol, args.progress, root=args.root, previous_review=args.previous_review,
                    analysis_prefix=args.analysis_prefix)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False)+'\n')
    print(json.dumps({'status': result['status'], 'admitted_new_processes': result['admitted_new_processes'],
                      'protocol_sha256': result['protocol_sha256'], 'progress_snapshot_sha256': result['progress_snapshot_sha256']}))
    return 0 if result['status'] == 'PASS_final' else 2


if __name__ == '__main__':
    sys.exit(main())
