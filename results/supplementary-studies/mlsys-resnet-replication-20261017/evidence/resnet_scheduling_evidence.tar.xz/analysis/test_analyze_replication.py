#!/usr/bin/env python3
"""Focused offline tests of fresh-series admission, paired math and relocation."""
from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import tempfile
import unittest

SPEC = importlib.util.spec_from_file_location("replication_analysis", Path(__file__).with_name("analyze_replication.py"))
analysis = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(analysis)


def digest(text):
    return hashlib.sha256(text.encode()).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True, allow_nan=False)+"\n")
    return hashlib.sha256(path.read_bytes()).hexdigest()


class Fixture:
    def __init__(self, root):
        self.root = root
        self.task_name = "mlsys_r14_resnet_full_replication_20261017_sm2"
        self.remote = "/home/nx/Reports/"+self.task_name+"/replication_v1"
        self.spec = {"case_ids": list(analysis.CASES), "variants": list(analysis.VARIANTS),
                     "blocks": [1, 2, 3, 4, 5], "mode": "duration", "seed": 20261017, "expected_runs": 40}
        self.spec["schedule"] = analysis.frozen_schedule(self.spec)
        self.cases, self.configs = [], {}
        for case_id, cut in analysis.CASES.items():
            config = {"identity": {"model_id": "resnet50", "case_id": cut, "precision": "uint8_dequant_fp16",
                                   "output_endpoint_id": "classification:classification_logits:test"},
                      "task": "classification", "completion_contract": {"operation": "top1_top5"}, "queue_depth": 2,
                      "expected_runtime_artifacts": {"part1_runtime": {"path": "/artifacts/"+cut+".hef", "sha256": digest(cut+"hef")},
                                                     "engine": {"path": "/artifacts/"+cut+".engine", "sha256": digest(cut+"engine")}}}
            config_path = "input/"+case_id+".json"
            config_sha = save(root/config_path, config)
            args_path = "input/"+case_id+"_native_args.json"
            args_sha = save(root/args_path, ["--task", "classification"])
            runners = {chain: {"path": self.remote+"/"+chain+"/runner.py", "sha256": digest(chain)}
                       for chain in ("generic", "native")}
            case = {"case_id": case_id, "model_id": "resnet50", "cut": cut, "config_path": config_path,
                    "config_sha256": config_sha, "native_args_path": args_path, "native_args_sha256": args_sha,
                    "artifact_identity": config["expected_runtime_artifacts"], "runners": runners,
                    "required_sources": list(runners.values())}
            self.cases.append(case)
            self.configs[case_id] = config
        self.protocol = {"schema": "mechanism-controller-v1", "kind": analysis.KIND, "series_id": analysis.SERIES,
            "reuse_original_cells": False, "pilot_results_in_confirmatory_estimates": False,
            "attempt_budget": {"required_admitted_cells": 40, "technical_replacements": 4, "max_process_attempts": 44},
            "recipe": {"warmup_s": 30, "window_s": 60}, "phases": {"primary": self.spec}, "cases": self.cases,
            "profiles": {"sha256": digest("fixed profile")}, "adapter": {"sha256": digest("fixed adapter")},
            "analysis_source": {"path": "analysis/analyze_replication.py", "sha256": hashlib.sha256(Path(analysis.__file__).read_bytes()).hexdigest()},
            "device": {"remote_root": self.remote, "state_policy": {"affinity": [0, 1, 2, 3, 4, 5]}}}
        self.protocol_sha = save(root/"PROTOCOL.json", self.protocol)
        self.attempts = []
        for i, cell in enumerate(self.spec["schedule"]):
            case = next(c for c in self.cases if c["case_id"] == cell["case_id"])
            config = self.configs[cell["case_id"]]
            action = analysis.controller_action(self.protocol_sha, case, config, cell)
            chain, schedule = analysis.VARIANTS[cell["variant"]]
            count = 6000 if case["cut"] == "b002" else {"G_product": 4800, "N_product": 9000, "G_single": 6000, "N_single": 6000}[cell["variant"]]
            seconds = 60.0
            identity = {"protocol_sha256": self.protocol_sha, "identity": config["identity"],
                "artifact_identity": config["expected_runtime_artifacts"], "chain": chain,
                "schedule": schedule, "block": cell["block"], "mode": "duration"}
            raw = {**identity, "run_id": analysis.canonical(identity), "schema": "mechanism-product-workers-v1",
                "status": "complete", "adapter_sha256": self.protocol["adapter"]["sha256"], "config_sha256": case["config_sha256"],
                "product_runner_sha256": case["runners"][chain]["sha256"], "product_runner": case["runners"][chain]["path"],
                "loaded_source_hashes": {case["runners"][chain]["path"]: case["runners"][chain]["sha256"]},
                "diagnostic_adapter": True, "energy_measured": False, "accepted_work_drained": True,
                "warmup_duration_s": 30, "admission_window_seconds": 60,
                "worker_cpu_affinity": self.protocol["device"]["state_policy"]["affinity"],
                "schedule_description": "unchanged_product_parallelism" if schedule == "product" else
                    "one_global_outstanding_task_until_classification_tail_complete",
                "completed_work_units": count, "measurement_time_seconds": seconds, "completed_task_fps": count/seconds,
                "warmup_completed_count": 3000,
                "pid": 1000+i, "started_time_ns": 1_000_000_000_000_000_000+i*100_000_000_000,
                "finished_time_ns": 1_000_000_090_000_000_000+i*100_000_000_000}
            if chain == "generic":
                start = 1_000_000_000_000+i*100_000_000_000
                raw["metrics"] = {"fill_and_drain_included": True, "postprocess_timed": True, "output_materialization_timed": True,
                    "accepted_work_drained": True, "admission_stopped_at_deadline": True, "completed_task_count": count,
                    "processor_count_delta": count, "admitted_task_count": count, "completed_work_units": count,
                    "measured_makespan_seconds": seconds, "warmup_end_ns": start-1, "measurement_start_ns": start,
                    "admission_deadline_ns": start+60_000_000_000, "admission_stopped_ns": start+60_000_000_000,
                    "measurement_end_ns": start+60_000_000_000, "worker_count": 2, "queue_depth": 2}
            else:
                raw["metrics"] = {"task_complete": True, "postprocess_included": True, "postprocess_completion_verified": True,
                    "trt_copy_outputs": True, "completed_task_stage": "classification_top1_top5", "measurement_endpoint": "completed_task",
                    "last_completion_source": "current_output_top1_top5", "warmup_contract": "fully_drained_before_worker_start",
                    "produced_frames": count, "consumed_frames": count, "completed_frames": count, "completed_work_units": count,
                    "postprocess_completed_frames": count, "makespan_ms": seconds*1000,
                    "inflight": 1 if schedule == "single" else 8, "queue_depth": 3}
            report_path = "raw/"+action["run_id"]+".json"
            report_sha = save(root/report_path, raw)
            before, after = "states/"+str(i)+"_before.json", "states/"+str(i)+"_after.json"
            save(root/before, {"identity": "synthetic before"});save(root/after, {"identity": "synthetic after"})
            self.attempts.append({**action, "attempt_id": action["run_id"]+"_attempt01", "status": "completed", "included": True,
                "returncode": 0, "before_state_check": {"comparable": True, "reasons": []}, "state_check": {"comparable": True, "reasons": []},
                "before_snapshot": before, "after_snapshot": after, "report_path": report_path, "report_sha256": report_sha})
        self.save_progress()

    def save_progress(self):
        save(self.root/"receipts/final_snapshot.json", {"schema": "mechanism-progress-v1", "series_id": analysis.SERIES,
             "protocol_sha256": self.protocol_sha, "attempts": self.attempts, "events": []})

    def mutate_raw(self, index, function, *, update_seal=True):
        attempt = self.attempts[index]
        path = self.root/attempt["report_path"]
        raw = json.loads(path.read_text());function(raw)
        actual = save(path, raw)
        if update_seal:attempt["report_sha256"] = actual
        self.save_progress()

    def analyze(self, **kwargs):
        self.save_progress()
        return analysis.analyze(self.root/"PROTOCOL.json", self.root/"receipts/final_snapshot.json", root=self.root, **kwargs)


class ReplicationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="new-resnet-analysis-test-")
        self.root = Path(self.temp.name)
        self.fixture = Fixture(self.root)

    def tearDown(self):
        self.temp.cleanup()

    def assert_invalid(self, result):
        self.assertEqual(result["status"], "invalid")
        self.assertEqual(result["summaries"], [])
        self.assertIsNone(result["decisions"])

    def test_full_fresh_series_has_seven_correct_paired_contrasts(self):
        result = self.fixture.analyze()
        self.assertEqual((result["status"], result["admitted_cells"], result["distinct_worker_pids"]), ("complete", 40, 40))
        self.assertEqual(len(result["blocks"]), 35)
        expected = {"G_product": .8, "N_product": 1.5, "G_single": 1, "N_single": 1,
                    "generic_schedule_effect": .8, "native_schedule_effect": 1.5, "interaction": 1.875}
        for summary in result["summaries"]:
            self.assertEqual(summary["n_blocks"], 5)
            self.assertAlmostEqual(summary["geometric_mean"], expected[summary["contrast"]], places=12)
        self.assertTrue(result["decisions"]["productive_point_preferences_opposite"])
        self.assertEqual(result["decisions"]["interaction_interval_direction_relative_to_RegNet"], "same_direction_above_one")

    def test_sample_log_interval_uses_five_blocks_and_sample_sd(self):
        values = [-.4, -.1, .2, .25, .8]
        result = analysis.summarize_logs(values)
        mean = sum(values)/5
        sd = math.sqrt(sum((x-mean)**2 for x in values)/4)
        self.assertAlmostEqual(result["se_log"], sd/math.sqrt(5), places=15)
        self.assertAlmostEqual(result["ci95_high"], math.exp(mean+2.7764451051977987*sd/math.sqrt(5)), places=14)
        with self.assertRaises(ValueError):analysis.summarize_logs(values[:4])

    def test_missing_cell_has_no_summary_and_no_zero_fill(self):
        self.fixture.attempts.pop()
        result = self.fixture.analyze()
        self.assertEqual(result["status"], "incomplete")
        self.assertEqual(result["summaries"], [])
        self.assertEqual(sum(row["ratio"] is None for row in result["blocks"]), 7)
        self.assertIsNone(result["cells"][-1]["completed_task_fps"])

    def test_duplicate_completed_attempt_is_not_an_extra_replicate(self):
        self.fixture.attempts.insert(1, copy.deepcopy(self.fixture.attempts[0]))
        self.assert_invalid(self.fixture.analyze())

    def test_foreign_old_cell_never_pools(self):
        self.fixture.attempts.append({"run_id": "old_native_cell", "phase": "replication", "status": "completed"})
        self.assert_invalid(self.fixture.analyze())

    def test_wrong_journal_protocol_or_series_rejected(self):
        path = self.root/"receipts/final_snapshot.json"
        for key, value in [("series_id", "old_series"), ("protocol_sha256", "0"*64)]:
            self.fixture.save_progress();progress = json.loads(path.read_text());progress[key] = value;save(path, progress)
            with self.assertRaises(ValueError):analysis.analyze(self.root/"PROTOCOL.json", path, root=self.root)

    def test_raw_hash_and_runtime_identity_mismatches_rejected(self):
        self.fixture.mutate_raw(0, lambda raw: raw.update(completed_task_fps=999), update_seal=False)
        self.assert_invalid(self.fixture.analyze())

    def test_wrong_loaded_source_rejected_even_with_updated_report_seal(self):
        self.fixture.mutate_raw(0, lambda raw: raw.update(loaded_source_hashes={"foreign.py": "0"*64}))
        self.assert_invalid(self.fixture.analyze())

    def test_core_window_denominator_cannot_replace_full_drain_time(self):
        self.fixture.mutate_raw(0, lambda raw: raw.update(measurement_time_seconds=61, completed_task_fps=raw["completed_work_units"]/60))
        self.assert_invalid(self.fixture.analyze())

    def test_actual_warmup_completion_and_outer_duration_are_required(self):
        self.fixture.mutate_raw(0, lambda raw: raw.update(warmup_completed_count=0))
        self.assert_invalid(self.fixture.analyze())
        self.fixture.mutate_raw(0, lambda raw: raw.update(warmup_completed_count=3000,
            finished_time_ns=raw["started_time_ns"]+75_000_000_000))
        self.assert_invalid(self.fixture.analyze())

    def test_endpoint_and_global_single_policy_are_required(self):
        index = next(i for i,a in enumerate(self.fixture.attempts) if a["variant"] == "N_single")
        self.fixture.mutate_raw(index, lambda raw: raw["metrics"].update(inflight=8))
        self.assert_invalid(self.fixture.analyze())

    def test_reordered_or_overlapping_processes_rejected(self):
        self.fixture.attempts[0],self.fixture.attempts[1] = self.fixture.attempts[1],self.fixture.attempts[0]
        self.assert_invalid(self.fixture.analyze())

    def test_duplicate_pid_rejected(self):
        self.fixture.mutate_raw(1, lambda raw: raw.update(pid=1000))
        self.assert_invalid(self.fixture.analyze())

    def test_corrected_immediate_failed_retry_retains_history(self):
        failed = copy.deepcopy(self.fixture.attempts[0]);failed.update(status="failed", included=False, returncode=1, reason="transport collection failed")
        success = self.fixture.attempts[0];success["attempt_id"] = success["run_id"]+"_attempt02"
        success["retry_cause"] = {"run_id": success["run_id"], "protocol_sha256": self.fixture.protocol_sha,
            "cause_corrected": True, "reason": "transport restored", "technical_error": "transport"}
        self.fixture.attempts.insert(0, failed)
        result = self.fixture.analyze()
        self.assertEqual((result["status"], result["attempt_count"], result["admitted_cells"]), ("complete", 41, 40))
        self.assertEqual(result["attempts"][0]["status"], "failed")

    def test_uncorrected_retry_rejected(self):
        failed = copy.deepcopy(self.fixture.attempts[0]);failed.update(status="failed", included=False)
        self.fixture.attempts[0]["attempt_id"] = failed["run_id"]+"_attempt02"
        self.fixture.attempts.insert(0, failed)
        self.assert_invalid(self.fixture.analyze())

    def technical_state_replacement(self):
        excluded = copy.deepcopy(self.fixture.attempts[0])
        excluded.update(included=False, state_check={"comparable": False, "reasons": ["fixed_end_state_outside_policy"]})
        replacement = self.fixture.attempts[0]
        replacement["attempt_id"] = replacement["run_id"]+"_attempt02"
        replacement["retry_cause"] = {"run_id": replacement["run_id"], "protocol_sha256": self.fixture.protocol_sha,
            "cause_corrected": True, "reason": "Fixed state restored to preregistered range after rest",
            "technical_error": "state_policy", "previous_state_reasons": excluded["state_check"]["reasons"]}
        raw = json.loads((self.root/replacement["report_path"]).read_text())
        raw.update(pid=9000, started_time_ns=raw["started_time_ns"]+91_000_000_000,
                   finished_time_ns=raw["finished_time_ns"]+91_000_000_000)
        replacement["report_path"] = "raw/replacement02.json"
        replacement["report_sha256"] = save(self.root/replacement["report_path"], raw)
        # Keep all later cells chronologically after the extra completed process.
        for i in range(1, len(self.fixture.attempts)):
            self.fixture.mutate_raw(i, lambda r:r.update(started_time_ns=r["started_time_ns"]+100_000_000_000,
                                                        finished_time_ns=r["finished_time_ns"]+100_000_000_000))
        self.fixture.attempts.insert(0, excluded)

    def test_explicit_corrected_technical_state_replacement_preserves_excluded_raw(self):
        self.technical_state_replacement()
        result = self.fixture.analyze()
        self.assertEqual((result["status"], result["admitted_cells"], result["attempt_count"]), ("complete", 40, 41))
        self.assertEqual((result["distinct_worker_pids"], result["all_completed_attempt_worker_pids"]), (40, 41))
        self.assertEqual(result["attempts"][0]["admission"], "technical_state_excluded")
        self.assertIn(result["attempts"][0]["report_path"], result["source_sha256"])
        self.assertNotEqual(result["attempts"][0]["report_path"], result["cells"][0]["report_path"])

    def test_state_retry_must_reproduce_exact_old_technical_reasons(self):
        self.technical_state_replacement()
        self.fixture.attempts[1]["retry_cause"]["previous_state_reasons"] = ["invented reason"]
        self.assert_invalid(self.fixture.analyze())

    def test_invalid_raw_of_excluded_attempt_stays_fatal_after_replacement(self):
        self.technical_state_replacement()
        self.fixture.mutate_raw(0, lambda raw:raw.update(adapter_sha256="0"*64))
        self.assert_invalid(self.fixture.analyze())

    def test_total_attempt_cap_is_four_technical_replacements(self):
        # Five explicitly corrected launcher failures still exceed the sealed cap.
        success = self.fixture.attempts[0]
        corrected = {"run_id": success["run_id"], "protocol_sha256": self.fixture.protocol_sha,
                     "cause_corrected": True, "reason": "launcher restored", "technical_error": "launcher"}
        failures = []
        for i in range(1, 6):
            failed = copy.deepcopy(success)
            failed["attempt_id"] = success["run_id"]+f"_attempt{i:02d}"
            failed.update(status="failed", included=False, returncode=1, reason="launcher failed")
            if i > 1:failed["retry_cause"] = copy.deepcopy(corrected)
            failures.append(failed)
        success["attempt_id"] = success["run_id"]+"_attempt06"
        success["retry_cause"] = corrected
        self.fixture.attempts = failures+self.fixture.attempts
        result = self.fixture.analyze()
        self.assert_invalid(result)
        self.assertTrue(any("44_process_attempt_cap" in error["error"] for error in result["audit_errors"]))

    def test_interval_crossing_one_does_not_erase_point_reversal(self):
        summaries = []
        for name in analysis.CONTRASTS:
            values = [-1, -.5, .1, .3, .8] if name == "G_product" else [-.2, .1, .3, .4, .5]
            summaries.append({"contrast": name, **analysis.summarize_logs(values)})
        result = analysis.decisions(summaries)
        self.assertTrue(result["productive_point_preferences_opposite"])
        self.assertFalse(result["productive_opposite_preferences_both_intervals_exclude_one"])
        self.assertEqual(result["interaction_interval_direction_relative_to_RegNet"], "inconclusive_includes_one")

    def test_historical_manifest_is_sealed_but_never_read_as_observations(self):
        save(self.root/"input/historical.json", {"old_cells": [999999]*20, "source": "documentary only"})
        before = self.fixture.analyze()
        after = self.fixture.analyze(historical_manifest="input/historical.json")
        self.assertEqual(before["summaries"], after["summaries"])
        self.assertFalse(after["historical_reference"]["included_in_statistics"])
        self.assertEqual(after["historical_reference"]["old_cells_reused"], 0)

    def test_absolute_new_task_paths_relocate_but_old_task_paths_reject(self):
        self.fixture.attempts[0]["report_path"] = "/home/kmika/Reports/"+self.fixture.task_name+"/"+self.fixture.attempts[0]["report_path"]
        self.assertEqual(self.fixture.analyze()["status"], "complete")
        with self.assertRaises(ValueError):analysis.task_path(self.root,
            "/home/kmika/Reports/mlsys_r14_evidence_mechanism_20261017_sm2/raw/cell.json", self.fixture.task_name)

    def test_current_mutable_progress_name_rejected(self):
        self.fixture.save_progress();shutil.copyfile(self.root/"receipts/final_snapshot.json", self.root/"PROGRESS.json")
        with self.assertRaises(ValueError):analysis.analyze(self.root/"PROTOCOL.json", self.root/"PROGRESS.json", root=self.root)

    def test_analysis_source_change_after_freeze_rejected(self):
        self.fixture.protocol["analysis_source"]["sha256"] = "0"*64;save(self.root/"PROTOCOL.json", self.fixture.protocol)
        with self.assertRaisesRegex(ValueError, "analysis_source_differs"):self.fixture.analyze()

    def test_cli_relocated_package_uses_only_stdlib_and_reproduces_tables(self):
        target = self.root/"analysis/analyze_replication.py";target.parent.mkdir();shutil.copyfile(analysis.__file__, target)
        self.fixture.save_progress()
        process = subprocess.run([sys.executable,"-I",str(target),"--root",str(self.root),"--progress-snapshot","receipts/final_snapshot.json"],
                                 text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        self.assertEqual(process.returncode, 0, process.stderr)
        result = json.loads((self.root/"results/replication_analysis.json").read_text())
        self.assertEqual(result["status"], "complete")
        self.assertEqual(result["admitted_cells"], 40)
        self.assertTrue((self.root/"results/replication_analysis_blocks.csv").is_file())


if __name__ == "__main__":
    unittest.main()
