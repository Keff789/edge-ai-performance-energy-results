#!/usr/bin/env python3
"""Offline analysis of the separate, fresh 40-process ResNet replication.

Only five complete eight-cell blocks from the exact new protocol enter inference.
No hardware, runtime, third-party numerical package or historical observation is
loaded. An incomplete/invalid ledger produces diagnostics and no summaries.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path
import random
import re
import statistics


SERIES = "resnet_full_replication_v1"
KIND = "resnet-full-replication"
VARIANTS = {"G_product": ("generic", "product"), "N_product": ("native", "product"),
            "G_single": ("generic", "single"), "N_single": ("native", "single")}
CASES = {"resnet_b002": "b002", "resnet_b095": "b095"}
BLOCKS = [1, 2, 3, 4, 5]
CONTRASTS = [*VARIANTS, "generic_schedule_effect", "native_schedule_effect", "interaction"]
T95_DF4 = 2.7764451051977987
SHA = re.compile(r"[a-f0-9]{64}\Z")
METHOD = "mean_log_plus_minus_t95_df4_times_sample_sd_log_over_sqrt5"


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     allow_nan=False).encode()).hexdigest()


def read_json(path, expected=None):
    data = Path(path).read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    if expected is not None and (not isinstance(expected, str) or not SHA.fullmatch(expected)
                                 or digest != expected):
        raise ValueError("source_hash_mismatch:" + str(path))
    return json.loads(data), digest


def require(condition, message):
    if not condition:
        raise ValueError(message)


def task_path(root, value, original_name):
    """Relocate only this exact task's known local/remote report prefixes."""
    root, path = Path(root).resolve(), Path(value)
    if path.is_absolute() and not path.is_relative_to(root):
        prefixes = [Path(home)/"Reports"/original_name for home in ("/home/kmika", "/home/nx")]
        found = [prefix for prefix in prefixes if path.is_relative_to(prefix)]
        require(len(found) == 1, "path_outside_exact_new_series:" + str(value))
        path = root/path.relative_to(found[0])
    elif not path.is_absolute():
        path = root/path
    path = path.resolve()
    require(path.is_relative_to(root), "path_escapes_new_series:" + str(value))
    return path


def frozen_schedule(spec):
    rng, result = random.Random(spec["seed"]), []
    for block in BLOCKS:
        cells = [(case, variant) for case in spec["case_ids"] for variant in spec["variants"]]
        rng.shuffle(cells)
        result.extend({"case_id": case, "variant": variant, "block": block} for case, variant in cells)
    return result


def validate_protocol(protocol):
    require(protocol.get("schema") == "mechanism-controller-v1", "wrong_protocol_schema")
    require(protocol.get("series_id") == SERIES and protocol.get("kind") == KIND,
            "not_the_separate_full_resnet_replication")
    require(protocol.get("reuse_original_cells") is False and
            protocol.get("pilot_results_in_confirmatory_estimates") is False, "old_or_pilot_pooling_not_forbidden")
    require(protocol.get("attempt_budget") == {"required_admitted_cells": 40, "technical_replacements": 4,
            "max_process_attempts": 44}, "prefrozen_forty_cell_four_technical_replacement_budget_required")
    require(set(protocol.get("phases", {})) == {"primary"}, "exactly_one_new_primary_phase_required")
    require(protocol.get("recipe", {}).get("warmup_s") == 30 and
            protocol["recipe"].get("window_s") == 60, "measurement_recipe_drift")
    spec = protocol["phases"]["primary"]
    require(spec.get("case_ids") == list(CASES) and spec.get("variants") == list(VARIANTS) and
            spec.get("blocks") == BLOCKS and spec.get("mode") == "duration" and
            type(spec.get("seed")) is int and spec.get("expected_runs") == 40,
            "fixed_two_cut_four_variant_five_block_design_drift")
    require(spec.get("schedule") == frozen_schedule(spec), "joint_seeded_eight_cell_schedule_drift")
    cases = {case["case_id"]: case for case in protocol["cases"]}
    require(len(cases) == len(protocol["cases"]) == 2 and set(cases) == set(CASES), "duplicate_or_foreign_case")
    for case_id, case in cases.items():
        require(case.get("model_id") == "resnet50" and case.get("cut") == CASES[case_id], "wrong_model_or_cut")
        for field in ("config_sha256", "native_args_sha256"):
            require(isinstance(case.get(field), str) and SHA.fullmatch(case[field]), "invalid_case_seal:" + field)
        sources = case.get("required_sources", [])
        require(bool(sources) and len({s["path"] for s in sources}) == len(sources) and
                all(isinstance(s.get("sha256"), str) and SHA.fullmatch(s["sha256"]) for s in sources),
                "missing_duplicate_or_invalid_frozen_sources")
    require(isinstance(protocol.get("profiles", {}).get("sha256"), str) and
            SHA.fullmatch(protocol["profiles"]["sha256"]), "profile_seal_missing")
    require(isinstance(protocol.get("adapter", {}).get("sha256"), str) and
            SHA.fullmatch(protocol["adapter"]["sha256"]), "adapter_seal_missing")
    remote = Path(protocol["device"]["remote_root"])
    require(remote.is_relative_to("/home/nx/Reports") and remote.parent.name !=
            "mlsys_r14_evidence_mechanism_20261017_sm2", "old_or_unknown_remote_series_root")
    return cases, remote.parent.name


def controller_action(protocol_sha, case, config, cell):
    identity = {"protocol_sha256": protocol_sha, "artifact_identity": config["expected_runtime_artifacts"],
                "case_id": case["case_id"], "cut": case["cut"], "variant": cell["variant"],
                "block": cell["block"], "phase": "primary", "mode": "duration"}
    return {**identity, "run_id": canonical(identity)}


def finite_positive(value):
    return type(value) in (int, float) and math.isfinite(value) and value > 0


def close(first, second):
    return finite_positive(first) and finite_positive(second) and math.isclose(first, second, rel_tol=1e-9, abs_tol=1e-12)


def validate_raw(protocol, protocol_sha, case, config, action, raw):
    chain, schedule = VARIANTS[action["variant"]]
    identity = {"protocol_sha256": protocol_sha, "identity": config["identity"],
                "artifact_identity": config["expected_runtime_artifacts"], "chain": chain,
                "schedule": schedule, "block": action["block"], "mode": "duration"}
    expected = {**identity, "run_id": canonical(identity), "schema": "mechanism-product-workers-v1",
        "status": "complete", "adapter_sha256": protocol["adapter"]["sha256"],
        "config_sha256": case["config_sha256"], "product_runner_sha256": case["runners"][chain]["sha256"],
        "product_runner": case["runners"][chain]["path"],
        "diagnostic_adapter": True, "energy_measured": False, "accepted_work_drained": True,
        "warmup_duration_s": 30, "admission_window_seconds": 60,
        "worker_cpu_affinity": protocol["device"]["state_policy"]["affinity"],
        "schedule_description": ("unchanged_product_parallelism" if schedule == "product" else
            "one_global_outstanding_task_until_classification_tail_complete")}
    for key, value in expected.items():
        require(raw.get(key) is value if type(value) is bool else raw.get(key) == value,
                "raw_identity_or_contract_mismatch:" + key)
    loaded, allowed = raw.get("loaded_source_hashes"), {s["path"]: s["sha256"] for s in case["required_sources"]}
    require(isinstance(loaded, dict) and bool(loaded) and all(allowed.get(path) == value and
            isinstance(value, str) and SHA.fullmatch(value) for path, value in loaded.items()), "raw_loaded_source_not_frozen")
    count, seconds, reported = (raw.get(key) for key in
        ("completed_work_units", "measurement_time_seconds", "completed_task_fps"))
    require(type(count) is int and count > 0 and finite_positive(seconds) and seconds >= 60 and
            close(reported, count/seconds), "raw_full_makespan_throughput_invalid")
    require(type(raw.get("warmup_completed_count")) is int and raw["warmup_completed_count"] > 0,
            "raw_positive_completed_warmup_count_missing")
    require(type(raw.get("pid")) is int and raw["pid"] > 0 and
            type(raw.get("started_time_ns")) is int and type(raw.get("finished_time_ns")) is int and
            raw["finished_time_ns"] > raw["started_time_ns"] > 0 and
            (raw["finished_time_ns"]-raw["started_time_ns"])/1e9+0.001 >= 30+seconds,
            "raw_process_identity_or_time_invalid")
    metrics = raw["metrics"]
    if chain == "generic":
        require(all(metrics.get(key) is True for key in ("fill_and_drain_included", "postprocess_timed",
                "output_materialization_timed", "accepted_work_drained", "admission_stopped_at_deadline")),
                "generic_complete_task_endpoint_or_drain_missing")
        require(all(metrics.get(key) == count for key in ("completed_task_count", "processor_count_delta",
                "admitted_task_count", "completed_work_units")) and
                close(metrics.get("measured_makespan_seconds"), seconds), "generic_completion_counter_or_time_mismatch")
        clocks = [metrics.get(key) for key in ("warmup_end_ns", "measurement_start_ns", "admission_deadline_ns",
                  "admission_stopped_ns", "measurement_end_ns")]
        require(all(type(value) is int and value > 0 for value in clocks) and
                clocks[0] <= clocks[1] < clocks[2] <= clocks[3] <= clocks[4] and
                clocks[2]-clocks[1] == 60_000_000_000 and close((clocks[4]-clocks[1])/1e9, seconds),
                "generic_measurement_boundaries_invalid")
        require(metrics.get("worker_count") == 2 and metrics.get("queue_depth") == config["queue_depth"],
                "generic_product_policy_drift")
    else:
        require(all(metrics.get(key) is True for key in ("task_complete", "postprocess_included",
                "postprocess_completion_verified", "trt_copy_outputs")) and
                metrics.get("completed_task_stage") == "classification_top1_top5" and
                metrics.get("measurement_endpoint") == "completed_task" and
                metrics.get("last_completion_source") == "current_output_top1_top5" and
                metrics.get("warmup_contract") == "fully_drained_before_worker_start", "native_complete_task_endpoint_missing")
        require(all(metrics.get(key) == count for key in ("produced_frames", "consumed_frames", "completed_frames",
                "completed_work_units", "postprocess_completed_frames")) and
                close(metrics.get("makespan_ms"), seconds*1000), "native_completion_counter_or_time_mismatch")
        require(metrics.get("inflight") == (1 if schedule == "single" else 8) and metrics.get("queue_depth") == 3,
                "native_product_or_single_policy_drift")
    return {"completed_work_units": count, "measurement_time_seconds": seconds,
            "completed_task_fps": count/seconds, "reported_completed_task_fps": reported,
            "worker_pid": raw["pid"], "started_time_ns": raw["started_time_ns"],
            "finished_time_ns": raw["finished_time_ns"]}


def summarize_logs(values):
    require(len(values) == 5 and all(type(x) in (int, float) and math.isfinite(x) for x in values),
            "exactly_five_finite_whole_block_log_contrasts_required")
    mean, sd = statistics.mean(values), statistics.stdev(values)
    se = sd/math.sqrt(5)
    low, high = mean-T95_DF4*se, mean+T95_DF4*se
    return {"n_blocks": 5, "mean_log": mean, "sd_log": sd, "se_log": se, "df": 4, "t95": T95_DF4,
            "log_ci95_low": low, "log_ci95_high": high, "geometric_mean": math.exp(mean),
            "ci95_low": math.exp(low), "ci95_high": math.exp(high), "ci_includes_null": low <= 0 <= high}


def block_contrasts(cells):
    result = []
    for block in BLOCKS:
        selected = [r for r in cells if r["block"] == block]
        whole = len(selected) == 8 and all(r["included"] for r in selected)
        values = {}
        if whole:
            rates = {(r["cut"], r["variant"]): r["completed_task_fps"] for r in selected}
            values = {variant: math.log(rates["b095", variant]/rates["b002", variant]) for variant in VARIANTS}
            values["generic_schedule_effect"] = values["G_product"]-values["G_single"]
            values["native_schedule_effect"] = values["N_product"]-values["N_single"]
            values["interaction"] = values["native_schedule_effect"]-values["generic_schedule_effect"]
        for contrast in CONTRASTS:
            value = values.get(contrast)
            result.append({"series_id": SERIES, "model": "resnet50", "block": block, "contrast": contrast,
                "numerator_cut": "b095", "denominator_cut": "b002", "whole_block_included": whole,
                "admitted_cells": sum(r["included"] for r in selected), "expected_cells": 8,
                "log_ratio": value, "ratio": math.exp(value) if value is not None else None})
    return result


def decisions(summaries):
    by_name = {r["contrast"]: r for r in summaries}
    def direction(row, interval=False):
        if interval:
            return "above_one" if row["log_ci95_low"] > 0 else "below_one" if row["log_ci95_high"] < 0 else "includes_one"
        return "above_one" if row["mean_log"] > 0 else "below_one" if row["mean_log"] < 0 else "equal_one"
    preferences = {variant: {"point_preferred_cut": "b095" if by_name[variant]["mean_log"] > 0 else
                    "b002" if by_name[variant]["mean_log"] < 0 else "tie",
                    "interval_direction": direction(by_name[variant], True)} for variant in VARIANTS}
    productive = [by_name[v] for v in ("G_product", "N_product")]
    interaction = by_name["interaction"]
    return {"cut_preferences": preferences,
        "productive_point_preferences_opposite": productive[0]["mean_log"]*productive[1]["mean_log"] < 0,
        "productive_opposite_preferences_both_intervals_exclude_one":
            {direction(row, True) for row in productive} == {"above_one", "below_one"},
        "generic_schedule_effect": {"point_direction": direction(by_name["generic_schedule_effect"]),
                                    "interval_direction": direction(by_name["generic_schedule_effect"], True)},
        "native_schedule_effect": {"point_direction": direction(by_name["native_schedule_effect"]),
                                   "interval_direction": direction(by_name["native_schedule_effect"], True)},
        "interaction_point_direction_relative_to_RegNet": "same" if interaction["mean_log"] > 0 else
            "opposite" if interaction["mean_log"] < 0 else "null",
        "interaction_interval_direction_relative_to_RegNet": "same_direction_above_one" if interaction["log_ci95_low"] > 0
            else "opposite_direction_below_one" if interaction["log_ci95_high"] < 0 else "inconclusive_includes_one",
        "selected_pair_scope": "ResNet was selected for a known rank reversal. This is a separate randomized replication for this selected pair, not prevalence evidence.",
        "interaction_is_not_per_cut_speedup": True}


def analyze(protocol_path, progress_path, *, root, historical_manifest=None):
    root = Path(root).resolve()
    protocol_path, progress_path = Path(protocol_path).resolve(), Path(progress_path).resolve()
    require(protocol_path.is_relative_to(root) and progress_path.is_relative_to(root), "inputs_must_be_inside_new_series")
    require(progress_path.name != "PROGRESS.json", "explicit_immutable_progress_snapshot_required")
    protocol, protocol_sha = read_json(protocol_path)
    cases, original = validate_protocol(protocol)
    analyzer_sha = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    require(protocol.get("analysis_source", {}).get("sha256") == analyzer_sha,
            "analysis_source_differs_from_prefrozen_protocol")
    progress, progress_sha = read_json(progress_path)
    require(progress.get("schema") == "mechanism-progress-v1" and progress.get("protocol_sha256") == protocol_sha and
            progress.get("series_id") == SERIES and isinstance(progress.get("attempts"), list), "journal_series_or_protocol_mismatch")
    sources = {protocol_path.relative_to(root).as_posix(): protocol_sha,
               progress_path.relative_to(root).as_posix(): progress_sha}
    configs = {}
    for key, case in cases.items():
        path = task_path(root, case["config_path"], original)
        config, digest = read_json(path, case["config_sha256"])
        require(config["identity"]["model_id"] == "resnet50" and config["identity"]["case_id"] == case["cut"] and
                config.get("task") == "classification" and config.get("completion_contract", {}).get("operation") == "top1_top5",
                "configuration_model_or_endpoint_mismatch")
        require(case.get("artifact_identity") == config["expected_runtime_artifacts"], "configuration_artifact_binding_mismatch")
        sources[path.relative_to(root).as_posix()] = digest
        args_path = task_path(root, case["native_args_path"], original)
        _, args_digest = read_json(args_path, case["native_args_sha256"])
        sources[args_path.relative_to(root).as_posix()] = args_digest
        configs[key] = config
    actions = [controller_action(protocol_sha, cases[cell["case_id"]], configs[cell["case_id"]], cell)
               for cell in protocol["phases"]["primary"]["schedule"]]
    by_id = {action["run_id"]: (i, action) for i, action in enumerate(actions)}
    require(len(by_id) == 40, "duplicate_registered_cell")
    attempts, failures, rows, seen_first, grouped = progress["attempts"], [], [], [], {}
    if len(attempts) > protocol["attempt_budget"]["max_process_attempts"]:
        failures.append({"error": "prefrozen_44_process_attempt_cap_exceeded"})
    pids, last_raw_finish, prior_run = set(), None, None
    for index, attempt in enumerate(attempts):
        row = {"progress_index": index, "attempt_id": attempt.get("attempt_id"), "run_id": attempt.get("run_id"),
               "status": attempt.get("status"), "included_recorded": attempt.get("included"),
               "retry_cause": attempt.get("retry_cause"), "reason": attempt.get("reason"),
               "recorded_report_path": attempt.get("report_path"), "recorded_report_sha256": attempt.get("report_sha256"),
               "errors": []}
        rows.append(row)
        try:
            require(attempt.get("run_id") in by_id, "foreign_or_historical_attempt")
            order, action = by_id[attempt["run_id"]]
            history = grouped.setdefault(attempt["run_id"], [])
            if not history:
                seen_first.append(order)
            require(all(attempt.get(key) == value for key, value in action.items()), "attempt_action_identity_mismatch")
            require(attempt.get("attempt_id") == action["run_id"]+f"_attempt{len(history)+1:02d}", "duplicate_or_nonsequential_attempt")
            if history:
                cause = attempt.get("retry_cause") or {}
                previous = history[-1][1]
                previous_review = rows[history[-1][0]]
                failed_retry = (previous.get("status") == "failed" and
                    cause.get("technical_error") in {"launcher", "transport", "implementation"})
                state_retry = (previous.get("status") == "completed" and previous.get("included") is False and
                    previous_review.get("admission") == "technical_state_excluded" and
                    cause.get("technical_error") == "state_policy" and
                    bool(previous.get("state_check", {}).get("reasons")) and
                    cause.get("previous_state_reasons") == previous["state_check"]["reasons"])
                require(prior_run == action["run_id"] and (failed_retry or state_retry) and
                        cause.get("run_id") == action["run_id"] and cause.get("protocol_sha256") == protocol_sha and
                        cause.get("cause_corrected") is True and isinstance(cause.get("reason"), str) and
                        bool(cause["reason"].strip()), "inadmissible_retry")
            elif prior_run is not None:
                require(grouped[prior_run][-1][1].get("status") == "completed" and
                        grouped[prior_run][-1][1].get("included") is True, "advanced_past_nonadmitted_cell")
            history.append((index, attempt))
            prior_run = action["run_id"]
            row.update(case_id=action["case_id"], cut=action["cut"], variant=action["variant"], block=action["block"])
            if attempt.get("status") in {"started", "hardware_finished", "uncertain", "failed"}:
                row["admission"] = "not_admitted"
                continue
            require(attempt.get("status") == "completed" and attempt.get("returncode") == 0, "attempt_not_successful")
            path = task_path(root, attempt["report_path"], original)
            raw, digest = read_json(path, attempt["report_sha256"])
            sources[path.relative_to(root).as_posix()] = digest
            case = cases[action["case_id"]]
            measures = validate_raw(protocol, protocol_sha, case, configs[action["case_id"]], action, raw)
            require(measures["worker_pid"] not in pids, "reused_worker_process_pid")
            require(last_raw_finish is None or measures["started_time_ns"] >= last_raw_finish, "raw_process_order_or_overlap_invalid")
            pids.add(measures["worker_pid"])
            last_raw_finish = measures["finished_time_ns"]
            row.update(measures, report_path=path.relative_to(root).as_posix(), report_sha256=digest)
            require(attempt.get("before_state_check", {}).get("comparable") is True and
                    not attempt["before_state_check"].get("reasons"), "controller_started_with_noncomparable_state")
            for name in ("before_snapshot", "after_snapshot"):
                state_path = task_path(root, attempt[name], original)
                _, state_sha = read_json(state_path)
                row[name] = state_path.relative_to(root).as_posix()
                row[name+"_sha256"] = state_sha
                sources[state_path.relative_to(root).as_posix()] = state_sha
            state = attempt.get("state_check", {})
            if attempt.get("included") is True:
                require(state.get("comparable") is True and not state.get("reasons"), "controller_state_admission_failed")
                row["admission"] = "admitted"
            else:
                require(attempt.get("included") is False and state.get("comparable") is False and
                        isinstance(state.get("reasons"), list) and bool(state["reasons"]), "unregistered_or_unexplained_completed_exclusion")
                row.update(admission="technical_state_excluded", technical_state_reasons=state["reasons"])
        except (ValueError, OSError, KeyError, TypeError, IndexError) as error:
            row["errors"].append(str(error))
            failures.append({"attempt_id": attempt.get("attempt_id"), "error": str(error)})
    if seen_first != list(range(len(seen_first))):
        failures.append({"error": "actual_first_attempt_order_is_not_frozen_schedule_prefix"})
    cells = []
    for i, action in enumerate(actions):
        history = grouped.get(action["run_id"], [])
        last = rows[history[-1][0]] if history else None
        included = bool(last and last.get("admission") == "admitted" and not last["errors"])
        cell = {"series_id": SERIES, "model": "resnet50", "schedule_order": i+1,
                **{k: action[k] for k in ("case_id", "cut", "variant", "block", "run_id")},
                "attempt_count": len(history), "last_status": last["status"] if last else "not_started",
                "included": included, "protocol_sha256": protocol_sha,
                "protocol_profile_sha256": protocol["profiles"]["sha256"],
                "last_attempt_id": last["attempt_id"] if last else None,
                "exclusion_reasons": (last["errors"] or ([] if included else ["last_attempt_not_admitted:"+str(last["status"])]))
                    if last else ["not_started"]}
        for key in ("completed_work_units", "measurement_time_seconds", "completed_task_fps", "reported_completed_task_fps",
                    "worker_pid", "started_time_ns", "finished_time_ns", "report_path", "report_sha256",
                    "before_snapshot", "before_snapshot_sha256", "after_snapshot", "after_snapshot_sha256"):
            cell[key] = last.get(key) if last else None
        cells.append(cell)
    complete = len(cells) == 40 and all(c["included"] for c in cells) and not failures
    blocks = block_contrasts(cells)
    summaries = [{"series_id": SERIES, "model": "resnet50", "contrast": name, "method": METHOD,
                  "interval_scope": "nominal_two_sided_95_percent_five_independent_process_blocks",
                  **summarize_logs([r["log_ratio"] for r in blocks if r["contrast"] == name])}
                 for name in CONTRASTS] if complete else []
    historical = {"included_in_statistics": False, "old_cells_reused": 0, "manifest": None, "manifest_sha256": None}
    if historical_manifest is not None:
        path = task_path(root, historical_manifest, original)
        _, digest = read_json(path)
        historical.update(manifest=path.relative_to(root).as_posix(), manifest_sha256=digest)
        sources[path.relative_to(root).as_posix()] = digest
    return {"schema": "resnet-full-replication-analysis-v1", "series_id": SERIES,
        "status": "invalid" if failures else "complete" if complete else "incomplete",
        "protocol_path": protocol_path.relative_to(root).as_posix(), "protocol_sha256": protocol_sha,
        "progress_snapshot_path": progress_path.relative_to(root).as_posix(), "progress_snapshot_sha256": progress_sha,
        "analysis_source_sha256": analyzer_sha,
        "expected_cells": 40, "admitted_cells": sum(c["included"] for c in cells),
        "attempt_count": len(attempts), "distinct_worker_pids": len({c["worker_pid"] for c in cells if c["included"]}),
        "all_completed_attempt_worker_pids": len(pids), "audit_errors": failures,
        "complete_block_ids": [b for b in BLOCKS if all(c["included"] for c in cells if c["block"] == b)],
        "cells": cells, "attempts": rows, "blocks": blocks, "summaries": summaries,
        "decisions": decisions(summaries) if complete else None, "historical_reference": historical,
        "source_sha256": dict(sorted(sources.items())),
        "scope": {"no_historical_or_pilot_pooling": True, "outcome_dependent_extension": False,
            "energy_measured": False, "isolated_copy_or_conversion_cost_identified": False,
            "general_prevalence_inference": False, "independent_device_state_review_required": True}}


def write_csv(path, rows, fields):
    fields = list(dict.fromkeys(key for row in rows for key in row)) or fields
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: json.dumps(value, sort_keys=True, allow_nan=False) if isinstance(value, (list, dict)) else value
                             for key, value in row.items()})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--protocol", type=Path, default=Path("PROTOCOL.json"))
    parser.add_argument("--progress-snapshot", type=Path, required=True)
    parser.add_argument("--historical-manifest", type=Path)
    parser.add_argument("--output-prefix", type=Path, default=Path("results/replication_analysis"))
    args = parser.parse_args()
    root = args.root.resolve()
    def inside(path):
        result = (root/path).resolve() if not path.is_absolute() else path.resolve()
        require(result.is_relative_to(root), "CLI_path_outside_new_series")
        return result
    output = inside(args.output_prefix)
    result = analyze(inside(args.protocol), inside(args.progress_snapshot), root=root,
                     historical_manifest=args.historical_manifest)
    output.parent.mkdir(parents=True, exist_ok=True)
    for name, fallback in [("cells", ["series_id", "cut", "variant", "block", "included"]),
                           ("attempts", ["attempt_id", "status"]), ("blocks", ["block", "contrast", "log_ratio"]),
                           ("summaries", ["contrast", "n_blocks", "geometric_mean", "ci95_low", "ci95_high"])]:
        write_csv(Path(str(output)+"_"+name+".csv"), result[name], fallback)
    Path(str(output)+".json").write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False)+"\n")
    print(json.dumps({key: result[key] for key in ("status", "series_id", "expected_cells", "admitted_cells", "attempt_count", "audit_errors")}, indent=2))
    return 0 if result["status"] == "complete" else 1 if result["status"] == "invalid" else 2


if __name__ == "__main__":
    raise SystemExit(main())
