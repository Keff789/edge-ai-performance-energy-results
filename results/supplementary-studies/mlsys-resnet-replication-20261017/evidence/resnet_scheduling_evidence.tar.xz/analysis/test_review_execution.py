"""Synthetic saved-evidence tests. No hardware or actual new outcomes read."""
import copy
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("independent_execution", ROOT / "analysis/review_execution.py")
REVIEW = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(REVIEW)


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, sort_keys=True) + "\n")


def fixture(root, *, state_replacement=False):
    protocol = REVIEW.load(ROOT / "PROTOCOL.json")
    for relative in {"PROTOCOL.json", *(pin["local_path"] for pin in protocol["deploy_files"]),
                     protocol["controller"]["path"], protocol["analysis_source"]["path"], protocol["reuse_evidence"]["path"]}:
        destination = root / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / relative, destination)
    digest = REVIEW.sha(root / "PROTOCOL.json")
    policy = protocol["device"]["state_policy"]
    cases = {case["case_id"]: case for case in protocol["cases"]}
    sequence = copy.deepcopy(protocol["phases"]["primary"]["schedule"])
    if state_replacement:
        sequence.insert(0, copy.deepcopy(sequence[0]))
    attempts, counts = [], {}
    base = datetime.fromisoformat(protocol["frozen_at_utc"]).timestamp() + 1000
    for i, cell in enumerate(sequence):
        case = cases[cell["case_id"]]
        config = REVIEW.load(root / case["config_path"])
        action = REVIEW.action(digest, case, config, "primary", cell)
        counts[action["run_id"]] = counts.get(action["run_id"], 0) + 1
        attempt_id = action["run_id"] + f"_attempt{counts[action['run_id']]:02d}"
        chain, scheduling = REVIEW.VARIANTS[cell["variant"]]
        start = base + 200 * i
        state = {"/sys/class/thermal/thermal_zone0/temp": "50000", "probe_process_cpu_affinity": policy["affinity"],
                 "power_mode_read_only_query": {"returncode": 0, "output": policy["power_mode"]}}
        for core in policy["affinity"]:
            for field in ["scaling_min_freq", "scaling_max_freq", "scaling_cur_freq"]:
                state[f"/sys/devices/system/cpu/cpu{core}/cpufreq/{field}"] = str(policy["cpu_min_max_khz"])
        for field in ["min_freq", "max_freq", "cur_freq"]:
            state["/sys/class/devfreq/17000000.gpu/" + field] = str(policy["gpu_min_max_hz"])
        for number in range(8):
            prefix = f"/sys/class/thermal/cooling_device{number}"
            state[prefix + "/type"] = f"synthetic{number}-throttle-alert"
            state[prefix + "/cur_state"] = "0"
        pins = {pin["path"]: pin["sha256"] for pin in case["required_artifacts"] + case["required_sources"]}
        pins.update({protocol["device"]["remote_root"] + "/" + pin["remote_relative"]: pin["sha256"] for pin in protocol["deploy_files"]})
        pins[protocol["device"]["remote_root"] + "/PROTOCOL.json"] = digest
        observation = {"ok": True, "read_only": True, "processes": [], "live_product_leases": [], "visibility_errors": []}
        snapshot = {"read_only": True, "admission": {"eligible": True, "exclusive_start_permission": True, "blockers": []},
            "identity": protocol["device"]["expected_identity"], "owners": observation, "controller": observation,
            "reservation": {"owner": {"state": "running", "run_id": protocol["series_id"], "session_id": "mechanism-" + digest, "pid": 999},
                "kernel_lock_pids": [999], "quarantine_exists": False, "visibility_errors": []},
            "artifacts": [{"path": path, "exists": True, "regular_file": True, "readable": True, "actual_sha256": value} for path, value in pins.items()],
            "current_python_environment": {"runtime_initialized": False, "returncode": 0, "executable": protocol["device"]["python"]},
            "read_only_start_state": state}
        directory = root / "results/synthetic/snapshots"
        for suffix, stamp in [("stability", start - 3), ("before", start - 1), ("after", start + 95)]:
            value = copy.deepcopy(snapshot)
            value["observed_at_utc"] = datetime.fromtimestamp(stamp, timezone.utc).isoformat()
            if state_replacement and i == 0 and suffix == "after":
                value["read_only_start_state"]["/sys/class/devfreq/17000000.gpu/cur_freq"] = "1"
            write(directory / (action["run_id"] + "_" + suffix + "_" + str(i) + ".json"), value)
        raw_identity = {"protocol_sha256": digest, "identity": config["identity"], "artifact_identity": config["expected_runtime_artifacts"],
                        "chain": chain, "schedule": scheduling, "block": cell["block"], "mode": "duration"}
        metrics = ({"status": "ok", "requested_duration_s": 60, "admitted_task_count": 64, "completed_task_count": 64,
            "processor_count_delta": 64, "completed_work_units": 64, "accepted_work_drained": True, "fill_and_drain_included": True,
            "postprocess_timed": True, "output_materialization_timed": True, "measurement_start_ns": 0,
            "admission_deadline_ns": 60_000_000_000, "admission_stopped_ns": 60_000_000_000, "measurement_end_ns": 60_100_000_000,
            "admission_stopped_at_deadline": True, "measured_makespan_seconds": 60.1, "worker_count": 2, "queue_depth": 2} if chain == "generic" else
            {"duration_s": 60, "produced_frames": 64, "consumed_frames": 64, "completed_work_units": 64, "postprocess_completed_frames": 64,
             "task_complete": True, "postprocess_completion_verified": True, "postprocess_included": True,
             "completed_task_stage": "classification_top1_top5", "measurement_boundary": "workers_ready_to_last_completed_task_frame",
             "warmup_contract": "fully_drained_before_worker_start", "makespan_ms": 60100.0,
             "inflight": 8 if scheduling == "product" else 1, "queue_depth": 3,
             "request_latency": {"status": "unavailable", "reason": "duration_workload_not_instrumented", "pairs": []}})
        raw = {**raw_identity, "run_id": REVIEW.canonical(raw_identity), "schema": "mechanism-product-workers-v1", "status": "complete",
            "adapter_sha256": protocol["adapter"]["sha256"], "product_runner": case["runners"][chain]["path"],
            "product_runner_sha256": case["runners"][chain]["sha256"], "config_sha256": case["config_sha256"],
            "diagnostic_adapter": True, "energy_measured": False, "worker_cpu_affinity": policy["affinity"],
            "loaded_source_hashes": {case["runners"][chain]["path"]: case["runners"][chain]["sha256"]},
            "pid": 10000 + i, "started_time_ns": int(start * 1e9), "finished_time_ns": int((start + 92) * 1e9),
            "completed_work_units": 64, "measurement_time_seconds": 60.1, "completed_task_fps": 64 / 60.1,
            "warmup_duration_s": 30, "warmup_completed_count": 8, "admission_window_seconds": 60, "accepted_work_drained": True,
            "metrics": metrics}
        raw_path = root / "results/synthetic/reports" / (attempt_id + ".json")
        write(raw_path, raw)
        absolute = lambda path: str(Path("/home/kmika/Reports") / REVIEW.STUDY_NAME / path.relative_to(root))
        before = directory / (action["run_id"] + "_before_" + str(i) + ".json")
        after = directory / (action["run_id"] + "_after_" + str(i) + ".json")
        state_check = {"comparable": True, "reasons": []}
        excluded = state_replacement and i == 0
        attempt = {**action, "attempt_id": attempt_id, "status": "completed", "returncode": 0, "included": not excluded,
            "started_at_utc": datetime.fromtimestamp(start, timezone.utc).isoformat(), "finished_wall_time": start + 96,
            "before_snapshot": absolute(before), "after_snapshot": absolute(after), "report_path": absolute(raw_path), "report_sha256": REVIEW.sha(raw_path),
            "before_state_check": {**state_check, "temperature_c": 50, "previous_temperature_c": 50},
            "state_check": {"comparable": False, "reasons": ["gpu_clock_changed"]} if excluded else state_check}
        if state_replacement and i == 1:
            attempt["retry_cause"] = {"run_id": action["run_id"], "protocol_sha256": digest, "cause_corrected": True,
                "technical_error": "state_policy", "reason": "Synthetic clock observation restored", "previous_state_reasons": ["gpu_clock_changed"]}
        attempts.append(attempt)
    progress = {"schema": "mechanism-progress-v1", "protocol_sha256": digest, "attempts": attempts, "events": [{"status": "phase_completed"}]}
    write(root / "results/final_progress.json", progress)
    return progress


class SavedExecutionReviewTests(unittest.TestCase):
    def check(self, mutation=None, *, state_replacement=False):
        with tempfile.TemporaryDirectory(prefix="resnet-renamed-synthetic-") as temporary:
            root = Path(temporary)
            progress = fixture(root, state_replacement=state_replacement)
            if mutation:
                mutation(root, progress)
                write(root / "results/final_progress.json", progress)
            return REVIEW.execution_review(root, root / "PROTOCOL.json", root / "results/final_progress.json")

    def test_complete_fresh40_pass(self):
        result = self.check()
        self.assertEqual((result["status"], result["admitted_complete_processes"], result["distinct_admitted_worker_pids"]), ("PASS", 40, 40))

    def test_incomplete39_is_not_pass(self):
        result = self.check(lambda root, progress: progress["attempts"].pop())
        self.assertEqual(result["status"], "INCOMPLETE")

    def test_reordered_first_attempts_fail(self):
        def change(root, progress):
            progress["attempts"][0], progress["attempts"][1] = progress["attempts"][1], progress["attempts"][0]
        self.assertEqual(self.check(change)["status"], "FAIL")

    def test_wrong_full_makespan_rate_fails(self):
        def change(root, progress):
            attempt = progress["attempts"][0]
            path = REVIEW.task_path(root, attempt["report_path"])
            raw = REVIEW.load(path); raw["completed_task_fps"] = 64 / 60
            write(path, raw); attempt["report_sha256"] = REVIEW.sha(path)
        self.assertEqual(self.check(change)["status"], "FAIL")

    def test_incomplete_postprocess_fails(self):
        def change(root, progress):
            attempt = next(item for item in progress["attempts"] if item["variant"].startswith("N_"))
            path = REVIEW.task_path(root, attempt["report_path"])
            raw = REVIEW.load(path); raw["metrics"]["postprocess_completed_frames"] = 63
            write(path, raw); attempt["report_sha256"] = REVIEW.sha(path)
        self.assertEqual(self.check(change)["status"], "FAIL")

    def test_state_exclusion_replacement_preserves41_and_admits40(self):
        result = self.check(state_replacement=True)
        self.assertEqual((result["status"], result["process_attempts"], result["admitted_complete_processes"]), ("PASS", 41, 40))
        self.assertEqual(result["attempt_status_counts"]["excluded_attempt_preserved"], 1)

    def test_state_replacement_without_cause_fails(self):
        self.assertEqual(self.check(lambda root, progress: progress["attempts"][1].pop("retry_cause"), state_replacement=True)["status"], "FAIL")

    def test_foreign_original_prefix_rejected(self):
        def change(root, progress):
            progress["attempts"][0]["before_snapshot"] = "/home/kmika/Reports/another_study/before.json"
        self.assertEqual(self.check(change)["status"], "FAIL")


if __name__ == "__main__":
    unittest.main()
