# Original scheduling evidence extract

Source: `MLSYS_R14_RESNET_FULL_REPLIKATION_20261017_RESULTS.zip`
SHA256: `7e0bd1c86f57184cd6c53cc5122a20d664ca1f8a05b57eeb8d8d3a3807ae5056`

All selected original members are byte-identical and retain their original paths. `EXTRACT_MANIFEST.json` binds each member to its original archive and SHA256. The two EXTRACT files are new packaging metadata. Original README commands and statements describe the full source archive; they are not a claim that every original dependency is bundled here.

The process groups are {"resnet_fresh_factorial": 40}. The earlier twenty-process Native-only ResNet series is separate from both forty-process factorial studies. Use the manifest's series index; do not pool these observations.

All protocol-deployed source files and separately pinned local controller files are included with matching hashes. Each confirmed process has before, stability and after state records. Reused functional checks retain their original canary/pilot provenance; pilot timing reports, model binaries, manuscript inputs and personal task prompts are excluded. Small prepared-input and output-reference tensors are functional evidence, not model binaries.

Offline arithmetic can use these recorded reports and the accompanying analysis source. New hardware measurements additionally require the original model artifacts, datasets/benchmark artifacts, compatible vendor SDKs and recorded device configuration. Source copies and recorded states do not recreate every historical environment.
