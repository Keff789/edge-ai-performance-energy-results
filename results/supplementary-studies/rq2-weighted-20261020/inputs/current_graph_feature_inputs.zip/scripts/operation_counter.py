"""Metadata-only adapter for the rules evidenced by analytic-operation-proxy-v2.1.

This is NEW source, not the unavailable original counter with SHA 4cad91d5....
The supported arithmetic rules are those actually exercised in the seven bound
graphs. Capture verifies every node against the original seven-model v2.1 audit.
One MAC, scalar arithmetic primitive, comparison, and selection each count one.
Structural zero means zero analytic arithmetic, not zero runtime/memory cost.
Unsupported operators and missing metadata never silently contribute a known 0.
"""
from __future__ import annotations

import math

VERSION = "bound-v2.1-rules-adapter-v1"
STRUCTURAL_ZERO = {
    "Cast", "Compress", "Concat", "Constant", "ConstantOfShape", "DepthToSpace",
    "Expand", "Flatten", "Gather", "GatherElements", "GatherND", "Identity", "Pad",
    "Reshape", "Shape", "Size", "Slice", "SpaceToDepth", "Split", "Squeeze", "Tile",
    "Transpose", "Unsqueeze",
}
ELEMENT_PRIMITIVES = {"Add": 1, "Sub": 1, "Mul": 1, "Div": 1, "Relu": 2,
                      "HardSwish": 7, "HardSigmoid": 6, "Sigmoid": 4}


def _shape(tensors, name):
    shape = tensors.get(name, {}).get("shape")
    if shape is None or any(not isinstance(d, int) or isinstance(d, bool) or d < 0 for d in shape):
        raise ValueError("missing_or_dynamic_shape:" + name)
    return shape


def _result(node, value, classification, reason="", detail=None):
    return {
        "node_index": node["index"], "node_name": node["name"], "operator": node["op_type"],
        "complete": value is not None, "operations": value,
        "known_operations": value if value is not None else 0,
        "classification": classification, "reason": reason, "detail": detail or {},
    }


def count_node(node, tensors):
    op, attrs, inputs = node["op_type"], node["attributes"], node["input_names"]
    if node.get("domain", "") not in ("", "ai.onnx"):
        return _result(node, None, "unsupported_computational", "unsupported_domain:" + node["domain"])
    if op in STRUCTURAL_ZERO:
        return _result(node, 0, "structural_zero_arithmetic")
    supported = set(ELEMENT_PRIMITIVES) | {"Conv", "Gemm", "MatMul", "ReduceMean", "MaxPool", "Resize"}
    if op not in supported:
        return _result(node, None, "unsupported_computational", "unsupported_operator:" + op)
    try:
        output = _shape(tensors, node["output_names"][0])
        elements = math.prod(output)
        detail = {"output_shape": output, "output_elements": elements}
        if op in ELEMENT_PRIMITIVES:
            factor = ELEMENT_PRIMITIVES[op]
            if op not in {"Add", "Sub", "Mul", "Div"}:
                detail["primitives_per_element"] = factor
            if op == "HardSigmoid":
                detail.update(alpha=attrs.get("alpha", 0.2), beta=attrs.get("beta", 0.5))
            value = elements * factor
        elif op == "Conv":
            source, weight = _shape(tensors, inputs[0]), _shape(tensors, inputs[1])
            group = attrs.get("group", 1)
            if len(source) < 3 or len(weight) != len(source) or len(output) != len(source):
                raise ValueError("invalid_conv_rank")
            if group <= 0 or source[1] != weight[1] * group or output[1] != weight[0]:
                raise ValueError("inconsistent_conv_channels")
            macs = elements * weight[1] * math.prod(weight[2:])
            bias = elements if len(inputs) > 2 and inputs[2] else 0
            detail.update(group=group, input_channels=source[1], weight_shape=weight,
                          macs=macs, bias_additions=bias)
            value = macs + bias
        elif op == "Gemm":
            a, b = _shape(tensors, inputs[0]), _shape(tensors, inputs[1])
            if len(a) != 2 or len(b) != 2:
                raise ValueError("invalid_gemm_rank")
            trans_a, trans_b = attrs.get("transA", 0), attrs.get("transB", 0)
            m, k = a[::-1] if trans_a else a
            k2, n = b[::-1] if trans_b else b
            if k != k2 or output != [m, n]:
                raise ValueError("inconsistent_gemm_dimensions")
            alpha, beta = attrs.get("alpha", 1.0), attrs.get("beta", 1.0)
            bias_shape = _shape(tensors, inputs[2]) if len(inputs) > 2 and inputs[2] else None
            if bias_shape is not None:
                aligned = [1] * (2 - len(bias_shape)) + bias_shape
                if len(aligned) != 2 or any(c not in (1, d) for c, d in zip(aligned, output)):
                    raise ValueError("inconsistent_gemm_bias_shape")
            macs = m * n * k
            alpha_ops = elements if alpha != 1 else 0
            beta_ops = elements if bias_shape is not None and beta not in (0, 1) else 0
            bias_ops = elements if bias_shape is not None and beta != 0 else 0
            detail.update(transA=trans_a, transB=trans_b, M=m, N=n, K=k, alpha=alpha,
                          beta=beta, bias_shape=bias_shape, macs=macs,
                          alpha_multiplications=alpha_ops, beta_multiplications=beta_ops,
                          bias_additions=bias_ops)
            value = macs + alpha_ops + beta_ops + bias_ops
        elif op == "MatMul":
            a, b = _shape(tensors, inputs[0]), _shape(tensors, inputs[1])
            if len(a) < 2 or len(b) < 2:
                raise ValueError("vector_matmul_rule_not_evidenced")
            if a[-1] != b[-2]:
                raise ValueError("inconsistent_matmul_inner_dimension")
            lead = max(len(a), len(b)) - 2
            aa, bb = [1] * (lead - len(a[:-2])) + a[:-2], [1] * (lead - len(b[:-2])) + b[:-2]
            if any(x != y and x != 1 and y != 1 for x, y in zip(aa, bb)):
                raise ValueError("inconsistent_matmul_broadcast")
            batch = [max(x, y) for x, y in zip(aa, bb)]
            if output != batch + [a[-2], b[-1]]:
                raise ValueError("inconsistent_matmul_output")
            value = elements * a[-1]
            detail.update(batch_shape=batch, M=a[-2], N=b[-1], K=a[-1], macs=value)
        elif op == "ReduceMean":
            source = _shape(tensors, inputs[0])
            axes = attrs.get("axes")
            axes_source = "attribute"
            if len(inputs) > 1 and inputs[1]:
                axes = tensors.get(inputs[1], {}).get("constant_int_values")
                axes_source = "constant_input"
                if axes is None:
                    raise ValueError("missing_constant_reduction_axes")
            noop = not axes and bool(attrs.get("noop_with_empty_axes", 0))
            if not axes:
                axes = [] if noop else list(range(len(source)))
            axes = [a if a >= 0 else a + len(source) for a in axes]
            if len(axes) != len(set(axes)) or any(a < 0 or a >= len(source) for a in axes):
                raise ValueError("invalid_reduction_axes")
            axes = sorted(axes)
            reduced = math.prod(source[a] for a in axes)
            keepdims = attrs.get("keepdims", 1)
            expected = [1 if i in axes else d for i, d in enumerate(source)] if keepdims else [
                d for i, d in enumerate(source) if i not in axes]
            if expected != output or reduced == 0:
                raise ValueError("inconsistent_or_empty_reduction")
            additions = 0 if noop else elements * (reduced - 1)
            divisions = 0 if noop else elements
            detail.update(axes=axes, axes_source=axes_source, keepdims=keepdims, noop=bool(noop),
                          reduced_elements_per_output=reduced, additions=additions, divisions=divisions)
            value = additions + divisions
        elif op == "MaxPool":
            source = _shape(tensors, inputs[0])
            rank = len(source) - 2
            kernel = attrs.get("kernel_shape")
            if rank < 1 or not kernel or len(kernel) != rank or len(output) != len(source):
                raise ValueError("invalid_pool_rank")
            strides, dilation = attrs.get("strides", [1] * rank), attrs.get("dilations", [1] * rank)
            pads = attrs.get("pads", [0] * (2 * rank))[:rank]
            if attrs.get("auto_pad", "NOTSET") not in ("NOTSET", ""):
                raise ValueError("pool_auto_pad_rule_not_evidenced")
            counts = []
            for d in range(rank):
                counts.append([sum(0 <= o * strides[d] - pads[d] + j * dilation[d] < source[d + 2]
                                   for j in range(kernel[d])) for o in range(output[d + 2])])
            # Separability avoids iterating every output element or allocating tensors.
            valid_elements = math.prod(sum(axis) for axis in counts)
            nonempty_windows = math.prod(sum(n > 0 for n in axis) for axis in counts)
            comparisons = (valid_elements - nonempty_windows) * math.prod(output[:2])
            detail.update(kernel_shape=kernel, strides=strides, dilations=dilation, begin_pads=pads,
                          comparisons=comparisons, selections=comparisons,
                          padding_policy="excluded_real_input_windows")
            value = comparisons * 2
        else:  # Resize: only the evidenced nearest-neighbour selection rule.
            mode = attrs.get("mode", "nearest")
            if mode != "nearest":
                raise ValueError("resize_mode_rule_not_evidenced:" + mode)
            value = elements
            detail.update(mode=mode, sampled_value_selections=elements)
        return _result(node, value, "modeled", detail=detail)
    except (ValueError, IndexError, TypeError) as error:
        return _result(node, None, "modeled_issue", str(error))
