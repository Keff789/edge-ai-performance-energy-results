"""Reproduce complete graph-boundary features from compact, bound metadata."""
from __future__ import annotations

import csv
import hashlib
import json
import math
from pathlib import Path

DTYPE_BITS = {1: 32, 2: 8, 3: 8, 4: 16, 5: 16, 6: 32, 7: 64,
              9: 8, 10: 16, 11: 64, 12: 32, 13: 64, 14: 64, 15: 128, 16: 16}
DTYPE_NAMES = {1: "FLOAT", 2: "UINT8", 3: "INT8", 4: "UINT16", 5: "INT16",
               6: "INT32", 7: "INT64", 8: "STRING", 9: "BOOL", 10: "FLOAT16",
               11: "DOUBLE", 12: "UINT32", 13: "UINT64", 14: "COMPLEX64",
               15: "COMPLEX128", 16: "BFLOAT16"}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def order_identity(order):
    return hashlib.sha256(canonical(order).encode()).hexdigest()


def boundary_identity(graph_sha, order_sha, boundary):
    return f"sha256:{graph_sha}:topo:{order_sha}:b{boundary:06d}"


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def write_csv(path, rows):
    with Path(path).open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: canonical(v) if isinstance(v, (list, dict)) else v for k, v in row.items()})


def tensor_size(tensor):
    shape, dtype = tensor.get("shape"), tensor.get("dtype_enum")
    if shape is None:
        return None, "unknown_rank"
    if any(not isinstance(d, int) or isinstance(d, bool) or d < 0 for d in shape):
        return None, "dynamic_or_unknown_dimension"
    if dtype not in DTYPE_BITS:
        return None, "unknown_or_variable_width_dtype"
    return (math.prod(shape) * DTYPE_BITS[dtype] + 7) // 8, "known"


def graph_maps(graph):
    nodes = graph["nodes"]
    order = graph["order"]
    if sorted(order) != list(range(len(nodes))):
        raise ValueError("Topological order is not a complete node permutation")
    producer, consumers = {}, {}
    for i, node in enumerate(nodes):
        if node["index"] != i:
            raise ValueError("Original node index changed")
        for output in node["output_names"]:
            if output:
                if output in producer:
                    raise ValueError("Multiple producers for a tensor")
                producer[output] = i
    positions = {node: pos for pos, node in enumerate(order)}
    for i, node in enumerate(nodes):
        for name in node["input_names"]:
            if name:
                consumers.setdefault(name, []).append(i)
            if name in producer and positions[producer[name]] >= positions[i]:
                raise ValueError("Captured order violates a producer dependency")
    return producer, consumers, positions


def part2_inputs(graph, cut, producer):
    """Same backward-slice contract as the published Tool's Part2 exporter."""
    if not cut:
        return [], []
    initializer_names = {name for name, value in graph["tensors"].items() if value.get("is_initializer")}
    original_inputs = set(graph["input_names"]) - initializer_names
    stop = set(cut) | original_inputs
    stack, visited, needed = list(graph["output_names"]), set(), set()
    while stack:
        value = stack.pop()
        if not value or value in visited:
            continue
        visited.add(value)
        if value in stop or value in initializer_names:
            continue
        index = producer.get(value)
        if index is not None and index not in needed:
            needed.add(index)
            stack.extend(v for v in graph["nodes"][index]["input_names"] if v)
    used = {v for i in needed for v in graph["nodes"][i]["input_names"] if v}
    produced = {v for i in needed for v in graph["nodes"][i]["output_names"] if v}
    return sorted((used - produced) - initializer_names), sorted(needed)


def range_description(rows, field):
    known = [r[field] for r in rows if r[field] is not None]
    unknown = len(rows) - len(known)
    lo, hi = (min(known), max(known)) if known else (None, None)
    complete = unknown == 0 and bool(rows)
    return {
        "minimum": lo if complete else None, "maximum": hi if complete else None,
        "known_minimum": lo, "known_maximum": hi, "complete": complete,
        "constant": (lo == hi) if complete else None,
        "unknown_member_count": unknown, "member_count": len(rows),
        "constant_normalization_rule": "Known constant feature normalizes to zero, as in the archived Tool; an unknown feature remains null.",
    }


def universe(rows, definition):
    return {
        "members": [r["boundary_id"] for r in rows],
        "boundary_indices": [r["boundary"] for r in rows],
        "filter_definition": definition,
        "ranges": {f: range_description(rows, f) for f in ("log10_1p_Comm", "Imb_raw", "T_raw")},
    }


def features_for_graph(graph, costs):
    producer, consumers, positions = graph_maps(graph)
    order = graph["order"]
    if len(costs) != len(graph["nodes"]):
        raise ValueError("Counter omitted nodes")
    for cost in costs:
        known = cost["known_operations"]
        if not isinstance(known, int) or isinstance(known, bool) or known < 0:
            raise ValueError("Counter must report nonnegative integer known operation subtotals")
        if cost["complete"] != (cost["operations"] is not None):
            raise ValueError("Counter completeness disagrees with null status")
        if cost["complete"] and cost["operations"] != known:
            raise ValueError("Complete node count differs from its known subtotal")
    order_sha = order_identity(order)
    graph_sha = graph["model_sha256"]
    missing = [i for i, cost in enumerate(costs) if not cost["complete"]]
    total_known = sum(cost["known_operations"] for cost in costs)
    total = total_known if not missing else None
    prefix_known, prefix_missing = 0, 0
    rows, tensor_rows = [], []
    saved = {int(c["boundary"]): c for c in graph["saved_candidates"]}
    if len(saved) != len(graph["saved_candidates"]):
        raise ValueError("Duplicate saved boundary identity")
    for boundary, index in enumerate(order[:-1]):
        prefix_known += costs[index]["known_operations"]
        prefix_missing += not costs[index]["complete"]
        suffix_missing = len(missing) - prefix_missing
        # This order follows left-node topological order and output-port order,
        # precisely the cut_tensors_for_boundary contract, with no size filter.
        cut = [
            name for left in order[:boundary + 1]
            for name in graph["nodes"][left]["output_names"]
            if name and any(positions[c] > boundary for c in consumers.get(name, []))
        ]
        if len(cut) != len(set(cut)):
            raise ValueError("Duplicate crossing tensor")
        inputs, needed = part2_inputs(graph, cut, producer)
        extras = sorted(set(inputs) - set(cut) - set(graph["input_names"]))
        tensor_details = []
        for name in cut:
            tensor = graph["tensors"].get(name, {})
            size, status = tensor_size(tensor)
            tensor_details.append({
                "name": name, "tensor_id": f"sha256:{graph_sha}/value:{name}",
                "identity_definition": "Exact full-graph SHA and ONNX value name; not a runtime tensor-content hash.",
                "shape": tensor.get("shape"), "dtype": DTYPE_NAMES.get(tensor.get("dtype_enum"), tensor.get("dtype_name", "UNKNOWN")),
                "dtype_enum": tensor.get("dtype_enum"), "logical_bytes": size,
                "size_status": status,
                "unknown_dimension_indices": [i for i, d in enumerate(tensor.get("shape") or []) if not isinstance(d, int) or isinstance(d, bool) or d < 0],
                "producer_node_index": producer[name],
                "producer_topological_position": positions[producer[name]],
                "consumer_node_indices": consumers.get(name, []),
                "right_consumer_node_indices": [c for c in consumers.get(name, []) if positions[c] > boundary],
                "shape_source": tensor.get("shape_source", "original_onnx_value_info"),
            })
        comm_known = sum(t["logical_bytes"] for t in tensor_details if t["logical_bytes"] is not None)
        comm_complete = all(t["logical_bytes"] is not None for t in tensor_details)
        comm = comm_known if comm_complete else None
        left = prefix_known if prefix_missing == 0 else None
        right = total_known - prefix_known if suffix_missing == 0 else None
        imbalance = abs(left - right) / total if total is not None and total > 0 else None
        reasons = []
        if boundary == 0:
            reasons.append("workflow_starts_at_boundary_1")
        if comm is None:
            reasons.append("communication_size_incomplete")
        elif comm <= 0:
            reasons.append("nonpositive_communication")
        if extras:
            reasons.append("additional_intermediate_part2_inputs")
        complete = comm_complete and total is not None and total > 0
        unavailable = list(reasons)
        if total is None:
            unavailable.append("operations_incomplete")
        elif total == 0:
            unavailable.append("zero_total_operations")
        row = {
            "model": graph["model"], "model_sha256": graph_sha, "boundary": boundary,
            "boundary_id": boundary_identity(graph_sha, order_sha, boundary),
            "topological_order_sha256": order_sha,
            "case": f"b{boundary:03d}",
            "left_last_node_index": index, "right_first_node_index": order[boundary + 1],
            "crossing_tensor_names": cut, "crossing_tensor_count": len(cut),
            "part2_input_names": inputs, "part2_input_count": len(inputs),
            "native_single_input_compatible": len(inputs) == 1,
            "Comm": comm, "Comm_known": comm_known, "comm_complete": comm_complete,
            "F_left": left, "F_right": right, "F_total": total,
            "F_left_known": prefix_known, "F_right_known": total_known - prefix_known,
            "F_total_known": total_known,
            "left_operations_complete": prefix_missing == 0,
            "right_operations_complete": suffix_missing == 0,
            "operations_complete": not missing,
            "left_missing_operation_nodes": prefix_missing,
            "right_missing_operation_nodes": suffix_missing,
            "total_missing_operation_nodes": len(missing),
            "operation_node_coverage_denominator": len(costs),
            "Imb_raw": imbalance,
            "Imb_status": "complete" if imbalance is not None else "unknown_operations" if total is None else "zero_total_operations",
            "T_raw": max(0, len(cut) - 1),
            "log10_1p_Comm": math.log10(1 + comm) if comm is not None else None,
            "strict_boundary_ok": not extras, "strict_extra_inputs": extras,
            "tool_workflow_candidate": not reasons,
            "tool_workflow_filter_reasons": reasons,
            "stored_candidate_member": boundary in saved,
            "stored_candidate_exclude_reason": saved.get(boundary, {}).get("exclude_reason"),
            "stored_candidate_strict_ok": saved.get(boundary, {}).get("strict_ok"),
            "candidate_available": not reasons and complete,
            "candidate_unavailable_reasons": unavailable,
            "feature_complete": complete,
        }
        if left is not None and right is not None and total is not None and left + right != total:
            raise AssertionError("Operation partition does not sum")
        rows.append(row)
        tensor_rows.append({
            "model": graph["model"], "model_sha256": graph_sha, "boundary": boundary,
            "boundary_id": row["boundary_id"], "topological_order_sha256": order_sha,
            "tensors": tensor_details, "part2_input_names": inputs,
            "part2_required_node_indices": needed,
        })
    if any(b < 0 or b >= len(order) - 1 for b in saved):
        raise ValueError("Saved candidate lies outside enumerated universe")
    ranking_methods = sorted({c["workflow_ranking_method"] for c in graph["saved_candidates"]
                              if c.get("workflow_ranking_method")})
    normalized = {
        "model": graph["model"], "model_sha256": graph_sha, "order": order,
        "topological_order_sha256": order_sha,
        "order_policy": graph["order_policy"],
        "node_count": len(order), "enumerated_boundary_count": len(rows),
        "saved_candidates_source": graph["saved_candidates_source"],
        "saved_candidate_values_role": "Membership/filter provenance only. Current operation features are recomputed; archived operation counts/scores are not reused.",
        "saved_scoring_provenance": {
            "recorded_workflow_ranking_methods": ranking_methods,
            "recorded_selection_reasons": sorted({c["selection_reason"] for c in graph["saved_candidates"]
                                                  if c.get("selection_reason")}),
            "recorded_score_minmax_normalization": False if ranking_methods == ["cut_bytes_only"] else None,
            "recorded_score_interpretation": (
                "The bound candidate_ranking records cut_bytes_only ordering. This is not evidence that an ARCS score or ARCS min-max normalization was executed."
                if ranking_methods == ["cut_bytes_only"] else
                "Recorded ranking method alone is not evidence of a particular executed ARCS normalization universe."),
            "executed_archived_ARCS_normalization_universe": None,
            "executed_archived_ARCS_normalization_status": "not_recorded_in_inspected_saved_ranking",
            "later_reconstruction_universe": "archived_saved_score_candidates",
            "later_reconstruction_scope": "An explicitly declared choice of the exact stored membership, with new ranges from this counter. It is not a claim about an unrecorded historical ARCS execution.",
        },
        "universes": {
            "full_enumerated": universe(rows, "Every between-node boundary b=0,...,N-2 in the explicitly captured topological order."),
            "regular_workflow_candidates": universe([r for r in rows if r["tool_workflow_candidate"]],
                "Workflow b>=1, positive fully known communication and no extra intermediate Part2 inputs. Original graph inputs are allowed; single-Part2-input compatibility is a separate flag."),
            "archived_saved_score_candidates": universe([r for r in rows if r["stored_candidate_member"]],
                "Exact saved candidate_ranking membership, independent of measured/quality subsets; new ranges supplied for a later explicitly chosen reconstruction. The key identifies stored membership, not a verified executed archived ARCS normalization universe."),
            "available_complete_candidates": universe([r for r in rows if r["candidate_available"]],
                "Regular workflow candidates with complete operation counts and positive total operations; no measured quality/performance gate is applied."),
        },
        "formulas": {
            "Comm": "sum of logical crossing-tensor bytes; null if any size is unknown",
            "Imb_raw": "abs(F_left-F_right)/(F_left+F_right); null if incomplete or denominator is zero",
            "T_raw": "max(0,crossing_tensor_count-1), counting all structural crossings including unknown-size values",
            "printed_ARCS_later": "1*minmax(log10(1+Comm)) + 3*Imb_raw + 0.2*minmax(T_raw)",
            "archived_Tool_later": "1*minmax(log10(1+Comm)) + 3*minmax(Imb_raw) + 0.2*minmax(T_raw)",
            "weights": [1, 3, 0.2], "scores_computed_here": False,
        },
    }
    return rows, tensor_rows, normalized, {
        "model": graph["model"], "model_sha256": graph_sha,
        "nodes": len(costs), "missing_operation_nodes": missing,
        "node_costs": costs, "F_total": total, "F_total_known": total_known,
        "operation_complete_node_count": len(costs) - len(missing),
        "enumeration_complete": len(rows) == max(0, len(costs) - 1),
        "communication_complete_boundary_count": sum(r["comm_complete"] for r in rows),
        "enumerated_boundary_count": len(rows),
        "convtranspose_nodes": [n["index"] for n in graph["nodes"] if n["op_type"] == "ConvTranspose"],
    }


def build(package_root: Path, output: Path):
    """The counter adapter is a versioned local module, populated at capture."""
    import importlib.util
    package_root, output = Path(package_root), Path(output)
    sources = json.loads((package_root / "inputs/graphs_manifest.json").read_text())
    for entry in sources["compact_files"]:
        if digest(package_root / entry["path"]) != entry["sha256"]:
            raise ValueError(f"Graph/counter input hash mismatch: {entry['path']}")
    projection = json.loads((package_root / "inputs/graphs.json").read_text())
    reference = json.loads((package_root / "inputs/counter_audit_reference.json").read_text())
    references = {g["model"]: g for g in reference["models"]}
    spec = importlib.util.spec_from_file_location("_current_graph_counter", package_root / "scripts/operation_counter.py")
    counter = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(counter)
    all_rows, tensor_rows, universes, audits = [], [], [], []
    for graph in projection["graphs"]:
        costs = [counter.count_node(node, graph["tensors"]) for node in graph["nodes"]]
        rows, tensors, norm, audit = features_for_graph(graph, costs)
        expected = references[graph["model"]]
        if graph["model_sha256"] != expected["observed_model_sha256"] or graph["order"] != expected["topological_order"]:
            raise ValueError("Graph identity/topology differs from bound current audit")
        if len(costs) != len(expected["node_operations"]):
            raise ValueError("Node count differs from bound current audit")
        for cost, original in zip(costs, expected["node_operations"]):
            for key in ("node_index", "node_name", "operator", "operations", "classification", "reason", "detail"):
                if cost[key] != original[key]:
                    raise ValueError(f"Recomputed counter differs from current audit: {graph['model']}/{cost['node_index']}/{key}")
        by_boundary = {r["boundary"]: r for r in rows}
        fields = {"Comm": "cut_bytes", "crossing_tensor_names": "cut_tensor_names",
                  "part2_input_names": "part2_input_names", "F_left": "operations_prefix",
                  "F_right": "operations_suffix", "F_left_known": "known_operation_subtotal_prefix",
                  "F_right_known": "known_operation_subtotal_suffix"}
        for original in expected["candidates"].values():
            row = by_boundary[original["boundary"]]
            for actual_field, original_field in fields.items():
                if actual_field in ("F_left", "F_right") and expected["operations_full"] is None:
                    if original[original_field] is not None:
                        raise ValueError("Unexpected incomplete-audit masking policy")
                    continue
                if row[actual_field] != original[original_field]:
                    raise ValueError(f"Recomputed boundary differs from current audit: {graph['model']}/{row['boundary']}/{actual_field}")
        audit["current_audit_verification"] = {
            "source_sha256": reference["source_sha256"], "nodes_compared": len(costs),
            "node_mismatches": 0, "boundaries_compared": len(expected["candidates"]),
            "boundary_mismatches": 0, "reference_used_as_feature_input": False,
            "all_exact_under_documented_null_policy": True,
            "incomplete_graph_side_policy": "The reference globally masks both side counts whenever total operations are incomplete. This export retains an independently complete side, comparing every known subtotal exactly; F_total and Imb remain null.",
        }
        all_rows.extend(rows)
        tensor_rows.extend(tensors)
        universes.append(norm)
        audits.append(audit)
    output.mkdir(parents=True, exist_ok=True)
    write_csv(output / "graph_boundary_features.csv", all_rows)
    with (output / "boundary_tensors.jsonl").open("w") as handle:
        for row in tensor_rows:
            handle.write(canonical(row) + "\n")
    write_json(output / "normalization_universes.json", {"schema": "current-graph-normalization-universes-v1", "graphs": universes})
    write_json(output / "graph_audit.json", {
        "schema": "current-graph-audit-v1", "counter": sources["counter"],
        "graphs": audits,
        "coverage_definition": "Operation completeness is coverage of explicit counting rules over graph nodes, never measured runtime or energy.",
    })
    return {
        "outputs": ["graph_boundary_features.csv", "boundary_tensors.jsonl", "normalization_universes.json", "graph_audit.json"],
        "graph_count": len(universes), "boundary_count": len(all_rows),
        "complete_graph_operations_count": sum(a["F_total"] is not None for a in audits),
        "complete_graph_enumeration_count": sum(a["enumeration_complete"] for a in audits),
        "complete_boundary_features_count": sum(r["feature_complete"] for r in all_rows),
        "boundary_ids_unique": len({r["boundary_id"] for r in all_rows}) == len(all_rows),
        "normalization_reference": "normalization_universes.json",
        "current_audit_node_match_count": sum(len(a["node_costs"]) for a in audits),
        "saved_boundary_match_count": sum(a["current_audit_verification"]["boundaries_compared"] for a in audits),
        "all_exact": True,
    }
