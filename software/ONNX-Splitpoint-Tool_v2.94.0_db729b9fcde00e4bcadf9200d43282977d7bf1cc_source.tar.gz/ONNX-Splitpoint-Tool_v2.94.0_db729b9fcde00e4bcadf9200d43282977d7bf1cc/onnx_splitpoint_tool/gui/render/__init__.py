"""GUI render/context helpers."""
